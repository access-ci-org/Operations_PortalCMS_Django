--
-- PostgreSQL database dump
--

\restrict C2bNOe3oulJmmKEGTggCUthMQa5ZshXos5qvhyb6c9dnJwIP4DjRS6A2NpNfppH

-- Dumped from database version 15.15 (Homebrew)
-- Dumped by pg_dump version 15.15 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.taggit_taggeditem DROP CONSTRAINT IF EXISTS taggit_taggeditem_tag_id_f4f5b767_fk_taggit_tag_id;
ALTER TABLE IF EXISTS ONLY public.taggit_taggeditem DROP CONSTRAINT IF EXISTS taggit_taggeditem_content_type_id_9957a03c_fk_django_co;
ALTER TABLE IF EXISTS ONLY public.socialaccount_socialaccount DROP CONSTRAINT IF EXISTS socialaccount_socialaccount_user_id_8146e70c_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.socialaccount_socialapp_sites DROP CONSTRAINT IF EXISTS socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc;
ALTER TABLE IF EXISTS ONLY public.socialaccount_socialapp_sites DROP CONSTRAINT IF EXISTS socialaccount_social_site_id_2579dee5_fk_django_si;
ALTER TABLE IF EXISTS ONLY public.socialaccount_socialtoken DROP CONSTRAINT IF EXISTS socialaccount_social_app_id_636a42d7_fk_socialacc;
ALTER TABLE IF EXISTS ONLY public.socialaccount_socialtoken DROP CONSTRAINT IF EXISTS socialaccount_social_account_id_951f210e_fk_socialacc;
ALTER TABLE IF EXISTS ONLY public.filer_image DROP CONSTRAINT IF EXISTS filer_image_file_ptr_id_3e21d4f0_fk_filer_file_id;
ALTER TABLE IF EXISTS ONLY public.filer_folderpermission DROP CONSTRAINT IF EXISTS filer_folderpermission_user_id_7673d4b6_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.filer_folderpermission DROP CONSTRAINT IF EXISTS filer_folderpermission_group_id_8901bafa_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.filer_folderpermission DROP CONSTRAINT IF EXISTS filer_folderpermission_folder_id_5d02f1da_fk_filer_folder_id;
ALTER TABLE IF EXISTS ONLY public.filer_folder DROP CONSTRAINT IF EXISTS filer_folder_parent_id_308aecda_fk_filer_folder_id;
ALTER TABLE IF EXISTS ONLY public.filer_folder DROP CONSTRAINT IF EXISTS filer_folder_owner_id_be530fb4_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.filer_file DROP CONSTRAINT IF EXISTS filer_file_polymorphic_ctype_id_f44903c1_fk_django_co;
ALTER TABLE IF EXISTS ONLY public.filer_file DROP CONSTRAINT IF EXISTS filer_file_owner_id_b9e32671_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.filer_file DROP CONSTRAINT IF EXISTS filer_file_folder_id_af803bbb_fk_filer_folder_id;
ALTER TABLE IF EXISTS ONLY public.filer_clipboarditem DROP CONSTRAINT IF EXISTS filer_clipboarditem_file_id_06196f80_fk_filer_file_id;
ALTER TABLE IF EXISTS ONLY public.filer_clipboarditem DROP CONSTRAINT IF EXISTS filer_clipboarditem_clipboard_id_7a76518b_fk_filer_clipboard_id;
ALTER TABLE IF EXISTS ONLY public.filer_clipboard DROP CONSTRAINT IF EXISTS filer_clipboard_user_id_b52ff0bc_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.easy_thumbnails_thumbnaildimensions DROP CONSTRAINT IF EXISTS easy_thumbnails_thum_thumbnail_id_c3a0c549_fk_easy_thum;
ALTER TABLE IF EXISTS ONLY public.easy_thumbnails_thumbnail DROP CONSTRAINT IF EXISTS easy_thumbnails_thum_source_id_5b57bc77_fk_easy_thum;
ALTER TABLE IF EXISTS ONLY public.operations_portalcms_django_systemstatusnewsitemplugin DROP CONSTRAINT IF EXISTS djangocmsjoy_systems_cmsplugin_ptr_id_f0585fe0_fk_cms_cmspl;
ALTER TABLE IF EXISTS ONLY public.operations_portalcms_django_systemstatusnewsitemplugin DROP CONSTRAINT IF EXISTS djangocmsjoy_systems_author_id_fb1f3e7a_fk_auth_user;
ALTER TABLE IF EXISTS ONLY public.operations_portalcms_django_systemstatusnews DROP CONSTRAINT IF EXISTS djangocmsjoy_systemnews_author_id_a0aca835_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.operations_portalcms_django_integrationnews DROP CONSTRAINT IF EXISTS djangocmsjoy_resourcenews_author_id_cb45b430_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.operations_portalcms_django_integrationnewsitemplugin DROP CONSTRAINT IF EXISTS djangocmsjoy_integra_cmsplugin_ptr_id_a403debb_fk_cms_cmspl;
ALTER TABLE IF EXISTS ONLY public.operations_portalcms_django_integrationnewsitemplugin DROP CONSTRAINT IF EXISTS djangocmsjoy_integra_author_id_32089c1a_fk_auth_user;
ALTER TABLE IF EXISTS ONLY public.djangocms_video_videotrack DROP CONSTRAINT IF EXISTS djangocms_video_videotrack_src_id_e5a015d8_fk_filer_file_id;
ALTER TABLE IF EXISTS ONLY public.djangocms_video_videosource DROP CONSTRAINT IF EXISTS djangocms_video_vide_source_file_id_16f11167_fk_filer_fil;
ALTER TABLE IF EXISTS ONLY public.djangocms_video_videoplayer DROP CONSTRAINT IF EXISTS djangocms_video_vide_poster_id_07790e24_fk_filer_ima;
ALTER TABLE IF EXISTS ONLY public.djangocms_video_videotrack DROP CONSTRAINT IF EXISTS djangocms_video_vide_cmsplugin_ptr_id_edcbdf6c_fk_cms_cmspl;
ALTER TABLE IF EXISTS ONLY public.djangocms_video_videoplayer DROP CONSTRAINT IF EXISTS djangocms_video_vide_cmsplugin_ptr_id_cc81a95d_fk_cms_cmspl;
ALTER TABLE IF EXISTS ONLY public.djangocms_video_videosource DROP CONSTRAINT IF EXISTS djangocms_video_vide_cmsplugin_ptr_id_474cebf9_fk_cms_cmspl;
ALTER TABLE IF EXISTS ONLY public.djangocms_text_ckeditor_text DROP CONSTRAINT IF EXISTS djangocms_text_ckedi_cmsplugin_ptr_id_946882c1_fk_cms_cmspl;
ALTER TABLE IF EXISTS ONLY public.djangocms_picture_picture DROP CONSTRAINT IF EXISTS djangocms_picture_picture_link_page_id_dbec9beb_fk_cms_page_id;
ALTER TABLE IF EXISTS ONLY public.djangocms_picture_picture DROP CONSTRAINT IF EXISTS djangocms_picture_pi_thumbnail_options_id_59cf80d1_fk_filer_thu;
ALTER TABLE IF EXISTS ONLY public.djangocms_picture_picture DROP CONSTRAINT IF EXISTS djangocms_picture_pi_picture_id_f7d6711b_fk_filer_ima;
ALTER TABLE IF EXISTS ONLY public.djangocms_picture_picture DROP CONSTRAINT IF EXISTS djangocms_picture_pi_cmsplugin_ptr_id_0e797309_fk_cms_cmspl;
ALTER TABLE IF EXISTS ONLY public.djangocms_link_link DROP CONSTRAINT IF EXISTS djangocms_link_link_cmsplugin_ptr_id_10f7b2f2_fk_cms_cmspl;
ALTER TABLE IF EXISTS ONLY public.djangocms_file_folder DROP CONSTRAINT IF EXISTS djangocms_file_folder_folder_src_id_9558406a_fk_filer_folder_id;
ALTER TABLE IF EXISTS ONLY public.djangocms_file_folder DROP CONSTRAINT IF EXISTS djangocms_file_folde_cmsplugin_ptr_id_b258b166_fk_cms_cmspl;
ALTER TABLE IF EXISTS ONLY public.djangocms_file_file DROP CONSTRAINT IF EXISTS djangocms_file_file_file_src_id_74ac14a5_fk_filer_file_id;
ALTER TABLE IF EXISTS ONLY public.djangocms_file_file DROP CONSTRAINT IF EXISTS djangocms_file_file_cmsplugin_ptr_id_428f5041_fk_cms_cmspl;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_user_id_c564eba6_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_content_type_id_c4bce8eb_fk_django_co;
ALTER TABLE IF EXISTS ONLY public.cms_usersettings DROP CONSTRAINT IF EXISTS cms_usersettings_user_id_09633b2d_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.cms_usersettings DROP CONSTRAINT IF EXISTS cms_usersettings_clipboard_id_3ae17c19_fk_cms_placeholder_id;
ALTER TABLE IF EXISTS ONLY public.cms_pagecontent DROP CONSTRAINT IF EXISTS cms_title_page_id_5fade2a3_fk_cms_page_id;
ALTER TABLE IF EXISTS ONLY public.cms_staticplaceholder DROP CONSTRAINT IF EXISTS cms_staticplaceholder_site_id_dc6a85b6_fk_django_site_id;
ALTER TABLE IF EXISTS ONLY public.cms_staticplaceholder DROP CONSTRAINT IF EXISTS cms_staticplaceholder_public_id_876aaa66_fk_cms_placeholder_id;
ALTER TABLE IF EXISTS ONLY public.cms_staticplaceholder DROP CONSTRAINT IF EXISTS cms_staticplaceholder_draft_id_5aee407b_fk_cms_placeholder_id;
ALTER TABLE IF EXISTS ONLY public.cms_placeholderreference DROP CONSTRAINT IF EXISTS cms_placeholderrefer_placeholder_ref_id_244759b1_fk_cms_place;
ALTER TABLE IF EXISTS ONLY public.cms_placeholderreference DROP CONSTRAINT IF EXISTS cms_placeholderrefer_cmsplugin_ptr_id_6977ec85_fk_cms_cmspl;
ALTER TABLE IF EXISTS ONLY public.cms_placeholder DROP CONSTRAINT IF EXISTS cms_placeholder_content_type_id_a7659d9c_fk_django_co;
ALTER TABLE IF EXISTS ONLY public.cms_pageusergroup DROP CONSTRAINT IF EXISTS cms_pageusergroup_group_ptr_id_34578d93_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.cms_pageusergroup DROP CONSTRAINT IF EXISTS cms_pageusergroup_created_by_id_7d57fa39_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.cms_pageuser DROP CONSTRAINT IF EXISTS cms_pageuser_user_ptr_id_b3d65592_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.cms_pageuser DROP CONSTRAINT IF EXISTS cms_pageuser_created_by_id_8e9fbf83_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.cms_pageurl DROP CONSTRAINT IF EXISTS cms_pageurl_page_id_dbf4793a_fk_cms_page_id;
ALTER TABLE IF EXISTS ONLY public.cms_pagepermission DROP CONSTRAINT IF EXISTS cms_pagepermission_user_id_0c7d2b3c_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.cms_pagepermission DROP CONSTRAINT IF EXISTS cms_pagepermission_page_id_0ae9a163_fk_cms_page_id;
ALTER TABLE IF EXISTS ONLY public.cms_pagepermission DROP CONSTRAINT IF EXISTS cms_pagepermission_group_id_af5af193_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.cms_page DROP CONSTRAINT IF EXISTS cms_page_site_id_4323d3ff_fk_django_site_id;
ALTER TABLE IF EXISTS ONLY public.cms_page DROP CONSTRAINT IF EXISTS cms_page_parent_id_f89b72e4_fk_cms_page_id;
ALTER TABLE IF EXISTS ONLY public.cms_globalpagepermission DROP CONSTRAINT IF EXISTS cms_globalpagepermission_user_id_a227cee1_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.cms_globalpagepermission DROP CONSTRAINT IF EXISTS cms_globalpagepermission_group_id_991b4733_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.cms_globalpagepermission_sites DROP CONSTRAINT IF EXISTS cms_globalpagepermis_site_id_00460b53_fk_django_si;
ALTER TABLE IF EXISTS ONLY public.cms_globalpagepermission_sites DROP CONSTRAINT IF EXISTS cms_globalpagepermis_globalpagepermission_46bd2681_fk_cms_globa;
ALTER TABLE IF EXISTS ONLY public.cms_cmsplugin DROP CONSTRAINT IF EXISTS cms_cmsplugin_placeholder_id_0bfa3b26_fk_cms_placeholder_id;
ALTER TABLE IF EXISTS ONLY public.cms_cmsplugin DROP CONSTRAINT IF EXISTS cms_cmsplugin_parent_id_fd3bd9dd_fk_cms_cmsplugin_id;
ALTER TABLE IF EXISTS ONLY public.cms_aliaspluginmodel DROP CONSTRAINT IF EXISTS cms_aliaspluginmodel_plugin_id_9867676e_fk_cms_cmsplugin_id;
ALTER TABLE IF EXISTS ONLY public.cms_aliaspluginmodel DROP CONSTRAINT IF EXISTS cms_aliaspluginmodel_cmsplugin_ptr_id_f71dfd31_fk_cms_cmspl;
ALTER TABLE IF EXISTS ONLY public.cms_aliaspluginmodel DROP CONSTRAINT IF EXISTS cms_aliaspluginmodel_alias_placeholder_id_6d6e0c8a_fk_cms_place;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_user_id_6a12ed8b_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_group_id_97559544_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_content_type_id_2f476e4b_fk_django_co;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissio_permission_id_84c5c92e_fk_auth_perm;
ALTER TABLE IF EXISTS ONLY public.account_emailconfirmation DROP CONSTRAINT IF EXISTS account_emailconfirm_email_address_id_5b7f8c58_fk_account_e;
ALTER TABLE IF EXISTS ONLY public.account_emailaddress DROP CONSTRAINT IF EXISTS account_emailaddress_user_id_2c513194_fk_auth_user_id;
DROP INDEX IF EXISTS public.unique_verified_email;
DROP INDEX IF EXISTS public.unique_primary_email;
DROP INDEX IF EXISTS public.taggit_taggeditem_tag_id_f4f5b767;
DROP INDEX IF EXISTS public.taggit_taggeditem_object_id_e2d7d1df;
DROP INDEX IF EXISTS public.taggit_taggeditem_content_type_id_9957a03c;
DROP INDEX IF EXISTS public.taggit_tagg_content_8fc721_idx;
DROP INDEX IF EXISTS public.taggit_tag_slug_6be58b2c_like;
DROP INDEX IF EXISTS public.taggit_tag_name_58eb2ed9_like;
DROP INDEX IF EXISTS public.socialaccount_socialtoken_app_id_636a42d7;
DROP INDEX IF EXISTS public.socialaccount_socialtoken_account_id_951f210e;
DROP INDEX IF EXISTS public.socialaccount_socialapp_sites_socialapp_id_97fb6e7d;
DROP INDEX IF EXISTS public.socialaccount_socialapp_sites_site_id_2579dee5;
DROP INDEX IF EXISTS public.socialaccount_socialaccount_user_id_8146e70c;
DROP INDEX IF EXISTS public.filer_folderpermission_user_id_7673d4b6;
DROP INDEX IF EXISTS public.filer_folderpermission_group_id_8901bafa;
DROP INDEX IF EXISTS public.filer_folderpermission_folder_id_5d02f1da;
DROP INDEX IF EXISTS public.filer_folder_parent_id_308aecda;
DROP INDEX IF EXISTS public.filer_folder_owner_id_be530fb4;
DROP INDEX IF EXISTS public.filer_file_polymorphic_ctype_id_f44903c1;
DROP INDEX IF EXISTS public.filer_file_owner_id_b9e32671;
DROP INDEX IF EXISTS public.filer_file_folder_id_af803bbb;
DROP INDEX IF EXISTS public.filer_clipboarditem_file_id_06196f80;
DROP INDEX IF EXISTS public.filer_clipboarditem_clipboard_id_7a76518b;
DROP INDEX IF EXISTS public.filer_clipboard_user_id_b52ff0bc;
DROP INDEX IF EXISTS public.easy_thumbnails_thumbnail_storage_hash_f1435f49_like;
DROP INDEX IF EXISTS public.easy_thumbnails_thumbnail_storage_hash_f1435f49;
DROP INDEX IF EXISTS public.easy_thumbnails_thumbnail_source_id_5b57bc77;
DROP INDEX IF EXISTS public.easy_thumbnails_thumbnail_name_b5882c31_like;
DROP INDEX IF EXISTS public.easy_thumbnails_thumbnail_name_b5882c31;
DROP INDEX IF EXISTS public.easy_thumbnails_source_storage_hash_946cbcc9_like;
DROP INDEX IF EXISTS public.easy_thumbnails_source_storage_hash_946cbcc9;
DROP INDEX IF EXISTS public.easy_thumbnails_source_name_5fe0edc6_like;
DROP INDEX IF EXISTS public.easy_thumbnails_source_name_5fe0edc6;
DROP INDEX IF EXISTS public.djangocmsjoy_systemstatusnewsitemplugin_author_id_fb1f3e7a;
DROP INDEX IF EXISTS public.djangocmsjoy_systemnews_author_id_a0aca835;
DROP INDEX IF EXISTS public.djangocmsjoy_resourcenews_author_id_cb45b430;
DROP INDEX IF EXISTS public.djangocmsjoy_integrationnewsitemplugin_author_id_32089c1a;
DROP INDEX IF EXISTS public.djangocms_video_videotrack_src_id_e5a015d8;
DROP INDEX IF EXISTS public.djangocms_video_videosource_source_file_id_16f11167;
DROP INDEX IF EXISTS public.djangocms_video_videoplayer_poster_id_07790e24;
DROP INDEX IF EXISTS public.djangocms_picture_picture_thumbnail_options_id_59cf80d1;
DROP INDEX IF EXISTS public.djangocms_picture_picture_picture_id_f7d6711b;
DROP INDEX IF EXISTS public.djangocms_picture_picture_page_link_id_d5c782e0;
DROP INDEX IF EXISTS public.djangocms_file_folder_folder_src_id_9558406a;
DROP INDEX IF EXISTS public.djangocms_file_file_file_src_id_74ac14a5;
DROP INDEX IF EXISTS public.django_site_domain_a2e37b91_like;
DROP INDEX IF EXISTS public.django_session_session_key_c0390e0f_like;
DROP INDEX IF EXISTS public.django_session_expire_date_a5c62663;
DROP INDEX IF EXISTS public.django_admin_log_user_id_c564eba6;
DROP INDEX IF EXISTS public.django_admin_log_content_type_id_c4bce8eb;
DROP INDEX IF EXISTS public.cms_usersettings_clipboard_id_3ae17c19;
DROP INDEX IF EXISTS public.cms_title_soft_root_45486e51;
DROP INDEX IF EXISTS public.cms_title_page_id_5fade2a3;
DROP INDEX IF EXISTS public.cms_title_limit_visibility_in_menu_762b16e3;
DROP INDEX IF EXISTS public.cms_title_language_50a0dfa1_like;
DROP INDEX IF EXISTS public.cms_title_language_50a0dfa1;
DROP INDEX IF EXISTS public.cms_title_in_navigation_e2463722;
DROP INDEX IF EXISTS public.cms_staticplaceholder_site_id_dc6a85b6;
DROP INDEX IF EXISTS public.cms_staticplaceholder_public_id_876aaa66;
DROP INDEX IF EXISTS public.cms_staticplaceholder_draft_id_5aee407b;
DROP INDEX IF EXISTS public.cms_placeholderreference_placeholder_ref_id_244759b1;
DROP INDEX IF EXISTS public.cms_placeholder_slot_0bc04d21_like;
DROP INDEX IF EXISTS public.cms_placeholder_slot_0bc04d21;
DROP INDEX IF EXISTS public.cms_placeholder_content_type_id_a7659d9c;
DROP INDEX IF EXISTS public.cms_pageusergroup_created_by_id_7d57fa39;
DROP INDEX IF EXISTS public.cms_pageuser_created_by_id_8e9fbf83;
DROP INDEX IF EXISTS public.cms_pageurl_slug_f8d42287_like;
DROP INDEX IF EXISTS public.cms_pageurl_slug_f8d42287;
DROP INDEX IF EXISTS public.cms_pageurl_path_9f26e673_like;
DROP INDEX IF EXISTS public.cms_pageurl_path_9f26e673;
DROP INDEX IF EXISTS public.cms_pageurl_page_id_dbf4793a;
DROP INDEX IF EXISTS public.cms_pageurl_language_a10302dc_like;
DROP INDEX IF EXISTS public.cms_pageurl_language_a10302dc;
DROP INDEX IF EXISTS public.cms_pagepermission_user_id_0c7d2b3c;
DROP INDEX IF EXISTS public.cms_pagepermission_page_id_0ae9a163;
DROP INDEX IF EXISTS public.cms_pagepermission_group_id_af5af193;
DROP INDEX IF EXISTS public.cms_page_site_id_4323d3ff;
DROP INDEX IF EXISTS public.cms_page_reverse_id_ffc9ede2_like;
DROP INDEX IF EXISTS public.cms_page_reverse_id_ffc9ede2;
DROP INDEX IF EXISTS public.cms_page_path_d3a06f3d_like;
DROP INDEX IF EXISTS public.cms_page_parent_id_f89b72e4;
DROP INDEX IF EXISTS public.cms_page_navigation_extenders_c24af8dd_like;
DROP INDEX IF EXISTS public.cms_page_navigation_extenders_c24af8dd;
DROP INDEX IF EXISTS public.cms_page_is_home_edadca07;
DROP INDEX IF EXISTS public.cms_page_application_urls_9ef47497_like;
DROP INDEX IF EXISTS public.cms_page_application_urls_9ef47497;
DROP INDEX IF EXISTS public.cms_globalpagepermission_user_id_a227cee1;
DROP INDEX IF EXISTS public.cms_globalpagepermission_sites_site_id_00460b53;
DROP INDEX IF EXISTS public.cms_globalpagepermission_sites_globalpagepermission_id_46bd2681;
DROP INDEX IF EXISTS public.cms_globalpagepermission_group_id_991b4733;
DROP INDEX IF EXISTS public.cms_cmsplugin_plugin_type_94e96ebf_like;
DROP INDEX IF EXISTS public.cms_cmsplugin_plugin_type_94e96ebf;
DROP INDEX IF EXISTS public.cms_cmsplugin_placeholder_id_0bfa3b26;
DROP INDEX IF EXISTS public.cms_cmsplugin_parent_id_fd3bd9dd;
DROP INDEX IF EXISTS public.cms_cmsplugin_language_bbea8a48_like;
DROP INDEX IF EXISTS public.cms_cmsplugin_language_bbea8a48;
DROP INDEX IF EXISTS public.cms_cmsplug_placeho_3f2b0f_idx;
DROP INDEX IF EXISTS public.cms_aliaspluginmodel_plugin_id_9867676e;
DROP INDEX IF EXISTS public.cms_aliaspluginmodel_alias_placeholder_id_6d6e0c8a;
DROP INDEX IF EXISTS public.auth_user_username_6821ab7c_like;
DROP INDEX IF EXISTS public.auth_user_user_permissions_user_id_a95ead1b;
DROP INDEX IF EXISTS public.auth_user_user_permissions_permission_id_1fbb5f2c;
DROP INDEX IF EXISTS public.auth_user_groups_user_id_6a12ed8b;
DROP INDEX IF EXISTS public.auth_user_groups_group_id_97559544;
DROP INDEX IF EXISTS public.auth_permission_content_type_id_2f476e4b;
DROP INDEX IF EXISTS public.auth_group_permissions_permission_id_84c5c92e;
DROP INDEX IF EXISTS public.auth_group_permissions_group_id_b120cbf9;
DROP INDEX IF EXISTS public.auth_group_name_a6ea08ec_like;
DROP INDEX IF EXISTS public.account_emailconfirmation_key_f43612bd_like;
DROP INDEX IF EXISTS public.account_emailconfirmation_email_address_id_5b7f8c58;
DROP INDEX IF EXISTS public.account_emailaddress_user_id_2c513194;
DROP INDEX IF EXISTS public.account_emailaddress_email_03be32b2_like;
DROP INDEX IF EXISTS public.account_emailaddress_email_03be32b2;
ALTER TABLE IF EXISTS ONLY public.cms_pageurl DROP CONSTRAINT IF EXISTS unique_together_page_language;
ALTER TABLE IF EXISTS ONLY public.taggit_taggeditem DROP CONSTRAINT IF EXISTS taggit_taggeditem_pkey;
ALTER TABLE IF EXISTS ONLY public.taggit_taggeditem DROP CONSTRAINT IF EXISTS taggit_taggeditem_content_type_id_object_id_tag_id_4bb97a8e_uni;
ALTER TABLE IF EXISTS ONLY public.taggit_tag DROP CONSTRAINT IF EXISTS taggit_tag_slug_key;
ALTER TABLE IF EXISTS ONLY public.taggit_tag DROP CONSTRAINT IF EXISTS taggit_tag_pkey;
ALTER TABLE IF EXISTS ONLY public.taggit_tag DROP CONSTRAINT IF EXISTS taggit_tag_name_key;
ALTER TABLE IF EXISTS ONLY public.socialaccount_socialtoken DROP CONSTRAINT IF EXISTS socialaccount_socialtoken_pkey;
ALTER TABLE IF EXISTS ONLY public.socialaccount_socialtoken DROP CONSTRAINT IF EXISTS socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq;
ALTER TABLE IF EXISTS ONLY public.socialaccount_socialapp_sites DROP CONSTRAINT IF EXISTS socialaccount_socialapp_sites_pkey;
ALTER TABLE IF EXISTS ONLY public.socialaccount_socialapp DROP CONSTRAINT IF EXISTS socialaccount_socialapp_pkey;
ALTER TABLE IF EXISTS ONLY public.socialaccount_socialapp_sites DROP CONSTRAINT IF EXISTS socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq;
ALTER TABLE IF EXISTS ONLY public.socialaccount_socialaccount DROP CONSTRAINT IF EXISTS socialaccount_socialaccount_provider_uid_fc810c6e_uniq;
ALTER TABLE IF EXISTS ONLY public.socialaccount_socialaccount DROP CONSTRAINT IF EXISTS socialaccount_socialaccount_pkey;
ALTER TABLE IF EXISTS ONLY public.menus_cachekey DROP CONSTRAINT IF EXISTS menus_cachekey_pkey;
ALTER TABLE IF EXISTS ONLY public.filer_thumbnailoption DROP CONSTRAINT IF EXISTS filer_thumbnailoption_pkey;
ALTER TABLE IF EXISTS ONLY public.filer_image DROP CONSTRAINT IF EXISTS filer_image_pkey;
ALTER TABLE IF EXISTS ONLY public.filer_folderpermission DROP CONSTRAINT IF EXISTS filer_folderpermission_pkey;
ALTER TABLE IF EXISTS ONLY public.filer_folder DROP CONSTRAINT IF EXISTS filer_folder_pkey;
ALTER TABLE IF EXISTS ONLY public.filer_folder DROP CONSTRAINT IF EXISTS filer_folder_parent_id_name_bc773258_uniq;
ALTER TABLE IF EXISTS ONLY public.filer_file DROP CONSTRAINT IF EXISTS filer_file_pkey;
ALTER TABLE IF EXISTS ONLY public.filer_clipboarditem DROP CONSTRAINT IF EXISTS filer_clipboarditem_pkey;
ALTER TABLE IF EXISTS ONLY public.filer_clipboard DROP CONSTRAINT IF EXISTS filer_clipboard_pkey;
ALTER TABLE IF EXISTS ONLY public.easy_thumbnails_thumbnaildimensions DROP CONSTRAINT IF EXISTS easy_thumbnails_thumbnaildimensions_thumbnail_id_key;
ALTER TABLE IF EXISTS ONLY public.easy_thumbnails_thumbnaildimensions DROP CONSTRAINT IF EXISTS easy_thumbnails_thumbnaildimensions_pkey;
ALTER TABLE IF EXISTS ONLY public.easy_thumbnails_thumbnail DROP CONSTRAINT IF EXISTS easy_thumbnails_thumbnail_pkey;
ALTER TABLE IF EXISTS ONLY public.easy_thumbnails_thumbnail DROP CONSTRAINT IF EXISTS easy_thumbnails_thumbnai_storage_hash_name_source_fb375270_uniq;
ALTER TABLE IF EXISTS ONLY public.easy_thumbnails_source DROP CONSTRAINT IF EXISTS easy_thumbnails_source_storage_hash_name_481ce32d_uniq;
ALTER TABLE IF EXISTS ONLY public.easy_thumbnails_source DROP CONSTRAINT IF EXISTS easy_thumbnails_source_pkey;
ALTER TABLE IF EXISTS ONLY public.operations_portalcms_django_systemstatusnewsitemplugin DROP CONSTRAINT IF EXISTS djangocmsjoy_systemstatusnewsitemplugin_pkey;
ALTER TABLE IF EXISTS ONLY public.operations_portalcms_django_systemstatusnews DROP CONSTRAINT IF EXISTS djangocmsjoy_systemnews_pkey;
ALTER TABLE IF EXISTS ONLY public.operations_portalcms_django_integrationnews DROP CONSTRAINT IF EXISTS djangocmsjoy_resourcenews_pkey;
ALTER TABLE IF EXISTS ONLY public.operations_portalcms_django_integrationnewsitemplugin DROP CONSTRAINT IF EXISTS djangocmsjoy_integrationnewsitemplugin_pkey;
ALTER TABLE IF EXISTS ONLY public.djangocms_video_videotrack DROP CONSTRAINT IF EXISTS djangocms_video_videotrack_pkey;
ALTER TABLE IF EXISTS ONLY public.djangocms_video_videosource DROP CONSTRAINT IF EXISTS djangocms_video_videosource_pkey;
ALTER TABLE IF EXISTS ONLY public.djangocms_video_videoplayer DROP CONSTRAINT IF EXISTS djangocms_video_video_pkey;
ALTER TABLE IF EXISTS ONLY public.djangocms_text_ckeditor_text DROP CONSTRAINT IF EXISTS djangocms_text_ckeditor_text_pkey;
ALTER TABLE IF EXISTS ONLY public.djangocms_picture_picture DROP CONSTRAINT IF EXISTS djangocms_picture_picture_pkey;
ALTER TABLE IF EXISTS ONLY public.djangocms_link_link DROP CONSTRAINT IF EXISTS djangocms_link_link_pkey;
ALTER TABLE IF EXISTS ONLY public.djangocms_file_folder DROP CONSTRAINT IF EXISTS djangocms_file_folder_pkey;
ALTER TABLE IF EXISTS ONLY public.djangocms_file_file DROP CONSTRAINT IF EXISTS djangocms_file_file_pkey;
ALTER TABLE IF EXISTS ONLY public.django_site DROP CONSTRAINT IF EXISTS django_site_pkey;
ALTER TABLE IF EXISTS ONLY public.django_site DROP CONSTRAINT IF EXISTS django_site_domain_a2e37b91_uniq;
ALTER TABLE IF EXISTS ONLY public.django_session DROP CONSTRAINT IF EXISTS django_session_pkey;
ALTER TABLE IF EXISTS ONLY public.django_migrations DROP CONSTRAINT IF EXISTS django_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public.django_content_type DROP CONSTRAINT IF EXISTS django_content_type_pkey;
ALTER TABLE IF EXISTS ONLY public.django_content_type DROP CONSTRAINT IF EXISTS django_content_type_app_label_model_76bd3d3b_uniq;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_usersettings DROP CONSTRAINT IF EXISTS cms_usersettings_user_id_key;
ALTER TABLE IF EXISTS ONLY public.cms_usersettings DROP CONSTRAINT IF EXISTS cms_usersettings_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_urlconfrevision DROP CONSTRAINT IF EXISTS cms_urlconfrevision_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_pagecontent DROP CONSTRAINT IF EXISTS cms_title_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_pagecontent DROP CONSTRAINT IF EXISTS cms_title_language_page_id_61aaf084_uniq;
ALTER TABLE IF EXISTS ONLY public.cms_staticplaceholder DROP CONSTRAINT IF EXISTS cms_staticplaceholder_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_staticplaceholder DROP CONSTRAINT IF EXISTS cms_staticplaceholder_code_site_id_21ba079c_uniq;
ALTER TABLE IF EXISTS ONLY public.cms_placeholderreference DROP CONSTRAINT IF EXISTS cms_placeholderreference_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_placeholder DROP CONSTRAINT IF EXISTS cms_placeholder_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_pageusergroup DROP CONSTRAINT IF EXISTS cms_pageusergroup_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_pageuser DROP CONSTRAINT IF EXISTS cms_pageuser_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_pageurl DROP CONSTRAINT IF EXISTS cms_pageurl_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_pagepermission DROP CONSTRAINT IF EXISTS cms_pagepermission_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_page DROP CONSTRAINT IF EXISTS cms_page_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_page DROP CONSTRAINT IF EXISTS cms_page_path_key;
ALTER TABLE IF EXISTS ONLY public.cms_globalpagepermission_sites DROP CONSTRAINT IF EXISTS cms_globalpagepermission_sites_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_globalpagepermission DROP CONSTRAINT IF EXISTS cms_globalpagepermission_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_globalpagepermission_sites DROP CONSTRAINT IF EXISTS cms_globalpagepermission_globalpagepermission_id__db684f41_uniq;
ALTER TABLE IF EXISTS ONLY public.cms_cmsplugin DROP CONSTRAINT IF EXISTS cms_cmsplugin_placeholder_id_language_position_bad60ebe_uniq;
ALTER TABLE IF EXISTS ONLY public.cms_cmsplugin DROP CONSTRAINT IF EXISTS cms_cmsplugin_pkey;
ALTER TABLE IF EXISTS ONLY public.cms_aliaspluginmodel DROP CONSTRAINT IF EXISTS cms_aliaspluginmodel_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user DROP CONSTRAINT IF EXISTS auth_user_username_key;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_user_id_permission_id_14a6b632_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user DROP CONSTRAINT IF EXISTS auth_user_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_user_id_group_id_94350c0c_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_content_type_id_codename_01ab375a_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_group DROP CONSTRAINT IF EXISTS auth_group_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_group_id_permission_id_0cd325b0_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_group DROP CONSTRAINT IF EXISTS auth_group_name_key;
ALTER TABLE IF EXISTS ONLY public.account_emailconfirmation DROP CONSTRAINT IF EXISTS account_emailconfirmation_pkey;
ALTER TABLE IF EXISTS ONLY public.account_emailconfirmation DROP CONSTRAINT IF EXISTS account_emailconfirmation_key_key;
ALTER TABLE IF EXISTS ONLY public.account_emailaddress DROP CONSTRAINT IF EXISTS account_emailaddress_user_id_email_987c8728_uniq;
ALTER TABLE IF EXISTS ONLY public.account_emailaddress DROP CONSTRAINT IF EXISTS account_emailaddress_pkey;
DROP TABLE IF EXISTS public.taggit_taggeditem;
DROP TABLE IF EXISTS public.taggit_tag;
DROP TABLE IF EXISTS public.socialaccount_socialtoken;
DROP TABLE IF EXISTS public.socialaccount_socialapp_sites;
DROP TABLE IF EXISTS public.socialaccount_socialapp;
DROP TABLE IF EXISTS public.socialaccount_socialaccount;
DROP TABLE IF EXISTS public.operations_portalcms_django_systemstatusnewsitemplugin;
DROP TABLE IF EXISTS public.operations_portalcms_django_integrationnewsitemplugin;
DROP TABLE IF EXISTS public.menus_cachekey;
DROP TABLE IF EXISTS public.filer_thumbnailoption;
DROP TABLE IF EXISTS public.filer_image;
DROP TABLE IF EXISTS public.filer_folderpermission;
DROP TABLE IF EXISTS public.filer_folder;
DROP TABLE IF EXISTS public.filer_file;
DROP TABLE IF EXISTS public.filer_clipboarditem;
DROP TABLE IF EXISTS public.filer_clipboard;
DROP TABLE IF EXISTS public.easy_thumbnails_thumbnaildimensions;
DROP TABLE IF EXISTS public.easy_thumbnails_thumbnail;
DROP TABLE IF EXISTS public.easy_thumbnails_source;
DROP TABLE IF EXISTS public.operations_portalcms_django_systemstatusnews;
DROP TABLE IF EXISTS public.operations_portalcms_django_integrationnews;
DROP TABLE IF EXISTS public.djangocms_video_videotrack;
DROP TABLE IF EXISTS public.djangocms_video_videosource;
DROP TABLE IF EXISTS public.djangocms_video_videoplayer;
DROP TABLE IF EXISTS public.djangocms_text_ckeditor_text;
DROP TABLE IF EXISTS public.djangocms_picture_picture;
DROP TABLE IF EXISTS public.djangocms_link_link;
DROP TABLE IF EXISTS public.djangocms_file_folder;
DROP TABLE IF EXISTS public.djangocms_file_file;
DROP TABLE IF EXISTS public.django_site;
DROP TABLE IF EXISTS public.django_session;
DROP TABLE IF EXISTS public.django_migrations;
DROP TABLE IF EXISTS public.django_content_type;
DROP TABLE IF EXISTS public.django_admin_log;
DROP TABLE IF EXISTS public.cms_usersettings;
DROP TABLE IF EXISTS public.cms_urlconfrevision;
DROP TABLE IF EXISTS public.cms_staticplaceholder;
DROP TABLE IF EXISTS public.cms_placeholderreference;
DROP TABLE IF EXISTS public.cms_placeholder;
DROP TABLE IF EXISTS public.cms_pageusergroup;
DROP TABLE IF EXISTS public.cms_pageuser;
DROP TABLE IF EXISTS public.cms_pageurl;
DROP TABLE IF EXISTS public.cms_pagepermission;
DROP TABLE IF EXISTS public.cms_pagecontent;
DROP TABLE IF EXISTS public.cms_page;
DROP TABLE IF EXISTS public.cms_globalpagepermission_sites;
DROP TABLE IF EXISTS public.cms_globalpagepermission;
DROP TABLE IF EXISTS public.cms_cmsplugin;
DROP TABLE IF EXISTS public.cms_aliaspluginmodel;
DROP TABLE IF EXISTS public.auth_user_user_permissions;
DROP TABLE IF EXISTS public.auth_user_groups;
DROP TABLE IF EXISTS public.auth_user;
DROP TABLE IF EXISTS public.auth_permission;
DROP TABLE IF EXISTS public.auth_group_permissions;
DROP TABLE IF EXISTS public.auth_group;
DROP TABLE IF EXISTS public.account_emailconfirmation;
DROP TABLE IF EXISTS public.account_emailaddress;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_emailaddress (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.account_emailaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.account_emailaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.account_emailconfirmation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL,
    email_address_id integer NOT NULL
);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.account_emailconfirmation ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.account_emailconfirmation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cms_aliaspluginmodel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_aliaspluginmodel (
    cmsplugin_ptr_id integer NOT NULL,
    plugin_id integer,
    alias_placeholder_id integer
);


--
-- Name: cms_cmsplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_cmsplugin (
    id integer NOT NULL,
    "position" smallint NOT NULL,
    language character varying(15) NOT NULL,
    plugin_type character varying(50) NOT NULL,
    creation_date timestamp with time zone NOT NULL,
    changed_date timestamp with time zone NOT NULL,
    parent_id integer,
    placeholder_id integer
);


--
-- Name: cms_cmsplugin_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cms_cmsplugin ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cms_cmsplugin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cms_globalpagepermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_globalpagepermission (
    id integer NOT NULL,
    can_change boolean NOT NULL,
    can_add boolean NOT NULL,
    can_delete boolean NOT NULL,
    can_change_advanced_settings boolean NOT NULL,
    can_publish boolean NOT NULL,
    can_change_permissions boolean NOT NULL,
    can_move_page boolean NOT NULL,
    can_view boolean NOT NULL,
    can_recover_page boolean NOT NULL,
    group_id integer,
    user_id integer
);


--
-- Name: cms_globalpagepermission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cms_globalpagepermission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cms_globalpagepermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cms_globalpagepermission_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_globalpagepermission_sites (
    id bigint NOT NULL,
    globalpagepermission_id integer NOT NULL,
    site_id integer NOT NULL
);


--
-- Name: cms_globalpagepermission_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cms_globalpagepermission_sites ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cms_globalpagepermission_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cms_page; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_page (
    id integer NOT NULL,
    created_by character varying(255) NOT NULL,
    changed_by character varying(255) NOT NULL,
    creation_date timestamp with time zone NOT NULL,
    changed_date timestamp with time zone NOT NULL,
    reverse_id character varying(40),
    navigation_extenders character varying(80),
    login_required boolean NOT NULL,
    is_home boolean NOT NULL,
    application_urls character varying(200),
    application_namespace character varying(200),
    is_page_type boolean NOT NULL,
    depth integer NOT NULL,
    numchild integer NOT NULL,
    parent_id integer,
    path character varying(255) NOT NULL,
    site_id integer NOT NULL,
    CONSTRAINT cms_page_depth_check CHECK ((depth >= 0)),
    CONSTRAINT cms_page_numchild_check CHECK ((numchild >= 0))
);


--
-- Name: cms_page_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cms_page ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cms_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cms_pagecontent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_pagecontent (
    id integer NOT NULL,
    language character varying(15) NOT NULL,
    meta_description text,
    title character varying(255) NOT NULL,
    page_title character varying(255),
    menu_title character varying(255),
    redirect character varying(2048),
    creation_date timestamp with time zone NOT NULL,
    page_id integer NOT NULL,
    changed_by character varying(255) NOT NULL,
    changed_date timestamp with time zone NOT NULL,
    created_by character varying(255) NOT NULL,
    in_navigation boolean NOT NULL,
    limit_visibility_in_menu smallint,
    template character varying(100) NOT NULL,
    xframe_options integer NOT NULL,
    soft_root boolean NOT NULL
);


--
-- Name: cms_pagepermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_pagepermission (
    id integer NOT NULL,
    can_change boolean NOT NULL,
    can_add boolean NOT NULL,
    can_delete boolean NOT NULL,
    can_change_advanced_settings boolean NOT NULL,
    can_publish boolean NOT NULL,
    can_change_permissions boolean NOT NULL,
    can_move_page boolean NOT NULL,
    can_view boolean NOT NULL,
    grant_on integer NOT NULL,
    group_id integer,
    page_id integer,
    user_id integer
);


--
-- Name: cms_pagepermission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cms_pagepermission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cms_pagepermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cms_pageurl; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_pageurl (
    id integer NOT NULL,
    slug character varying(255) NOT NULL,
    path character varying(255),
    language character varying(15) NOT NULL,
    managed boolean NOT NULL,
    page_id integer NOT NULL
);


--
-- Name: cms_pageurl_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cms_pageurl ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cms_pageurl_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cms_pageuser; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_pageuser (
    user_ptr_id integer NOT NULL,
    created_by_id integer
);


--
-- Name: cms_pageusergroup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_pageusergroup (
    group_ptr_id integer NOT NULL,
    created_by_id integer
);


--
-- Name: cms_placeholder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_placeholder (
    id integer NOT NULL,
    slot character varying(255) NOT NULL,
    default_width smallint,
    content_type_id integer,
    object_id integer,
    CONSTRAINT cms_placeholder_default_width_check CHECK ((default_width >= 0)),
    CONSTRAINT cms_placeholder_object_id_check CHECK ((object_id >= 0))
);


--
-- Name: cms_placeholder_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cms_placeholder ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cms_placeholder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cms_placeholderreference; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_placeholderreference (
    cmsplugin_ptr_id integer NOT NULL,
    name character varying(255) NOT NULL,
    placeholder_ref_id integer
);


--
-- Name: cms_staticplaceholder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_staticplaceholder (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    dirty boolean NOT NULL,
    creation_method character varying(20) NOT NULL,
    draft_id integer,
    public_id integer,
    site_id integer
);


--
-- Name: cms_staticplaceholder_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cms_staticplaceholder ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cms_staticplaceholder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cms_title_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cms_pagecontent ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cms_title_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cms_urlconfrevision; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_urlconfrevision (
    id integer NOT NULL,
    revision character varying(255) NOT NULL
);


--
-- Name: cms_urlconfrevision_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cms_urlconfrevision ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cms_urlconfrevision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cms_usersettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cms_usersettings (
    id integer NOT NULL,
    language character varying(10) NOT NULL,
    clipboard_id integer,
    user_id integer NOT NULL
);


--
-- Name: cms_usersettings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.cms_usersettings ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cms_usersettings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


--
-- Name: django_site; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_site ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: djangocms_file_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_file_file (
    cmsplugin_ptr_id integer NOT NULL,
    file_name character varying(255) NOT NULL,
    link_target character varying(255) NOT NULL,
    link_title character varying(255) NOT NULL,
    file_src_id integer,
    attributes text NOT NULL,
    template character varying(255) NOT NULL,
    show_file_size boolean NOT NULL
);


--
-- Name: djangocms_file_folder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_file_folder (
    template character varying(255) NOT NULL,
    link_target character varying(255) NOT NULL,
    show_file_size boolean NOT NULL,
    attributes text NOT NULL,
    cmsplugin_ptr_id integer NOT NULL,
    folder_src_id integer
);


--
-- Name: djangocms_link_link; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_link_link (
    cmsplugin_ptr_id integer NOT NULL,
    name character varying(255) NOT NULL,
    target character varying(255) NOT NULL,
    attributes text NOT NULL,
    template character varying(255) NOT NULL,
    link jsonb NOT NULL
);


--
-- Name: djangocms_picture_picture; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_picture_picture (
    cmsplugin_ptr_id integer NOT NULL,
    link_url character varying(2040),
    alignment character varying(255) NOT NULL,
    link_page_id integer,
    height integer,
    width integer,
    picture_id integer,
    attributes text NOT NULL,
    caption_text text,
    link_attributes text NOT NULL,
    link_target character varying(255) NOT NULL,
    use_automatic_scaling boolean NOT NULL,
    use_crop boolean NOT NULL,
    use_no_cropping boolean NOT NULL,
    use_upscale boolean NOT NULL,
    thumbnail_options_id integer,
    external_picture character varying(255),
    template character varying(255) NOT NULL,
    use_responsive_image character varying(7) NOT NULL,
    CONSTRAINT djangocms_picture_picture_height_3db3e080_check CHECK ((height >= 0)),
    CONSTRAINT djangocms_picture_picture_width_5bba3699_check CHECK ((width >= 0))
);


--
-- Name: djangocms_text_ckeditor_text; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_text_ckeditor_text (
    cmsplugin_ptr_id integer NOT NULL,
    body text NOT NULL
);


--
-- Name: djangocms_video_videoplayer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_video_videoplayer (
    cmsplugin_ptr_id integer NOT NULL,
    embed_link character varying(255) NOT NULL,
    poster_id integer,
    attributes text NOT NULL,
    label character varying(255) NOT NULL,
    template character varying(255) NOT NULL,
    parameters text NOT NULL
);


--
-- Name: djangocms_video_videosource; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_video_videosource (
    cmsplugin_ptr_id integer NOT NULL,
    text_title character varying(255) NOT NULL,
    text_description text NOT NULL,
    attributes text NOT NULL,
    source_file_id integer
);


--
-- Name: djangocms_video_videotrack; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.djangocms_video_videotrack (
    cmsplugin_ptr_id integer NOT NULL,
    kind character varying(255) NOT NULL,
    srclang character varying(255) NOT NULL,
    label character varying(255) NOT NULL,
    attributes text NOT NULL,
    src_id integer
);


--
-- Name: operations_portalcms_django_integrationnews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operations_portalcms_django_integrationnews (
    id bigint NOT NULL,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_active boolean NOT NULL,
    author_id integer NOT NULL,
    affected_element character varying(100) NOT NULL,
    effective_date date,
    expiration_date date,
    news_type character varying(50) NOT NULL
);


--
-- Name: djangocmsjoy_resourcenews_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.operations_portalcms_django_integrationnews ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.djangocmsjoy_resourcenews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: operations_portalcms_django_systemstatusnews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operations_portalcms_django_systemstatusnews (
    id bigint NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_active boolean NOT NULL,
    author_id integer NOT NULL,
    effective_date date,
    expiration_date date,
    affected_infrastructure character varying(255) NOT NULL,
    email_list character varying(500) NOT NULL,
    end_datetime timestamp with time zone,
    infrastructure_news_type character varying(50) NOT NULL,
    post_to_slack boolean NOT NULL,
    send_email boolean NOT NULL,
    slack_channel character varying(100) NOT NULL,
    start_datetime timestamp with time zone,
    subject character varying(200) NOT NULL
);


--
-- Name: djangocmsjoy_systemnews_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.operations_portalcms_django_systemstatusnews ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.djangocmsjoy_systemnews_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: easy_thumbnails_source; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.easy_thumbnails_source (
    id integer NOT NULL,
    storage_hash character varying(40) NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL
);


--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.easy_thumbnails_source ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.easy_thumbnails_source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: easy_thumbnails_thumbnail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.easy_thumbnails_thumbnail (
    id integer NOT NULL,
    storage_hash character varying(40) NOT NULL,
    name character varying(255) NOT NULL,
    modified timestamp with time zone NOT NULL,
    source_id integer NOT NULL
);


--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.easy_thumbnails_thumbnail ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.easy_thumbnails_thumbnail_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: easy_thumbnails_thumbnaildimensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.easy_thumbnails_thumbnaildimensions (
    id integer NOT NULL,
    thumbnail_id integer NOT NULL,
    width integer,
    height integer,
    CONSTRAINT easy_thumbnails_thumbnaildimensions_height_check CHECK ((height >= 0)),
    CONSTRAINT easy_thumbnails_thumbnaildimensions_width_check CHECK ((width >= 0))
);


--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.easy_thumbnails_thumbnaildimensions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.easy_thumbnails_thumbnaildimensions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: filer_clipboard; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filer_clipboard (
    id integer NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: filer_clipboard_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.filer_clipboard ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.filer_clipboard_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: filer_clipboarditem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filer_clipboarditem (
    id integer NOT NULL,
    clipboard_id integer NOT NULL,
    file_id integer NOT NULL
);


--
-- Name: filer_clipboarditem_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.filer_clipboarditem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.filer_clipboarditem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: filer_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filer_file (
    id integer NOT NULL,
    file character varying(255),
    _file_size bigint,
    sha1 character varying(40) NOT NULL,
    has_all_mandatory_data boolean NOT NULL,
    original_filename character varying(255),
    name character varying(255) NOT NULL,
    description text,
    uploaded_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    is_public boolean NOT NULL,
    folder_id integer,
    owner_id integer,
    polymorphic_ctype_id integer,
    mime_type character varying(255) NOT NULL
);


--
-- Name: filer_file_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.filer_file ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.filer_file_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: filer_folder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filer_folder (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    uploaded_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone NOT NULL,
    modified_at timestamp with time zone NOT NULL,
    owner_id integer,
    parent_id integer
);


--
-- Name: filer_folder_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.filer_folder ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.filer_folder_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: filer_folderpermission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filer_folderpermission (
    id integer NOT NULL,
    type smallint NOT NULL,
    everybody boolean NOT NULL,
    can_edit smallint,
    can_read smallint,
    can_add_children smallint,
    folder_id integer,
    group_id integer,
    user_id integer
);


--
-- Name: filer_folderpermission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.filer_folderpermission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.filer_folderpermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: filer_image; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filer_image (
    file_ptr_id integer NOT NULL,
    _height double precision,
    _width double precision,
    date_taken timestamp with time zone,
    default_alt_text character varying(255),
    default_caption character varying(255),
    author character varying(255),
    must_always_publish_author_credit boolean NOT NULL,
    must_always_publish_copyright boolean NOT NULL,
    subject_location character varying(64) NOT NULL,
    _transparent boolean NOT NULL
);


--
-- Name: filer_thumbnailoption; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.filer_thumbnailoption (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    crop boolean NOT NULL,
    upscale boolean NOT NULL
);


--
-- Name: filer_thumbnailoption_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.filer_thumbnailoption ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.filer_thumbnailoption_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: menus_cachekey; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menus_cachekey (
    id integer NOT NULL,
    language character varying(255) NOT NULL,
    site integer NOT NULL,
    key character varying(255) NOT NULL,
    CONSTRAINT menus_cachekey_site_check CHECK ((site >= 0))
);


--
-- Name: menus_cachekey_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.menus_cachekey ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.menus_cachekey_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: operations_portalcms_django_integrationnewsitemplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operations_portalcms_django_integrationnewsitemplugin (
    cmsplugin_ptr_id integer NOT NULL,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    published_date timestamp with time zone NOT NULL,
    author_id integer NOT NULL
);


--
-- Name: operations_portalcms_django_systemstatusnewsitemplugin; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operations_portalcms_django_systemstatusnewsitemplugin (
    cmsplugin_ptr_id integer NOT NULL,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    published_date timestamp with time zone NOT NULL,
    author_id integer NOT NULL
);


--
-- Name: socialaccount_socialaccount; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.socialaccount_socialaccount (
    id integer NOT NULL,
    provider character varying(200) NOT NULL,
    uid character varying(191) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    extra_data jsonb NOT NULL,
    user_id integer NOT NULL
);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.socialaccount_socialaccount ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.socialaccount_socialaccount_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: socialaccount_socialapp; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.socialaccount_socialapp (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    name character varying(40) NOT NULL,
    client_id character varying(191) NOT NULL,
    secret character varying(191) NOT NULL,
    key character varying(191) NOT NULL,
    provider_id character varying(200) NOT NULL,
    settings jsonb NOT NULL
);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.socialaccount_socialapp ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.socialaccount_socialapp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: socialaccount_socialapp_sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.socialaccount_socialapp_sites (
    id bigint NOT NULL,
    socialapp_id integer NOT NULL,
    site_id integer NOT NULL
);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.socialaccount_socialapp_sites ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.socialaccount_socialapp_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: socialaccount_socialtoken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.socialaccount_socialtoken (
    id integer NOT NULL,
    token text NOT NULL,
    token_secret text NOT NULL,
    expires_at timestamp with time zone,
    account_id integer NOT NULL,
    app_id integer
);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.socialaccount_socialtoken ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.socialaccount_socialtoken_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: taggit_tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taggit_tag (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL
);


--
-- Name: taggit_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.taggit_tag ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.taggit_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: taggit_taggeditem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.taggit_taggeditem (
    id integer NOT NULL,
    object_id integer NOT NULL,
    content_type_id integer NOT NULL,
    tag_id integer NOT NULL
);


--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.taggit_taggeditem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.taggit_taggeditem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
\.


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group (id, name) FROM stdin;
1	System Status Editors
2	Integration News Editors
3	All News Editors
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
1	1	193
2	1	194
3	1	195
4	1	196
5	2	200
6	2	197
7	2	198
8	2	199
9	3	193
10	3	194
11	3	195
12	3	196
13	3	197
14	3	198
15	3	199
16	3	200
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can use Structure mode	1	use_structure
2	Can change page	2	change_page
3	Can add log entry	6	add_logentry
4	Can change log entry	6	change_logentry
5	Can delete log entry	6	delete_logentry
6	Can view log entry	6	view_logentry
7	Can add permission	7	add_permission
8	Can change permission	7	change_permission
9	Can delete permission	7	delete_permission
10	Can view permission	7	view_permission
11	Can add group	8	add_group
12	Can change group	8	change_group
13	Can delete group	8	delete_group
14	Can view group	8	view_group
15	Can add user	9	add_user
16	Can change user	9	change_user
17	Can delete user	9	delete_user
18	Can view user	9	view_user
19	Can add content type	10	add_contenttype
20	Can change content type	10	change_contenttype
21	Can delete content type	10	delete_contenttype
22	Can view content type	10	view_contenttype
23	Can add session	11	add_session
24	Can change session	11	change_session
25	Can delete session	11	delete_session
26	Can view session	11	view_session
27	Can add site	12	add_site
28	Can change site	12	change_site
29	Can delete site	12	delete_site
30	Can view site	12	view_site
31	Can add plugin	13	add_cmsplugin
32	Can change plugin	13	change_cmsplugin
33	Can delete plugin	13	delete_cmsplugin
34	Can view plugin	13	view_cmsplugin
35	Can add alias plugin model	14	add_aliaspluginmodel
36	Can change alias plugin model	14	change_aliaspluginmodel
37	Can delete alias plugin model	14	delete_aliaspluginmodel
38	Can view alias plugin model	14	view_aliaspluginmodel
39	Can add Page global permission	15	add_globalpagepermission
40	Can change Page global permission	15	change_globalpagepermission
41	Can delete Page global permission	15	delete_globalpagepermission
42	Can view Page global permission	15	view_globalpagepermission
43	Can add page	2	add_page
44	Can delete page	2	delete_page
45	Can view page	2	view_page
46	Can publish page	2	publish_page
47	Can edit static placeholders	2	edit_static_placeholder
48	Can add Page permission	16	add_pagepermission
49	Can change Page permission	16	change_pagepermission
50	Can delete Page permission	16	delete_pagepermission
51	Can view Page permission	16	view_pagepermission
52	Can add User (page)	17	add_pageuser
53	Can change User (page)	17	change_pageuser
54	Can delete User (page)	17	delete_pageuser
55	Can view User (page)	17	view_pageuser
56	Can add User group (page)	18	add_pageusergroup
57	Can change User group (page)	18	change_pageusergroup
58	Can delete User group (page)	18	delete_pageusergroup
59	Can view User group (page)	18	view_pageusergroup
60	Can add placeholder reference	19	add_placeholderreference
61	Can change placeholder reference	19	change_placeholderreference
62	Can delete placeholder reference	19	delete_placeholderreference
63	Can view placeholder reference	19	view_placeholderreference
64	Can add static placeholder	3	add_staticplaceholder
65	Can change static placeholder	3	change_staticplaceholder
66	Can delete static placeholder	3	delete_staticplaceholder
67	Can view static placeholder	3	view_staticplaceholder
68	Can add user setting	4	add_usersettings
69	Can change user setting	4	change_usersettings
70	Can delete user setting	4	delete_usersettings
71	Can view user setting	4	view_usersettings
72	Can add urlconf revision	20	add_urlconfrevision
73	Can change urlconf revision	20	change_urlconfrevision
74	Can delete urlconf revision	20	delete_urlconfrevision
75	Can view urlconf revision	20	view_urlconfrevision
76	Can add cache key	23	add_cachekey
77	Can change cache key	23	change_cachekey
78	Can delete cache key	23	delete_cachekey
79	Can view cache key	23	view_cachekey
80	Can add ACCESS News	24	add_accessnews
81	Can change ACCESS News	24	change_accessnews
82	Can delete ACCESS News	24	delete_accessnews
83	Can view ACCESS News	24	view_accessnews
84	Can add System News	25	add_systemnews
85	Can change System News	25	change_systemnews
86	Can delete System News	25	delete_systemnews
87	Can view System News	25	view_systemnews
88	Can add Resource News	26	add_resourcenews
89	Can change Resource News	26	change_resourcenews
90	Can delete Resource News	26	delete_resourcenews
91	Can view Resource News	26	view_resourcenews
92	Can add System News	25	add_systemstatusnews
93	Can change System News	25	change_systemstatusnews
94	Can delete System News	25	delete_systemstatusnews
95	Can view System News	25	view_systemstatusnews
96	Can add Resource News	26	add_integrationnews
97	Can change Resource News	26	change_integrationnews
98	Can delete Resource News	26	delete_integrationnews
99	Can view Resource News	26	view_integrationnews
100	Can add system status news item plugin	27	add_systemstatusnewsitemplugin
101	Can change system status news item plugin	27	change_systemstatusnewsitemplugin
102	Can delete system status news item plugin	27	delete_systemstatusnewsitemplugin
103	Can view system status news item plugin	27	view_systemstatusnewsitemplugin
104	Can add integration news item plugin	28	add_integrationnewsitemplugin
105	Can change integration news item plugin	28	change_integrationnewsitemplugin
106	Can delete integration news item plugin	28	delete_integrationnewsitemplugin
107	Can view integration news item plugin	28	view_integrationnewsitemplugin
108	Can add text	29	add_text
109	Can change text	29	change_text
110	Can delete text	29	delete_text
111	Can view text	29	view_text
112	Can add picture	30	add_picture
113	Can change picture	30	change_picture
114	Can delete picture	30	delete_picture
115	Can view picture	30	view_picture
116	Can add file	31	add_file
117	Can change file	31	change_file
118	Can delete file	31	delete_file
119	Can view file	31	view_file
120	Can add folder	32	add_folder
121	Can change folder	32	change_folder
122	Can delete folder	32	delete_folder
123	Can view folder	32	view_folder
124	Can add link	33	add_link
125	Can change link	33	change_link
126	Can delete link	33	delete_link
127	Can view link	33	view_link
128	Can add video player	34	add_videoplayer
129	Can change video player	34	change_videoplayer
130	Can delete video player	34	delete_videoplayer
131	Can view video player	34	view_videoplayer
132	Can add video source	35	add_videosource
133	Can change video source	35	change_videosource
134	Can delete video source	35	delete_videosource
135	Can view video source	35	view_videosource
136	Can add video track	36	add_videotrack
137	Can change video track	36	change_videotrack
138	Can delete video track	36	delete_videotrack
139	Can view video track	36	view_videotrack
140	Can add clipboard	37	add_clipboard
141	Can change clipboard	37	change_clipboard
142	Can delete clipboard	37	delete_clipboard
143	Can view clipboard	37	view_clipboard
144	Can add Folder	38	add_folder
145	Can change Folder	38	change_folder
146	Can delete Folder	38	delete_folder
147	Can view Folder	38	view_folder
148	Can use directory listing	38	can_use_directory_listing
149	Can add file	39	add_file
150	Can change file	39	change_file
151	Can delete file	39	delete_file
152	Can view file	39	view_file
153	Can add clipboard item	40	add_clipboarditem
154	Can change clipboard item	40	change_clipboarditem
155	Can delete clipboard item	40	delete_clipboarditem
156	Can view clipboard item	40	view_clipboarditem
157	Can add thumbnail option	41	add_thumbnailoption
158	Can change thumbnail option	41	change_thumbnailoption
159	Can delete thumbnail option	41	delete_thumbnailoption
160	Can view thumbnail option	41	view_thumbnailoption
161	Can add folder permission	42	add_folderpermission
162	Can change folder permission	42	change_folderpermission
163	Can delete folder permission	42	delete_folderpermission
164	Can view folder permission	42	view_folderpermission
165	Can add image	43	add_image
166	Can change image	43	change_image
167	Can delete image	43	delete_image
168	Can view image	43	view_image
169	Can add source	44	add_source
170	Can change source	44	change_source
171	Can delete source	44	delete_source
172	Can view source	44	view_source
173	Can add thumbnail	45	add_thumbnail
174	Can change thumbnail	45	change_thumbnail
175	Can delete thumbnail	45	delete_thumbnail
176	Can view thumbnail	45	view_thumbnail
177	Can add thumbnail dimensions	46	add_thumbnaildimensions
178	Can change thumbnail dimensions	46	change_thumbnaildimensions
179	Can delete thumbnail dimensions	46	delete_thumbnaildimensions
180	Can view thumbnail dimensions	46	view_thumbnaildimensions
181	Can add tag	47	add_tag
182	Can change tag	47	change_tag
183	Can delete tag	47	delete_tag
184	Can view tag	47	view_tag
185	Can add tagged item	48	add_taggeditem
186	Can change tagged item	48	change_taggeditem
187	Can delete tagged item	48	delete_taggeditem
188	Can view tagged item	48	view_taggeditem
189	Can add ACCESS News	49	add_accessnews
190	Can change ACCESS News	49	change_accessnews
191	Can delete ACCESS News	49	delete_accessnews
192	Can view ACCESS News	49	view_accessnews
193	Can add System News	50	add_systemstatusnews
194	Can change System News	50	change_systemstatusnews
195	Can delete System News	50	delete_systemstatusnews
196	Can view System News	50	view_systemstatusnews
197	Can add Resource News	51	add_integrationnews
198	Can change Resource News	51	change_integrationnews
199	Can delete Resource News	51	delete_integrationnews
200	Can view Resource News	51	view_integrationnews
201	Can add integration news item plugin	52	add_integrationnewsitemplugin
202	Can change integration news item plugin	52	change_integrationnewsitemplugin
203	Can delete integration news item plugin	52	delete_integrationnewsitemplugin
204	Can view integration news item plugin	52	view_integrationnewsitemplugin
205	Can add system status news item plugin	53	add_systemstatusnewsitemplugin
206	Can change system status news item plugin	53	change_systemstatusnewsitemplugin
207	Can delete system status news item plugin	53	delete_systemstatusnewsitemplugin
208	Can view system status news item plugin	53	view_systemstatusnewsitemplugin
209	Can add email address	54	add_emailaddress
210	Can change email address	54	change_emailaddress
211	Can delete email address	54	delete_emailaddress
212	Can view email address	54	view_emailaddress
213	Can add email confirmation	55	add_emailconfirmation
214	Can change email confirmation	55	change_emailconfirmation
215	Can delete email confirmation	55	delete_emailconfirmation
216	Can view email confirmation	55	view_emailconfirmation
217	Can add social account	56	add_socialaccount
218	Can change social account	56	change_socialaccount
219	Can delete social account	56	delete_socialaccount
220	Can view social account	56	view_socialaccount
221	Can add social application	57	add_socialapp
222	Can change social application	57	change_socialapp
223	Can delete social application	57	delete_socialapp
224	Can view social application	57	view_socialapp
225	Can add social application token	58	add_socialtoken
226	Can change social application token	58	change_socialtoken
227	Can delete social application token	58	delete_socialtoken
228	Can view social application token	58	view_socialtoken
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
5	pbkdf2_sha256$1000000$8qr7AuRw5ULgKuoMOKcF22$32yi8ktmAC/twIBc6M4Ys/Y6GplqZVOyLMVKVTKrroo=	\N	t	admin			admin@example.com	t	t	2026-02-10 08:43:06.774356-05
2	pbkdf2_sha256$1000000$sPqDBf033PlNkTp1gDquvH$b+Mxt2swkhFK1py4ObW5RhAxaL6M6E+a5sbM6c9S+P8=	2026-02-03 16:49:02-05	f	cmser_django			jelambe@iu.edu	t	t	2026-01-13 12:38:59-05
3	pbkdf2_sha256$1000000$I3PgwvOOtA4sIfj5ny0I3j$XSp5BqM+Bn0ipmWGBOSGCU+xP3XylF/RC00BnhDNdnk=	\N	f	cms_tester				f	t	2026-02-03 09:41:40-05
4	pbkdf2_sha256$1000000$lE7lRlYk0DcCujlnrzy8tN$59MzBDZTpZYlWx0/bsRg7Rs0M31JxNml2JRQjkT9gY8=	2026-02-13 09:31:46.06938-05	t	portalcms_django	portalcms_django			t	t	2026-02-03 13:24:49-05
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
2	3	2
3	2	1
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: cms_aliaspluginmodel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_aliaspluginmodel (cmsplugin_ptr_id, plugin_id, alias_placeholder_id) FROM stdin;
\.


--
-- Data for Name: cms_cmsplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_cmsplugin (id, "position", language, plugin_type, creation_date, changed_date, parent_id, placeholder_id) FROM stdin;
56	1	en	TextPlugin	2026-02-16 10:56:55.647283-05	2026-02-16 11:03:36.391927-05	\N	194
3	1	en	TextPlugin	2026-02-03 15:26:12.235649-05	2026-02-03 15:26:12.236909-05	\N	10
4	1	en	TextPlugin	2026-02-03 15:32:33.849133-05	2026-02-03 15:32:33.851601-05	\N	11
5	0	en	PicturePlugin	2026-02-03 15:32:34.127791-05	2026-02-03 15:32:34.168305-05	4	11
6	1	en	TextPlugin	2026-02-03 15:44:39.58289-05	2026-02-03 15:44:39.585912-05	\N	12
7	0	en	PicturePlugin	2026-02-03 15:44:39.719358-05	2026-02-03 15:44:39.818845-05	6	12
45	1	en	TextPlugin	2026-02-06 11:32:49.003074-05	2026-02-06 11:33:47.335677-05	\N	111
38	1	en	TextPlugin	2026-02-05 10:24:55.613048-05	2026-02-05 13:22:35.764565-05	\N	104
9	1	en	TextPlugin	2026-02-03 16:38:32.158219-05	2026-02-03 16:38:47.844498-05	\N	30
8	1	en	TextPlugin	2026-02-03 16:37:56.505704-05	2026-02-03 16:39:21.033632-05	\N	29
57	1	en	TextPlugin	2026-02-16 11:03:50.208471-05	2026-02-16 11:05:32.750177-05	\N	207
46	1	en	TextPlugin	2026-02-06 11:33:51.851419-05	2026-02-06 11:34:00.201588-05	\N	113
39	1	en	TextPlugin	2026-02-06 09:37:07.705186-05	2026-02-06 11:36:01.527216-05	\N	16
48	1	en	TextPlugin	2026-02-12 13:28:48.435331-05	2026-02-12 14:06:07.991415-05	\N	142
31	1	en	PicturePlugin	2026-02-04 17:12:52.429685-05	2026-02-04 17:12:52.440705-05	27	43
27	2	en	TextPlugin	2026-02-04 16:58:44.518916-05	2026-02-04 17:13:16.767531-05	\N	43
13	1	en	TextPlugin	2026-02-04 14:11:18.49769-05	2026-02-04 14:15:37.755305-05	\N	34
41	1	en	TextPlugin	2026-02-06 09:39:07.163085-05	2026-02-06 11:47:01.098641-05	\N	20
37	1	en	TextPlugin	2026-02-05 10:12:48.812368-05	2026-02-05 10:16:59.31763-05	\N	91
32	1	en	TextPlugin	2026-02-04 17:13:41.80606-05	2026-02-04 17:15:13.49281-05	\N	45
33	1	en	TextPlugin	2026-02-04 17:16:00.110534-05	2026-02-04 17:16:10.498127-05	\N	46
12	1	en	TextPlugin	2026-02-04 14:04:50.238226-05	2026-02-05 10:19:40.937159-05	\N	32
23	2	en	TextPlugin	2026-02-04 14:49:03.768939-05	2026-02-04 14:59:40.36765-05	\N	28
26	1	en	PicturePlugin	2026-02-04 14:59:40.442944-05	2026-02-04 14:59:40.457488-05	23	28
36	1	en	TextPlugin	2026-02-05 09:55:27.347571-05	2026-02-13 07:59:28.468857-05	\N	78
40	1	en	TextPlugin	2026-02-06 09:37:57.16937-05	2026-02-06 10:09:04.836392-05	\N	18
47	1	en	TextPlugin	2026-02-06 11:52:40.992658-05	2026-02-06 11:57:56.065881-05	\N	129
34	1	en	TextPlugin	2026-02-05 08:19:48.205818-05	2026-02-05 08:51:17.393009-05	\N	47
35	1	en	TextPlugin	2026-02-05 08:59:47.33645-05	2026-02-13 08:00:07.72182-05	\N	65
42	1	en	TextPlugin	2026-02-06 10:59:10.710942-05	2026-02-06 11:11:35.585071-05	\N	107
50	1	en	TextPlugin	2026-02-16 08:36:25.267653-05	2026-02-16 08:52:16.143008-05	\N	146
43	1	en	TextPlugin	2026-02-06 11:20:19.832023-05	2026-02-06 11:22:11.437285-05	\N	109
51	1	en	TextPlugin	2026-02-16 10:13:16.129448-05	2026-02-16 10:30:16.742936-05	\N	168
52	2	en	TextPlugin	2026-02-16 10:25:22.033071-05	2026-02-16 10:33:56.176586-05	\N	181
55	1	en	PicturePlugin	2026-02-16 10:33:56.227651-05	2026-02-16 10:33:56.246878-05	52	181
\.


--
-- Data for Name: cms_globalpagepermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_globalpagepermission (id, can_change, can_add, can_delete, can_change_advanced_settings, can_publish, can_change_permissions, can_move_page, can_view, can_recover_page, group_id, user_id) FROM stdin;
\.


--
-- Data for Name: cms_globalpagepermission_sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_globalpagepermission_sites (id, globalpagepermission_id, site_id) FROM stdin;
\.


--
-- Data for Name: cms_page; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_page (id, created_by, changed_by, creation_date, changed_date, reverse_id, navigation_extenders, login_required, is_home, application_urls, application_namespace, is_page_type, depth, numchild, parent_id, path, site_id) FROM stdin;
12	portalcms_django	portalcms_django	2026-02-05 08:55:32.308205-05	2026-02-05 08:55:32.319629-05	\N	\N	f	f	\N	\N	f	2	0	9	00030005	1
13	portalcms_django	portalcms_django	2026-02-05 09:12:08.978229-05	2026-02-05 09:12:08.981837-05	\N	\N	f	f	\N	\N	f	2	0	9	00030006	1
14	portalcms_django	portalcms_django	2026-02-05 10:11:57.289628-05	2026-02-05 10:11:57.303343-05	\N	\N	f	f	\N	\N	f	2	0	9	00030007	1
15	portalcms_django	portalcms_django	2026-02-05 10:24:06.515582-05	2026-02-05 10:24:06.525583-05	\N	\N	f	f	\N	\N	f	2	0	9	00030008	1
8	cmser_django	cmser_django	2026-02-03 15:44:39.525941-05	2026-02-03 16:28:08.696062-05	\N	\N	f	f		\N	f	2	1	9	00030001	1
16	portalcms_django	portalcms_django	2026-02-06 11:45:57.232848-05	2026-02-06 11:45:57.260983-05	\N	\N	f	f	\N	\N	f	3	0	8	000300010001	1
17	portalcms_django	portalcms_django	2026-02-12 13:00:13.804018-05	2026-02-12 13:00:13.813423-05	\N	\N	f	f	\N	\N	f	2	0	9	00030009	1
6	cmser_django	cmser_django	2026-02-03 15:26:12.21335-05	2026-02-03 15:26:12.215509-05	\N	\N	f	f	\N	\N	f	1	0	\N	0001	1
19	portalcms_django	portalcms_django	2026-02-16 08:35:13.373299-05	2026-02-16 08:35:13.379277-05	\N	\N	f	f	\N	\N	f	2	0	9	0003000A	1
20	portalcms_django	portalcms_django	2026-02-16 10:12:22.114744-05	2026-02-16 10:12:22.117705-05	\N	\N	f	f	\N	\N	f	2	0	9	0003000B	1
21	portalcms_django	portalcms_django	2026-02-16 10:24:52.716471-05	2026-02-16 10:24:52.718852-05	\N	\N	f	f	\N	\N	f	2	0	9	0003000C	1
22	portalcms_django	portalcms_django	2026-02-16 10:56:25.297222-05	2026-02-16 10:56:25.299343-05	\N	\N	f	f	\N	\N	f	2	0	9	0003000D	1
9	cmser_django	cmser_django	2026-02-03 15:48:40.463945-05	2026-02-03 15:48:40.465515-05	\N	\N	f	f	\N	\N	f	1	14	\N	0003	1
23	portalcms_django	portalcms_django	2026-02-16 11:02:44.36408-05	2026-02-16 11:02:44.365065-05	\N	\N	f	f	\N	\N	f	2	0	9	0003000E	1
7	cmser_django	cmser_django	2026-02-03 15:32:33.802102-05	2026-02-03 15:32:33.80452-05	\N	\N	f	f	\N	\N	f	2	0	9	00030002	1
10	cmser_django	cmser_django	2026-02-03 16:00:20.617872-05	2026-02-03 16:00:20.61875-05	\N	\N	f	f	\N	\N	f	2	0	9	00030003	1
11	cmser_django	cmser_django	2026-02-03 16:02:10.945976-05	2026-02-03 16:02:10.947024-05	\N	\N	f	f	\N	\N	f	2	0	9	00030004	1
\.


--
-- Data for Name: cms_pagecontent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_pagecontent (id, language, meta_description, title, page_title, menu_title, redirect, creation_date, page_id, changed_by, changed_date, created_by, in_navigation, limit_visibility_in_menu, template, xframe_options, soft_root) FROM stdin;
17	en		ACCESS Infrastructure Integration				2026-02-12 13:00:13.825718-05	17	portalcms_django	2026-02-12 13:00:21.319175-05	portalcms_django	t	\N	page.html	0	f
7	en		Student Training and Engagement Program				2026-02-03 15:32:33.819255-05	7	portalcms_django	2026-02-04 13:56:40.510917-05	cmser_django	t	\N	focus_area.html	0	f
6	en	\N	Home	\N	\N	\N	2026-02-03 15:26:12.222543-05	6	cmser_django	2026-02-03 15:26:12.222616-05	cmser_django	f	\N	page.html	0	f
19	en		Infrastructure Location Map			\N	2026-02-16 08:35:13.393502-05	19	portalcms_django	2026-02-16 08:35:13.425373-05	portalcms_django	t	\N	INHERIT	0	f
9	en		Public Content			\N	2026-02-03 15:48:40.473135-05	9	cmser_django	2026-02-03 15:48:40.480596-05	cmser_django	f	\N	focus_area.html	0	f
20	en		Infrastructure Maps				2026-02-16 10:12:22.128379-05	20	portalcms_django	2026-02-16 10:12:39.083349-05	portalcms_django	t	\N	page.html	0	f
12	en		ACCESS Ticket System FAQs				2026-02-05 08:55:32.32897-05	12	portalcms_django	2026-02-05 09:13:06.112522-05	portalcms_django	t	\N	page.html	0	f
10	en		Operational Support	Operational Support			2026-02-03 16:00:20.624898-05	10	cmser_django	2026-02-03 16:04:59.56829-05	cmser_django	t	\N	focus_area.html	0	f
13	en		ACCESS Identity Management - Frequently Asked Questions				2026-02-05 09:12:08.991971-05	13	portalcms_django	2026-02-05 09:14:31.223313-05	portalcms_django	t	\N	page.html	0	f
21	en		CONECT Map				2026-02-16 10:24:52.73441-05	21	portalcms_django	2026-02-16 10:30:33.895334-05	portalcms_django	t	\N	page.html	0	f
14	en		About ACCESS Operations				2026-02-05 10:11:57.314352-05	14	portalcms_django	2026-02-05 10:12:11.346412-05	portalcms_django	t	\N	page.html	0	f
22	en		Infrastructure Timelines				2026-02-16 10:56:25.312361-05	22	portalcms_django	2026-02-16 10:56:31.664367-05	portalcms_django	t	\N	page.html	0	f
15	en		ACCESS Integration and Operations Help				2026-02-05 10:24:06.537165-05	15	portalcms_django	2026-02-05 10:24:32.039975-05	portalcms_django	t	\N	page.html	0	f
23	en		Infrastructure Production Timeline				2026-02-16 11:02:44.379463-05	23	portalcms_django	2026-02-16 11:02:50.938021-05	portalcms_django	t	\N	page.html	0	f
8	en		CyberSecurity				2026-02-03 15:44:39.544836-05	8	portalcms_django	2026-02-06 08:33:57.727871-05	cmser_django	t	\N	focus_area.html	0	f
11	en		Data Transfer and Networking Support		Data Transfer and Networking Support		2026-02-03 16:02:10.955409-05	11	portalcms_django	2026-02-06 10:56:42.487108-05	cmser_django	t	\N	focus_area.html	0	f
16	en		Cybersecurity Awareness Resources				2026-02-06 11:45:57.280335-05	16	portalcms_django	2026-02-06 11:46:04.460393-05	portalcms_django	t	\N	page.html	0	f
\.


--
-- Data for Name: cms_pagepermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_pagepermission (id, can_change, can_add, can_delete, can_change_advanced_settings, can_publish, can_change_permissions, can_move_page, can_view, grant_on, group_id, page_id, user_id) FROM stdin;
\.


--
-- Data for Name: cms_pageurl; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_pageurl (id, slug, path, language, managed, page_id) FROM stdin;
6	home	home	en	t	6
9	pub	pub	en	t	9
10	operational_support	pub/operational_support	en	t	10
7	step	pub/step	en	t	7
12	ticketing-faqs	pub/ticketing-faqs	en	t	12
13	identity-faqs	pub/identity-faqs	en	t	13
14	about	pub/about	en	t	14
15	help	pub/help	en	t	15
8	cybersecurity	pub/cybersecurity	en	t	8
11	data_n_networking	pub/data_n_networking	en	t	11
16	awareness	pub/cybersecurity/awareness	en	t	16
17	access-infrastructure-integration	pub/access-infrastructure-integration	en	t	17
19	infrastructure-location-map	pub/infrastructure-location-map	en	t	19
20	infrastructure-maps	pub/infrastructure-maps	en	t	20
21	conect-map	pub/conect-map	en	t	21
22	infrastructure-timelines	pub/infrastructure-timelines	en	t	22
23	infrastructure-production-timeline	pub/infrastructure-production-timeline	en	t	23
\.


--
-- Data for Name: cms_pageuser; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_pageuser (user_ptr_id, created_by_id) FROM stdin;
\.


--
-- Data for Name: cms_pageusergroup; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_pageusergroup (group_ptr_id, created_by_id) FROM stdin;
\.


--
-- Data for Name: cms_placeholder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_placeholder (id, slot, default_width, content_type_id, object_id) FROM stdin;
1	clipboard	\N	4	1
7	clipboard	\N	4	2
10	content	\N	5	6
11	content	\N	5	7
12	content	\N	5	8
13	content	\N	5	9
14	hero_image	\N	5	8
15	section_1_heading	\N	5	8
16	section_1_content	\N	5	8
17	section_2_heading	\N	5	8
18	section_2_content	\N	5	8
19	section_3_heading	\N	5	8
20	section_3_content	\N	5	8
21	section_4_heading	\N	5	8
22	section_4_content	\N	5	8
23	section_5_heading	\N	5	8
24	section_5_content	\N	5	8
25	additional_links	\N	5	8
26	content	\N	5	10
27	content	\N	5	11
28	hero_image	\N	5	7
29	section_1_heading	\N	5	7
30	section_1_content	\N	5	7
31	section_2_heading	\N	5	7
32	section_2_content	\N	5	7
33	section_3_heading	\N	5	7
34	section_3_content	\N	5	7
35	section_4_heading	\N	5	7
36	section_4_content	\N	5	7
37	section_5_heading	\N	5	7
38	section_5_content	\N	5	7
39	additional_links	\N	5	7
40	clipboard	\N	4	3
41	hero_image	\N	5	10
42	section_1_heading	\N	5	10
43	section_1_content	\N	5	10
44	section_2_heading	\N	5	10
45	section_2_content	\N	5	10
46	section_3_heading	\N	5	10
47	section_3_content	\N	5	10
48	section_4_heading	\N	5	10
49	section_4_content	\N	5	10
50	section_5_heading	\N	5	10
51	section_5_content	\N	5	10
52	additional_links	\N	5	10
53	hero_image	\N	5	12
54	section_1_heading	\N	5	12
55	section_1_content	\N	5	12
56	section_2_heading	\N	5	12
57	section_2_content	\N	5	12
58	section_3_heading	\N	5	12
59	section_3_content	\N	5	12
60	section_4_heading	\N	5	12
61	section_4_content	\N	5	12
62	section_5_heading	\N	5	12
63	section_5_content	\N	5	12
64	additional_links	\N	5	12
65	content	\N	5	12
66	hero_image	\N	5	13
67	section_1_heading	\N	5	13
68	section_1_content	\N	5	13
69	section_2_heading	\N	5	13
70	section_2_content	\N	5	13
71	section_3_heading	\N	5	13
72	section_3_content	\N	5	13
73	section_4_heading	\N	5	13
74	section_4_content	\N	5	13
75	section_5_heading	\N	5	13
76	section_5_content	\N	5	13
77	additional_links	\N	5	13
78	content	\N	5	13
79	hero_image	\N	5	14
80	section_1_heading	\N	5	14
81	section_1_content	\N	5	14
82	section_2_heading	\N	5	14
83	section_2_content	\N	5	14
84	section_3_heading	\N	5	14
85	section_3_content	\N	5	14
86	section_4_heading	\N	5	14
87	section_4_content	\N	5	14
88	section_5_heading	\N	5	14
89	section_5_content	\N	5	14
90	additional_links	\N	5	14
91	content	\N	5	14
92	hero_image	\N	5	15
93	section_1_heading	\N	5	15
94	section_1_content	\N	5	15
95	section_2_heading	\N	5	15
96	section_2_content	\N	5	15
97	section_3_heading	\N	5	15
98	section_3_content	\N	5	15
99	section_4_heading	\N	5	15
100	section_4_content	\N	5	15
101	section_5_heading	\N	5	15
102	section_5_content	\N	5	15
103	additional_links	\N	5	15
104	content	\N	5	15
105	hero_image	\N	5	11
106	section_1_heading	\N	5	11
107	section_1_content	\N	5	11
108	section_2_heading	\N	5	11
109	section_2_content	\N	5	11
110	section_3_heading	\N	5	11
111	section_3_content	\N	5	11
112	section_4_heading	\N	5	11
113	section_4_content	\N	5	11
114	section_5_heading	\N	5	11
115	section_5_content	\N	5	11
116	additional_links	\N	5	11
117	hero_image	\N	5	16
118	section_1_heading	\N	5	16
119	section_1_content	\N	5	16
120	section_2_heading	\N	5	16
121	section_2_content	\N	5	16
122	section_3_heading	\N	5	16
123	section_3_content	\N	5	16
124	section_4_heading	\N	5	16
125	section_4_content	\N	5	16
126	section_5_heading	\N	5	16
127	section_5_content	\N	5	16
128	additional_links	\N	5	16
129	content	\N	5	16
130	hero_image	\N	5	17
131	section_1_heading	\N	5	17
132	section_1_content	\N	5	17
133	section_2_heading	\N	5	17
134	section_2_content	\N	5	17
135	section_3_heading	\N	5	17
136	section_3_content	\N	5	17
137	section_4_heading	\N	5	17
138	section_4_content	\N	5	17
139	section_5_heading	\N	5	17
140	section_5_content	\N	5	17
141	additional_links	\N	5	17
142	content	\N	5	17
144	hero_image	\N	5	19
145	section_1_heading	\N	5	19
146	section_1_content	\N	5	19
147	section_2_heading	\N	5	19
148	section_2_content	\N	5	19
149	section_3_heading	\N	5	19
150	section_3_content	\N	5	19
151	section_4_heading	\N	5	19
152	section_4_content	\N	5	19
153	section_5_heading	\N	5	19
154	section_5_content	\N	5	19
155	additional_links	\N	5	19
156	hero_image	\N	5	20
157	section_1_heading	\N	5	20
158	section_1_content	\N	5	20
159	section_2_heading	\N	5	20
160	section_2_content	\N	5	20
161	section_3_heading	\N	5	20
162	section_3_content	\N	5	20
163	section_4_heading	\N	5	20
164	section_4_content	\N	5	20
165	section_5_heading	\N	5	20
166	section_5_content	\N	5	20
167	additional_links	\N	5	20
168	content	\N	5	20
169	hero_image	\N	5	21
170	section_1_heading	\N	5	21
171	section_1_content	\N	5	21
172	section_2_heading	\N	5	21
173	section_2_content	\N	5	21
174	section_3_heading	\N	5	21
175	section_3_content	\N	5	21
176	section_4_heading	\N	5	21
177	section_4_content	\N	5	21
178	section_5_heading	\N	5	21
179	section_5_content	\N	5	21
180	additional_links	\N	5	21
181	content	\N	5	21
182	hero_image	\N	5	22
183	section_1_heading	\N	5	22
184	section_1_content	\N	5	22
185	section_2_heading	\N	5	22
186	section_2_content	\N	5	22
187	section_3_heading	\N	5	22
188	section_3_content	\N	5	22
189	section_4_heading	\N	5	22
190	section_4_content	\N	5	22
191	section_5_heading	\N	5	22
192	section_5_content	\N	5	22
193	additional_links	\N	5	22
194	content	\N	5	22
195	hero_image	\N	5	23
196	section_1_heading	\N	5	23
197	section_1_content	\N	5	23
198	section_2_heading	\N	5	23
199	section_2_content	\N	5	23
200	section_3_heading	\N	5	23
201	section_3_content	\N	5	23
202	section_4_heading	\N	5	23
203	section_4_content	\N	5	23
204	section_5_heading	\N	5	23
205	section_5_content	\N	5	23
206	additional_links	\N	5	23
207	content	\N	5	23
\.


--
-- Data for Name: cms_placeholderreference; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_placeholderreference (cmsplugin_ptr_id, name, placeholder_ref_id) FROM stdin;
\.


--
-- Data for Name: cms_staticplaceholder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_staticplaceholder (id, name, code, dirty, creation_method, draft_id, public_id, site_id) FROM stdin;
\.


--
-- Data for Name: cms_urlconfrevision; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_urlconfrevision (id, revision) FROM stdin;
\.


--
-- Data for Name: cms_usersettings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cms_usersettings (id, language, clipboard_id, user_id) FROM stdin;
2	en	7	2
3	en	40	4
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
5	2026-02-03 08:30:54.806772-05	1	serviceindex_django	3		9	2
6	2026-02-03 09:36:03.380884-05	2	cmser_django	2	[{"changed": {"fields": ["Groups"]}}]	9	2
7	2026-02-03 09:41:40.315988-05	3	cms_tester	1	[{"added": {}}]	9	2
8	2026-02-03 12:33:57.471707-05	1	https://operations.access-ci.org/	2	[{"changed": {"fields": ["Domain name", "Display name"]}}]	12	2
9	2026-02-03 13:24:49.963868-05	4	portalcms_django	1	[{"added": {}}]	9	2
10	2026-02-03 13:25:10.764066-05	4	portalcms_django	2	[{"changed": {"fields": ["First name", "Superuser status"]}}]	9	2
11	2026-02-03 14:15:51.386585-05	4	Student Training and Engagement Program (/)	1	Added Page Translation	2	2
12	2026-02-03 14:16:39.527418-05	4	Student Training and Engagement Program (/)	2	Changed Page Translation	2	2
13	2026-02-03 14:16:42.453868-05	4	Student Training and Engagement Program (/)	2	Changed Page Translation	2	2
14	2026-02-03 14:17:27.132224-05	4	Student Training and Engagement Program (/)	2	Changed Page Translation	2	2
15	2026-02-03 14:22:48.918781-05	4	Student Training and Engagement Program (/)	2	Changed Page Translation	2	2
16	2026-02-03 14:40:03.638663-05	4	Student Training and Engagement Program (/)	2	Changed Page Translation	2	2
17	2026-02-03 14:41:26.053296-05	4	Student Training and Engagement Program (/)	2	Changed Page Translation	2	2
18	2026-02-03 15:03:50.289454-05	4	Student Training and Engagement Program (/)	2	Changed Page Translation	2	2
19	2026-02-03 15:04:00.376367-05	4	Student Training and Engagement Program (/)	2	Changed Page Translation	2	2
20	2026-02-03 15:06:42.670877-05	4	Student Training and Engagement Program (/)	3	Deleted	2	2
21	2026-02-03 15:21:30.584647-05	5	Student Training and Engagement Program (/)	1	Added Page Translation	2	2
22	2026-02-03 15:26:12.229546-05	6	Home (/home)	1	Added Page Translation	2	2
23	2026-02-03 15:26:37.53067-05	6	Home (/home)	2	Moved	2	2
24	2026-02-03 15:26:41.834839-05	6	Home (/home)	2	Moved	2	2
25	2026-02-03 15:30:41.162972-05	5	Student Training and Engagement Program (/)	3	Deleted	2	2
26	2026-02-03 15:32:33.842659-05	7	Student Training and Engagement Program (/step)	1	Added Page Translation	2	2
27	2026-02-03 15:44:39.574658-05	8	CyberSecurity (/cybersecurity)	1	Added Page Translation	2	2
28	2026-02-03 15:46:07.138385-05	8	CyberSecurity (/cybersecurity)	2	Changed Page Translation	2	2
29	2026-02-03 15:46:18.090004-05	7	Student Training and Engagement Program (/step)	2	Changed Page Translation	2	2
30	2026-02-03 15:48:40.479119-05	9	Public Content (/pub)	1	Added Page Translation	2	2
31	2026-02-03 15:49:17.836118-05	9	Public Content (/cybersecurity/pub)	2	Moved	2	2
32	2026-02-03 15:49:28.217264-05	9	Public Content (/pub)	2	Moved	2	2
33	2026-02-03 15:49:35.374188-05	7	Student Training and Engagement Program (/pub/step)	2	Moved	2	2
34	2026-02-03 15:49:37.733037-05	7	Student Training and Engagement Program (/step)	2	Moved	2	2
35	2026-02-03 15:49:58.053891-05	8	CyberSecurity (/pub/cybersecurity)	2	Moved	2	2
36	2026-02-03 15:57:33.996533-05	7	Student Training and Engagement Program (/pub/step)	2	Moved	2	2
37	2026-02-03 16:00:20.645389-05	10	Operational Support (/operational-support)	1	Added Page Translation	2	2
38	2026-02-03 16:00:24.698004-05	10	Operational Support (/pub/operational-support)	2	Moved	2	2
39	2026-02-03 16:00:34.15227-05	10	Operational Support (/pub/operational-support)	2	Changed Page Translation	2	2
40	2026-02-03 16:02:10.960498-05	11	Data Transfer and Networking Support (/data_n_networking)	1	Added Page Translation	2	2
41	2026-02-03 16:02:15.116363-05	11	Data Transfer and Networking Support (/pub/data_n_networking)	2	Moved	2	2
42	2026-02-03 16:02:25.227869-05	11	Data Transfer and Networking Support (/pub/data_n_networking)	2	Changed Page Translation	2	2
43	2026-02-03 16:04:59.566315-05	10	Operational Support (/pub/operational_support)	2	Changed Page Translation	2	2
44	2026-02-03 16:28:08.707648-05	8	CyberSecurity (/pub/cybersecurity)	2	[]	2	2
45	2026-02-03 16:31:35.990924-05	8	CyberSecurity (/pub/cybersecurity)	2	Changed Page Translation	2	2
46	2026-02-03 16:38:12.700699-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	2
47	2026-02-03 16:38:47.889033-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	2
48	2026-02-03 16:39:21.049573-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
49	2026-02-03 16:39:51.442645-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	2
50	2026-02-03 16:41:31.392575-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	2
51	2026-02-03 16:49:19.709145-05	4	portalcms_django	2	[{"changed": {"fields": ["Staff status"]}}]	9	2
52	2026-02-04 10:39:57.04278-05	11	Data Transfer and Networking Support (/pub/data_n_networking)	2	Changed Page Translation	2	4
53	2026-02-04 10:46:33.4633-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	4
54	2026-02-04 10:46:53.79881-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	4
55	2026-02-04 13:55:58.668712-05	7	Student Training and Engagement Program (/pub/step)	2	Deleted Plugin	2	4
56	2026-02-04 13:56:40.509674-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Page Translation	2	4
57	2026-02-04 14:03:48.777253-05	7	Student Training and Engagement Program (/pub/step)	2	Deleted Plugin	2	4
58	2026-02-04 14:06:08.328256-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	4
59	2026-02-04 14:08:51.450119-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	4
60	2026-02-04 14:10:16.25576-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
61	2026-02-04 14:10:36.026731-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
62	2026-02-04 14:11:26.235311-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	4
63	2026-02-04 14:11:55.559691-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	4
64	2026-02-04 14:12:30.011315-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
65	2026-02-04 14:12:50.080949-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
66	2026-02-04 14:13:19.811984-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
67	2026-02-04 14:14:00.257846-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
68	2026-02-04 14:14:12.864919-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
69	2026-02-04 14:15:37.805188-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
70	2026-02-04 14:16:45.034761-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	4
71	2026-02-04 14:18:22.749184-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	4
72	2026-02-04 14:19:03.643813-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	4
73	2026-02-04 14:19:15.305143-05	7	Student Training and Engagement Program (/pub/step)	2	Cleared Placeholder	2	4
74	2026-02-04 14:19:57.441605-05	7	Student Training and Engagement Program (/pub/step)	2	Moved Plugin	2	4
75	2026-02-04 14:20:01.685839-05	7	Student Training and Engagement Program (/pub/step)	2	Moved Plugin	2	4
76	2026-02-04 14:20:28.640579-05	7	Student Training and Engagement Program (/pub/step)	2	Moved Plugin	2	4
77	2026-02-04 14:20:38.080853-05	7	Student Training and Engagement Program (/pub/step)	2	Moved Plugin	2	4
78	2026-02-04 14:21:15.231684-05	7	Student Training and Engagement Program (/pub/step)	2	Moved Plugin	2	4
79	2026-02-04 14:22:02.915525-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	4
80	2026-02-04 14:22:27.386537-05	7	Student Training and Engagement Program (/pub/step)	2	Cleared Placeholder	2	4
81	2026-02-04 14:22:34.408654-05	7	Student Training and Engagement Program (/pub/step)	2	Cleared Placeholder	2	4
82	2026-02-04 14:23:21.909436-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	4
83	2026-02-04 14:23:56.117033-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	4
84	2026-02-04 14:24:06.546526-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	4
85	2026-02-04 14:24:28.421471-05	7	Student Training and Engagement Program (/pub/step)	2	Cleared Placeholder	2	4
86	2026-02-04 14:24:32.525549-05	7	Student Training and Engagement Program (/pub/step)	2	Cleared Placeholder	2	4
87	2026-02-04 14:30:52.481984-05	4	STEP-collage-2024.jpg	2	[{"changed": {"fields": ["Subject location"]}}]	43	4
88	2026-02-04 14:31:04.275094-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	4
89	2026-02-04 14:35:44.124243-05	7	Student Training and Engagement Program (/pub/step)	2	Cleared Placeholder	2	4
90	2026-02-04 14:39:05.964129-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	4
91	2026-02-04 14:40:50.491857-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
92	2026-02-04 14:41:44.613313-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
93	2026-02-04 14:41:54.421955-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
94	2026-02-04 14:42:00.480433-05	7	Student Training and Engagement Program (/pub/step)	2	Deleted Plugin	2	2
95	2026-02-04 14:44:00.484621-05	4	STEP-collage-2024.jpg	2	[]	43	4
96	2026-02-04 14:44:15.556526-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	4
97	2026-02-04 14:44:55.785668-05	4	STEP-collage-2024.jpg	2	[{"changed": {"fields": ["Default alt text"]}}]	43	2
98	2026-02-04 14:45:25.912812-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
99	2026-02-04 14:48:56.893996-05	7	Student Training and Engagement Program (/pub/step)	2	Cleared Placeholder	2	4
100	2026-02-04 14:49:23.57239-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	4
101	2026-02-04 14:49:32.324148-05	7	Student Training and Engagement Program (/pub/step)	2	Added Plugin	2	4
102	2026-02-04 14:50:42.215596-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	4
103	2026-02-04 14:51:45.930065-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
104	2026-02-04 14:53:04.530263-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
105	2026-02-04 14:54:20.5393-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
106	2026-02-04 14:59:11.781297-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	2
107	2026-02-04 14:59:40.544266-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	4
108	2026-02-04 15:33:30.425871-05	7	Student Training and Engagement Program (/pub/step)	2	Cleared Placeholder	2	4
109	2026-02-04 15:33:35.238511-05	7	Student Training and Engagement Program (/pub/step)	2	Cleared Placeholder	2	4
110	2026-02-04 17:01:12.840124-05	10	Operational Support (/pub/operational_support)	2	Added Plugin	2	2
111	2026-02-04 17:06:17.316924-05	10	Operational Support (/pub/operational_support)	2	Changed Plugin	2	4
112	2026-02-04 17:08:02.003712-05	10	Operational Support (/pub/operational_support)	2	Changed Plugin	2	4
113	2026-02-04 17:10:23.881081-05	10	Operational Support (/pub/operational_support)	2	Changed Plugin	2	4
114	2026-02-04 17:12:26.682371-05	10	Operational Support (/pub/operational_support)	2	Changed Plugin	2	4
115	2026-02-04 17:12:52.484243-05	10	Operational Support (/pub/operational_support)	2	Changed Plugin	2	4
116	2026-02-04 17:13:16.828203-05	10	Operational Support (/pub/operational_support)	2	Changed Plugin	2	4
117	2026-02-04 17:13:47.909726-05	10	Operational Support (/pub/operational_support)	2	Added Plugin	2	4
118	2026-02-04 17:14:02.490486-05	10	Operational Support (/pub/operational_support)	2	Changed Plugin	2	4
119	2026-02-04 17:14:25.643389-05	10	Operational Support (/pub/operational_support)	2	Changed Plugin	2	4
120	2026-02-04 17:15:13.514202-05	10	Operational Support (/pub/operational_support)	2	Changed Plugin	2	2
121	2026-02-04 17:16:10.529886-05	10	Operational Support (/pub/operational_support)	2	Added Plugin	2	4
122	2026-02-05 08:35:05.748103-05	10	Operational Support (/pub/operational_support)	2	Added Plugin	2	4
123	2026-02-05 08:40:08.518411-05	10	Operational Support (/pub/operational_support)	2	Changed Plugin	2	4
124	2026-02-05 08:40:57.659434-05	10	Operational Support (/pub/operational_support)	2	Changed Plugin	2	4
125	2026-02-05 08:51:17.430751-05	10	Operational Support (/pub/operational_support)	2	Changed Plugin	2	4
126	2026-02-05 08:55:32.341031-05	12	FAQs (/pub/faqs)	1	Added Page Translation	2	4
127	2026-02-05 08:55:52.84094-05	12	FAQs (/pub/faqs)	2	Changed Page Translation	2	4
128	2026-02-05 09:00:56.911002-05	12	FAQs (/pub/faqs)	2	Added Plugin	2	2
129	2026-02-05 09:02:27.20922-05	12	FAQs (/pub/faqs)	2	Changed Plugin	2	4
130	2026-02-05 09:12:09.008763-05	13	ACCESS Identity Management - Frequently Asked Questions (/pub/identity-faqs)	1	Added Page Translation	2	4
131	2026-02-05 09:13:06.108585-05	12	ACCESS Ticket System FAQs (/pub/ticketing-faqs)	2	Changed Page Translation	2	4
132	2026-02-05 09:14:17.25669-05	13	ACCESS Identity Management - Frequently Asked Questions (/pub/identity-faqs)	2	Changed Page Translation	2	4
133	2026-02-05 09:14:31.219472-05	13	ACCESS Identity Management - Frequently Asked Questions (/pub/identity-faqs)	2	Changed Page Translation	2	4
134	2026-02-05 09:28:28.685531-05	12	ACCESS Ticket System FAQs (/pub/ticketing-faqs)	2	Changed Plugin	2	4
135	2026-02-05 09:32:01.706035-05	12	ACCESS Ticket System FAQs (/pub/ticketing-faqs)	2	Changed Plugin	2	4
136	2026-02-05 09:55:42.024653-05	13	ACCESS Identity Management - Frequently Asked Questions (/pub/identity-faqs)	2	Added Plugin	2	4
137	2026-02-05 10:02:59.331604-05	12	ACCESS Ticket System FAQs (/pub/ticketing-faqs)	2	Changed Plugin	2	4
138	2026-02-05 10:09:58.038715-05	12	ACCESS Ticket System FAQs (/pub/ticketing-faqs)	2	Changed Plugin	2	4
139	2026-02-05 10:10:46.929579-05	13	ACCESS Identity Management - Frequently Asked Questions (/pub/identity-faqs)	2	Changed Plugin	2	4
140	2026-02-05 10:11:57.346872-05	14	About ACCESS Operations (/pub/about)	1	Added Page Translation	2	4
141	2026-02-05 10:12:09.070639-05	14	About ACCESS Operations (/pub/about)	2	Changed Page Translation	2	4
142	2026-02-05 10:12:11.344235-05	14	About ACCESS Operations (/pub/about)	2	Changed Page Translation	2	4
143	2026-02-05 10:16:01.499939-05	14	About ACCESS Operations (/pub/about)	2	Added Plugin	2	4
144	2026-02-05 10:16:50.072358-05	14	About ACCESS Operations (/pub/about)	2	Changed Plugin	2	4
145	2026-02-05 10:16:59.359641-05	14	About ACCESS Operations (/pub/about)	2	Changed Plugin	2	4
146	2026-02-05 10:19:40.966462-05	7	Student Training and Engagement Program (/pub/step)	2	Changed Plugin	2	4
147	2026-02-05 10:24:06.558661-05	15	ACCESS Integration and Operations Help (/pub/help)	1	Added Page Translation	2	4
148	2026-02-05 10:24:21.290424-05	15	ACCESS Integration and Operations Help (/pub/help)	2	Changed Page Translation	2	4
149	2026-02-05 10:24:32.038823-05	15	ACCESS Integration and Operations Help (/pub/help)	2	Changed Page Translation	2	4
150	2026-02-05 10:30:27.422536-05	15	ACCESS Integration and Operations Help (/pub/help)	2	Added Plugin	2	4
151	2026-02-05 10:30:58.158324-05	15	ACCESS Integration and Operations Help (/pub/help)	2	Changed Plugin	2	4
152	2026-02-05 10:31:02.558647-05	15	ACCESS Integration and Operations Help (/pub/help)	2	Changed Plugin	2	4
153	2026-02-05 10:34:06.899473-05	15	ACCESS Integration and Operations Help (/pub/help)	2	Changed Plugin	2	4
154	2026-02-05 10:36:39.242842-05	15	ACCESS Integration and Operations Help (/pub/help)	2	Changed Plugin	2	4
155	2026-02-05 13:06:12.113322-05	15	ACCESS Integration and Operations Help (/pub/help)	2	Changed Plugin	2	4
156	2026-02-05 13:12:49.407782-05	15	ACCESS Integration and Operations Help (/pub/help)	2	Changed Plugin	2	4
157	2026-02-05 13:15:32.635703-05	15	ACCESS Integration and Operations Help (/pub/help)	2	Changed Plugin	2	4
158	2026-02-05 13:19:23.888634-05	15	ACCESS Integration and Operations Help (/pub/help)	2	Changed Plugin	2	4
159	2026-02-05 13:22:35.806267-05	15	ACCESS Integration and Operations Help (/pub/help)	2	Changed Plugin	2	4
160	2026-02-05 13:27:41.1995-05	12	ACCESS Ticket System FAQs (/pub/ticketing-faqs)	2	Changed Plugin	2	4
161	2026-02-05 13:28:12.733476-05	12	ACCESS Ticket System FAQs (/pub/ticketing-faqs)	2	Changed Plugin	2	4
162	2026-02-06 08:33:57.715798-05	8	CyberSecurity (/pub/cybersecurity)	2	Changed Page Translation	2	4
163	2026-02-06 09:37:18.157508-05	8	CyberSecurity (/pub/cybersecurity)	2	Added Plugin	2	4
164	2026-02-06 09:38:11.139903-05	8	CyberSecurity (/pub/cybersecurity)	2	Added Plugin	2	4
165	2026-02-06 09:39:12.849123-05	8	CyberSecurity (/pub/cybersecurity)	2	Added Plugin	2	4
166	2026-02-06 09:46:53.486089-05	8	CyberSecurity (/pub/cybersecurity)	2	Changed Plugin	2	4
167	2026-02-06 09:47:40.877242-05	8	CyberSecurity (/pub/cybersecurity)	2	Changed Plugin	2	4
168	2026-02-06 10:09:04.918475-05	8	CyberSecurity (/pub/cybersecurity)	2	Changed Plugin	2	4
169	2026-02-06 10:56:42.475182-05	11	Data Transfer and Networking Support (/pub/data_n_networking)	2	Changed Page Translation	2	4
170	2026-02-06 11:08:44.035108-05	11	Data Transfer and Networking Support (/pub/data_n_networking)	2	Added Plugin	2	4
171	2026-02-06 11:11:35.6396-05	11	Data Transfer and Networking Support (/pub/data_n_networking)	2	Changed Plugin	2	4
172	2026-02-06 11:20:31.999878-05	11	Data Transfer and Networking Support (/pub/data_n_networking)	2	Added Plugin	2	4
173	2026-02-06 11:21:15.726789-05	11	Data Transfer and Networking Support (/pub/data_n_networking)	2	Changed Plugin	2	4
174	2026-02-06 11:22:11.466855-05	11	Data Transfer and Networking Support (/pub/data_n_networking)	2	Changed Plugin	2	4
175	2026-02-06 11:22:43.646647-05	11	Data Transfer and Networking Support (/pub/data_n_networking)	2	Added Plugin	2	4
176	2026-02-06 11:22:53.183186-05	11	Data Transfer and Networking Support (/pub/data_n_networking)	2	Changed Plugin	2	4
177	2026-02-06 11:32:21.450983-05	11	Data Transfer and Networking Support (/pub/data_n_networking)	2	Cleared Placeholder	2	4
178	2026-02-06 11:32:59.604096-05	11	Data Transfer and Networking Support (/pub/data_n_networking)	2	Added Plugin	2	4
179	2026-02-06 11:33:47.394573-05	11	Data Transfer and Networking Support (/pub/data_n_networking)	2	Changed Plugin	2	4
180	2026-02-06 11:34:00.223367-05	11	Data Transfer and Networking Support (/pub/data_n_networking)	2	Added Plugin	2	4
181	2026-02-06 11:36:01.57822-05	8	CyberSecurity (/pub/cybersecurity)	2	Changed Plugin	2	4
182	2026-02-06 11:36:30.574173-05	8	CyberSecurity (/pub/cybersecurity)	2	Changed Plugin	2	4
183	2026-02-06 11:45:57.298419-05	16	Cybersecurity Awareness Resources (/pub/cybersecurity/awareness)	1	Added Page Translation	2	4
184	2026-02-06 11:46:04.459139-05	16	Cybersecurity Awareness Resources (/pub/cybersecurity/awareness)	2	Changed Page Translation	2	4
185	2026-02-06 11:47:01.172308-05	8	CyberSecurity (/pub/cybersecurity)	2	Changed Plugin	2	4
186	2026-02-06 11:54:10.619038-05	16	Cybersecurity Awareness Resources (/pub/cybersecurity/awareness)	2	Added Plugin	2	4
187	2026-02-06 11:56:07.561976-05	16	Cybersecurity Awareness Resources (/pub/cybersecurity/awareness)	2	Changed Plugin	2	4
188	2026-02-06 11:57:56.107317-05	16	Cybersecurity Awareness Resources (/pub/cybersecurity/awareness)	2	Changed Plugin	2	4
189	2026-02-10 11:08:26.239404-05	3	cms_tester	2	[{"changed": {"fields": ["Groups"]}}]	9	4
190	2026-02-10 11:18:46.888589-05	2	cmser_django	2	[{"changed": {"fields": ["Superuser status", "Groups"]}}]	9	4
191	2026-02-10 11:19:56.247876-05	3	cms_tester	2	[{"changed": {"fields": ["password"]}}]	9	4
192	2026-02-12 13:00:13.848323-05	17	ACCESS Infrastructure Integration (/pub/access-infrastructure-integration)	1	Added Page Translation	2	4
193	2026-02-12 13:00:21.318031-05	17	ACCESS Infrastructure Integration (/pub/access-infrastructure-integration)	2	Changed Page Translation	2	4
194	2026-02-12 13:29:10.695939-05	17	ACCESS Infrastructure Integration (/pub/access-infrastructure-integration)	2	Added Plugin	2	4
195	2026-02-12 13:30:37.270601-05	17	ACCESS Infrastructure Integration (/pub/access-infrastructure-integration)	2	Changed Plugin	2	4
196	2026-02-12 13:31:08.291172-05	17	ACCESS Infrastructure Integration (/pub/access-infrastructure-integration)	2	Changed Plugin	2	4
197	2026-02-12 13:31:54.918036-05	17	ACCESS Infrastructure Integration (/pub/access-infrastructure-integration)	2	Changed Plugin	2	4
198	2026-02-12 13:37:55.778626-05	17	ACCESS Infrastructure Integration (/pub/access-infrastructure-integration)	2	Changed Plugin	2	4
199	2026-02-12 13:46:23.381556-05	17	ACCESS Infrastructure Integration (/pub/access-infrastructure-integration)	2	Changed Plugin	2	4
200	2026-02-12 13:52:45.276761-05	17	ACCESS Infrastructure Integration (/pub/access-infrastructure-integration)	2	Changed Plugin	2	4
201	2026-02-12 13:54:39.709125-05	17	ACCESS Infrastructure Integration (/pub/access-infrastructure-integration)	2	Changed Plugin	2	4
202	2026-02-12 13:59:07.019372-05	17	ACCESS Infrastructure Integration (/pub/access-infrastructure-integration)	2	Changed Plugin	2	4
203	2026-02-12 13:59:57.964991-05	17	ACCESS Infrastructure Integration (/pub/access-infrastructure-integration)	2	Changed Plugin	2	4
204	2026-02-12 14:00:24.09852-05	17	ACCESS Infrastructure Integration (/pub/access-infrastructure-integration)	2	Changed Plugin	2	4
205	2026-02-12 14:03:21.071327-05	17	ACCESS Infrastructure Integration (/pub/access-infrastructure-integration)	2	Changed Plugin	2	4
206	2026-02-12 14:06:08.011692-05	17	ACCESS Infrastructure Integration (/pub/access-infrastructure-integration)	2	Changed Plugin	2	4
207	2026-02-12 15:29:35.308858-05	18	test (/test)	1	Added Page Translation	2	4
208	2026-02-12 15:30:40.25071-05	18	test (/test)	2	[]	2	4
209	2026-02-12 15:30:56.199086-05	18	test (/test)	3	Deleted	2	4
210	2026-02-13 07:43:01.526335-05	12	ACCESS Ticket System FAQs (/pub/ticketing-faqs)	2	Changed Plugin	2	4
211	2026-02-13 07:45:08.96431-05	13	ACCESS Identity Management - Frequently Asked Questions (/pub/identity-faqs)	2	Changed Plugin	2	4
212	2026-02-13 07:58:33.592432-05	13	ACCESS Identity Management - Frequently Asked Questions (/pub/identity-faqs)	2	Changed Plugin	2	4
213	2026-02-13 07:59:28.520927-05	13	ACCESS Identity Management - Frequently Asked Questions (/pub/identity-faqs)	2	Changed Plugin	2	4
214	2026-02-13 08:00:07.763029-05	12	ACCESS Ticket System FAQs (/pub/ticketing-faqs)	2	Changed Plugin	2	4
215	2026-02-16 08:35:13.420743-05	19	Infrastructure Location Map (/pub/infrastructure-location-map)	1	Added Page Translation	2	4
216	2026-02-16 08:51:20.120416-05	19	Infrastructure Location Map (/pub/infrastructure-location-map)	2	Added Plugin	2	4
217	2026-02-16 08:52:16.162471-05	19	Infrastructure Location Map (/pub/infrastructure-location-map)	2	Changed Plugin	2	4
218	2026-02-16 10:12:22.140856-05	20	Infrastructure Maps (/pub/infrastructure-maps)	1	Added Page Translation	2	4
219	2026-02-16 10:12:39.081448-05	20	Infrastructure Maps (/pub/infrastructure-maps)	2	Changed Page Translation	2	4
220	2026-02-16 10:13:55.48332-05	20	Infrastructure Maps (/pub/infrastructure-maps)	2	Added Plugin	2	4
221	2026-02-16 10:16:07.095265-05	20	Infrastructure Maps (/pub/infrastructure-maps)	2	Changed Plugin	2	4
222	2026-02-16 10:17:33.405009-05	20	Infrastructure Maps (/pub/infrastructure-maps)	2	Changed Plugin	2	4
223	2026-02-16 10:22:12.741642-05	20	Infrastructure Maps (/pub/infrastructure-maps)	2	Changed Plugin	2	4
224	2026-02-16 10:23:37.746604-05	20	Infrastructure Maps (/pub/infrastructure-maps)	2	Changed Plugin	2	4
225	2026-02-16 10:24:52.753589-05	21	CONECT Map (/pub/conect_map)	1	Added Page Translation	2	4
226	2026-02-16 10:25:00.855143-05	21	CONECT Map (/pub/conect_map)	2	Changed Page Translation	2	4
227	2026-02-16 10:25:47.016545-05	21	CONECT Map (/pub/conect_map)	2	Added Plugin	2	4
228	2026-02-16 10:30:16.782393-05	20	Infrastructure Maps (/pub/infrastructure-maps)	2	Changed Plugin	2	4
229	2026-02-16 10:30:33.894345-05	21	CONECT Map (/pub/conect-map)	2	Changed Page Translation	2	4
230	2026-02-16 10:32:21.175356-05	21	CONECT Map (/pub/conect-map)	2	Changed Plugin	2	4
231	2026-02-16 10:33:11.846345-05	21	CONECT Map (/pub/conect-map)	2	Changed Plugin	2	4
232	2026-02-16 10:33:56.327546-05	21	CONECT Map (/pub/conect-map)	2	Changed Plugin	2	4
233	2026-02-16 10:56:25.328467-05	22	Infrastructure Timelines (/pub/infrastructure-timelines)	1	Added Page Translation	2	4
234	2026-02-16 10:56:31.662763-05	22	Infrastructure Timelines (/pub/infrastructure-timelines)	2	Changed Page Translation	2	4
235	2026-02-16 10:59:28.985747-05	22	Infrastructure Timelines (/pub/infrastructure-timelines)	2	Added Plugin	2	4
236	2026-02-16 11:02:44.387884-05	23	Infrastructure Production Timeline (/pub/infrastructure-production-timeline)	1	Added Page Translation	2	4
237	2026-02-16 11:02:50.936525-05	23	Infrastructure Production Timeline (/pub/infrastructure-production-timeline)	2	Changed Page Translation	2	4
238	2026-02-16 11:03:36.427663-05	22	Infrastructure Timelines (/pub/infrastructure-timelines)	2	Changed Plugin	2	4
239	2026-02-16 11:05:32.77842-05	23	Infrastructure Production Timeline (/pub/infrastructure-production-timeline)	2	Added Plugin	2	4
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	cms	placeholder
2	cms	page
3	cms	staticplaceholder
4	cms	usersettings
5	cms	pagecontent
6	admin	logentry
7	auth	permission
8	auth	group
9	auth	user
10	contenttypes	contenttype
11	sessions	session
12	sites	site
13	cms	cmsplugin
14	cms	aliaspluginmodel
15	cms	globalpagepermission
16	cms	pagepermission
17	cms	pageuser
18	cms	pageusergroup
19	cms	placeholderreference
20	cms	urlconfrevision
21	cms	pagetype
22	cms	pageurl
23	menus	cachekey
24	djangocmsjoy	accessnews
25	djangocmsjoy	systemstatusnews
26	djangocmsjoy	integrationnews
27	djangocmsjoy	systemstatusnewsitemplugin
28	djangocmsjoy	integrationnewsitemplugin
29	djangocms_text_ckeditor	text
30	djangocms_picture	picture
31	djangocms_file	file
32	djangocms_file	folder
33	djangocms_link	link
34	djangocms_video	videoplayer
35	djangocms_video	videosource
36	djangocms_video	videotrack
37	filer	clipboard
38	filer	folder
39	filer	file
40	filer	clipboarditem
41	filer	thumbnailoption
42	filer	folderpermission
43	filer	image
44	easy_thumbnails	source
45	easy_thumbnails	thumbnail
46	easy_thumbnails	thumbnaildimensions
47	taggit	tag
48	taggit	taggeditem
49	operations_portalcms_django	accessnews
50	operations_portalcms_django	systemstatusnews
51	operations_portalcms_django	integrationnews
52	operations_portalcms_django	integrationnewsitemplugin
53	operations_portalcms_django	systemstatusnewsitemplugin
54	account	emailaddress
55	account	emailconfirmation
56	socialaccount	socialaccount
57	socialaccount	socialapp
58	socialaccount	socialtoken
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2025-12-03 13:41:16.49005-05
2	auth	0001_initial	2025-12-03 13:41:16.577393-05
3	admin	0001_initial	2025-12-03 13:41:16.598267-05
4	admin	0002_logentry_remove_auto_add	2025-12-03 13:41:16.602493-05
5	admin	0003_logentry_add_action_flag_choices	2025-12-03 13:41:16.60603-05
6	contenttypes	0002_remove_content_type_name	2025-12-03 13:41:16.614503-05
7	auth	0002_alter_permission_name_max_length	2025-12-03 13:41:16.61881-05
8	auth	0003_alter_user_email_max_length	2025-12-03 13:41:16.622195-05
9	auth	0004_alter_user_username_opts	2025-12-03 13:41:16.625204-05
10	auth	0005_alter_user_last_login_null	2025-12-03 13:41:16.629652-05
11	auth	0006_require_contenttypes_0002	2025-12-03 13:41:16.630808-05
12	auth	0007_alter_validators_add_error_messages	2025-12-03 13:41:16.634302-05
13	auth	0008_alter_user_username_max_length	2025-12-03 13:41:16.642912-05
14	auth	0009_alter_user_last_name_max_length	2025-12-03 13:41:16.647204-05
15	auth	0010_alter_group_name_max_length	2025-12-03 13:41:16.653702-05
16	auth	0011_update_proxy_permissions	2025-12-03 13:41:16.656715-05
17	auth	0012_alter_user_first_name_max_length	2025-12-03 13:41:16.660263-05
18	sites	0001_initial	2025-12-03 13:41:16.664425-05
19	sites	0002_alter_domain_unique	2025-12-03 13:41:16.673102-05
20	cms	0001_initial	2025-12-03 13:41:16.954271-05
21	cms	0002_auto_20140816_1918	2025-12-03 13:41:17.176876-05
22	cms	0003_auto_20140926_2347	2025-12-03 13:41:17.187071-05
23	cms	0004_auto_20140924_1038	2025-12-03 13:41:17.219011-05
24	cms	0005_auto_20140924_1039	2025-12-03 13:41:17.228895-05
25	cms	0006_auto_20140924_1110	2025-12-03 13:41:17.291167-05
26	cms	0007_auto_20141028_1559	2025-12-03 13:41:17.302021-05
27	cms	0008_auto_20150208_2149	2025-12-03 13:41:17.305402-05
28	cms	0008_auto_20150121_0059	2025-12-03 13:41:17.319894-05
29	cms	0009_merge	2025-12-03 13:41:17.321135-05
30	cms	0010_migrate_use_structure	2025-12-03 13:41:17.338046-05
31	cms	0011_auto_20150419_1006	2025-12-03 13:41:17.348531-05
32	cms	0012_auto_20150607_2207	2025-12-03 13:41:17.365984-05
33	cms	0013_urlconfrevision	2025-12-03 13:41:17.372751-05
34	cms	0014_auto_20160404_1908	2025-12-03 13:41:17.382371-05
35	cms	0015_auto_20160421_0000	2025-12-03 13:41:17.388958-05
36	cms	0016_auto_20160608_1535	2025-12-03 13:41:17.418239-05
37	cms	0017_pagetype	2025-12-03 13:41:17.436806-05
38	cms	0018_pagenode	2025-12-03 13:41:17.500811-05
39	cms	0019_set_pagenode	2025-12-03 13:41:17.549137-05
40	cms	0020_old_tree_cleanup	2025-12-03 13:41:17.618703-05
41	cms	0021_auto_20180507_1432	2025-12-03 13:41:17.622828-05
42	cms	0022_auto_20180620_1551	2025-12-03 13:41:17.628319-05
43	cms	0023_placeholder_source_field	2025-12-03 13:41:17.644869-05
44	cms	0024_set_plugin_absolute_position	2025-12-03 13:41:17.65734-05
45	cms	0025_remove_plugin_tree_fields	2025-12-03 13:41:17.705305-05
46	cms	0026_title_placeholders	2025-12-03 13:41:17.785567-05
47	cms	0027_title_placeholders_data_migration	2025-12-03 13:41:17.799238-05
48	cms	0028_remove_page_placeholders	2025-12-03 13:41:17.811901-05
49	cms	0029_create_title_fields_and_url_model	2025-12-03 13:41:17.883035-05
50	cms	0030_auto_20180810_0629	2025-12-03 13:41:17.897788-05
51	cms	0031_remove_fields	2025-12-03 13:41:17.977947-05
52	cms	0032_remove_title_to_pagecontent	2025-12-03 13:41:18.01572-05
53	cms	0033_placeholder_source_data_migration	2025-12-03 13:41:18.030406-05
54	cms	0034_remove_pagecontent_placeholders	2025-12-03 13:41:18.041513-05
55	cms	0035_auto_20230822_2208	2025-12-03 13:41:18.04691-05
56	cms	0036_auto_20240311_1028	2025-12-03 13:41:18.047706-05
57	cms	0037_merge_page_treenode	2025-12-03 13:41:18.129976-05
58	cms	0038_alter_page_site	2025-12-03 13:41:18.183412-05
59	cms	0039_remove_page_languages_alter_pageurl_unique_together	2025-12-03 13:41:18.209483-05
60	cms	0040_alter_pageuser_created_by_and_more	2025-12-03 13:41:18.235071-05
61	cms	0041_alter_pageurl_unique_together_pageurl_site_and_more	2025-12-03 13:41:18.244495-05
62	menus	0001_initial	2025-12-03 13:41:18.251231-05
63	sessions	0001_initial	2025-12-03 13:41:18.259925-05
64	cms	0018_create_pagenode	2025-12-03 13:41:18.261593-05
65	cms	0035_auto_20230822_2208_squashed_0036_auto_20240311_1028	2025-12-03 13:41:18.262449-05
66	djangocmsjoy	0001_initial	2025-12-03 14:24:52.705979-05
67	djangocmsjoy	0002_rename_news_models	2025-12-03 15:17:34.17547-05
68	djangocmsjoy	0003_remove_accessnews_model	2025-12-03 15:28:35.446611-05
69	djangocmsjoy	0004_integrationnewsitemplugin_systemstatusnewsitemplugin	2025-12-03 16:02:47.101369-05
70	filer	0001_initial	2026-01-28 12:37:03.313738-05
71	filer	0002_auto_20150606_2003	2026-01-28 12:37:03.319481-05
72	filer	0003_thumbnailoption	2026-01-28 12:37:03.320336-05
73	filer	0004_auto_20160328_1434	2026-01-28 12:37:03.321015-05
74	filer	0005_auto_20160623_1425	2026-01-28 12:37:03.322036-05
75	filer	0006_auto_20160623_1627	2026-01-28 12:37:03.322909-05
76	filer	0007_auto_20161016_1055	2026-01-28 12:37:03.323283-05
77	filer	0008_auto_20171117_1313	2026-01-28 12:37:03.323635-05
78	filer	0009_auto_20171220_1635	2026-01-28 12:37:03.323964-05
79	filer	0010_auto_20180414_2058	2026-01-28 12:37:03.324523-05
80	filer	0011_auto_20190418_0137	2026-01-28 12:37:03.32509-05
81	filer	0012_file_mime_type	2026-01-28 12:37:03.325659-05
82	filer	0013_image_width_height_to_float	2026-01-28 12:37:03.3261-05
83	filer	0014_folder_permission_choices	2026-01-28 12:37:03.326543-05
84	filer	0015_alter_file_owner_alter_file_polymorphic_ctype_and_more	2026-01-28 12:37:03.326984-05
85	filer	0016_alter_folder_index_together_remove_folder_level_and_more	2026-01-28 12:37:03.327391-05
86	djangocms_file	0001_initial	2026-01-28 12:37:03.376029-05
87	djangocms_file	0002_auto_20151202_1551	2026-01-28 12:37:03.417489-05
88	djangocms_file	0003_remove_related_name_for_cmsplugin_ptr	2026-01-28 12:37:03.544557-05
89	djangocms_file	0004_set_related_name_for_cmsplugin_ptr	2026-01-28 12:37:03.55629-05
90	djangocms_file	0005_auto_20160119_1534	2026-01-28 12:37:03.560362-05
91	djangocms_file	0006_migrate_to_filer	2026-01-28 12:37:03.592049-05
92	djangocms_file	0007_adapted_fields	2026-01-28 12:37:03.643793-05
93	djangocms_file	0008_add_folder	2026-01-28 12:37:03.676961-05
94	djangocms_file	0009_fixed_null_fields	2026-01-28 12:37:03.691505-05
95	djangocms_file	0010_removed_null_fields	2026-01-28 12:37:03.699779-05
96	djangocms_file	0011_auto_20181211_0357	2026-01-28 12:37:03.711465-05
97	djangocms_file	0012_alter_file_cmsplugin_ptr_alter_folder_cmsplugin_ptr	2026-01-28 12:37:03.739467-05
98	djangocms_link	0001_initial	2026-01-28 12:37:03.810439-05
99	djangocms_link	0002_auto_20140929_1705	2026-01-28 12:37:03.81689-05
100	djangocms_link	0003_auto_20150212_1310	2026-01-28 12:37:03.824376-05
101	djangocms_link	0004_auto_20150708_1133	2026-01-28 12:37:03.889773-05
102	djangocms_link	0005_auto_20151003_1710	2026-01-28 12:37:03.902973-05
103	djangocms_link	0006_remove_related_name_for_cmsplugin_ptr	2026-01-28 12:37:03.936359-05
104	djangocms_link	0007_set_related_name_for_cmsplugin_ptr	2026-01-28 12:37:03.948979-05
105	djangocms_link	0008_link_attributes	2026-01-28 12:37:03.958009-05
106	djangocms_link	0009_auto_20160705_1344	2026-01-28 12:37:03.966722-05
107	djangocms_link	0010_adapted_fields	2026-01-28 12:37:04.042436-05
108	djangocms_link	0011_fixed_null_values	2026-01-28 12:37:04.067561-05
109	djangocms_link	0012_removed_null	2026-01-28 12:37:04.103429-05
110	djangocms_link	0013_fix_hostname	2026-01-28 12:37:04.11197-05
111	djangocms_link	0014_link_file_link	2026-01-28 12:37:04.128463-05
112	djangocms_link	0015_auto_20190621_0407	2026-01-28 12:37:04.136157-05
113	djangocms_link	0016_alter_link_cmsplugin_ptr	2026-01-28 12:37:04.149619-05
114	djangocms_link	0017_link_link	2026-01-28 12:37:04.177362-05
115	djangocms_link	0018_remove_link_anchor_remove_link_external_link_and_more	2026-01-28 12:37:04.235193-05
116	djangocms_link	0019_alter_link_link	2026-01-28 12:37:04.240674-05
117	djangocms_picture	0001_initial	2026-01-28 12:37:04.316399-05
118	djangocms_picture	0002_auto_20151018_1927	2026-01-28 12:37:04.420921-05
119	djangocms_picture	0003_migrate_to_filer	2026-01-28 12:37:04.488124-05
120	djangocms_picture	0004_adapt_fields	2026-01-28 12:37:04.72504-05
121	djangocms_picture	0005_reset_null_values	2026-01-28 12:37:04.748882-05
122	djangocms_picture	0006_remove_null_values	2026-01-28 12:37:04.775637-05
123	djangocms_picture	0007_fix_alignment	2026-01-28 12:37:04.784174-05
124	djangocms_picture	0008_picture_use_responsive_image	2026-01-28 12:37:04.795074-05
125	djangocms_picture	0009_auto_20181212_1003	2026-01-28 12:37:04.83364-05
126	djangocms_picture	0010_auto_20190627_0432	2026-01-28 12:37:04.861295-05
127	djangocms_picture	0011_auto_20190314_1536	2026-01-28 12:37:04.889913-05
128	djangocms_picture	0012_alter_picture_cmsplugin_ptr	2026-01-28 12:37:04.903116-05
129	djangocms_text_ckeditor	0001_initial	2026-01-28 12:37:04.934685-05
130	djangocms_text_ckeditor	0002_remove_related_name_for_cmsplugin_ptr	2026-01-28 12:37:04.954402-05
131	djangocms_text_ckeditor	0003_set_related_name_for_cmsplugin_ptr	2026-01-28 12:37:04.968592-05
132	djangocms_text_ckeditor	0004_auto_20160706_1339	2026-01-28 12:37:04.986131-05
133	djangocms_text_ckeditor	0005_alter_text_cmsplugin_ptr	2026-01-28 12:37:05.001098-05
134	djangocms_video	0001_initial	2026-01-28 12:37:05.038322-05
135	djangocms_video	0002_set_related_name_for_cmsplugin_ptr	2026-01-28 12:37:05.099973-05
136	djangocms_video	0003_field_adaptions	2026-01-28 12:37:05.166781-05
137	djangocms_video	0004_move_to_attributes	2026-01-28 12:37:05.289746-05
138	djangocms_video	0005_migrate_to_filer	2026-01-28 12:37:05.304968-05
139	djangocms_video	0006_field_adaptions	2026-01-28 12:37:05.394316-05
140	djangocms_video	0007_create_nested_plugin	2026-01-28 12:37:05.457166-05
141	djangocms_video	0008_reset_null_values	2026-01-28 12:37:05.47104-05
142	djangocms_video	0009_removed_null_values	2026-01-28 12:37:05.480536-05
143	djangocms_video	0010_videoplayer_parameters	2026-01-28 12:37:05.491763-05
144	djangocms_video	0011_alter_videoplayer_cmsplugin_ptr_and_more	2026-01-28 12:37:05.531193-05
145	easy_thumbnails	0001_initial	2026-01-28 12:37:05.618988-05
146	easy_thumbnails	0002_thumbnaildimensions	2026-01-28 12:37:05.647067-05
147	filer	0017_image__transparent	2026-01-28 12:37:05.655756-05
148	filer	0018_alter_file_options	2026-01-28 12:37:05.664552-05
149	taggit	0001_initial	2026-01-28 12:37:05.726512-05
150	taggit	0002_auto_20150616_2121	2026-01-28 12:37:05.733332-05
151	taggit	0003_taggeditem_add_unique_index	2026-01-28 12:37:05.742684-05
152	taggit	0004_alter_taggeditem_content_type_alter_taggeditem_tag	2026-01-28 12:37:05.769005-05
153	taggit	0005_auto_20220424_2025	2026-01-28 12:37:05.771967-05
154	taggit	0006_rename_taggeditem_content_type_object_id_taggit_tagg_content_8fc721_idx	2026-01-28 12:37:05.781519-05
155	filer	0001_squashed_0016_alter_folder_index_together_remove_folder_level_and_more	2026-01-28 12:37:05.783277-05
156	operations_portalcms_django	0001_initial	2026-01-28 16:25:47.464569-05
157	operations_portalcms_django	0002_rename_news_models	2026-01-28 16:25:47.524237-05
158	operations_portalcms_django	0003_remove_accessnews_model	2026-01-28 16:25:58.465648-05
159	operations_portalcms_django	0004_integrationnewsitemplugin_systemstatusnewsitemplugin	2026-01-28 16:25:58.473532-05
160	operations_portalcms_django	0005_alter_integrationnews_table_and_more	2026-01-28 16:25:58.474425-05
161	account	0001_initial	2026-01-30 08:54:16.983813-05
162	account	0002_email_max_length	2026-01-30 08:54:17.009046-05
163	account	0003_alter_emailaddress_create_unique_verified_email	2026-01-30 08:54:17.032877-05
164	account	0004_alter_emailaddress_drop_unique_email	2026-01-30 08:54:17.179748-05
165	account	0005_emailaddress_idx_upper_email	2026-01-30 08:54:17.206315-05
166	account	0006_emailaddress_lower	2026-01-30 08:54:17.233413-05
167	account	0007_emailaddress_idx_email	2026-01-30 08:54:17.254588-05
168	account	0008_emailaddress_unique_primary_email_fixup	2026-01-30 08:54:17.280992-05
169	account	0009_emailaddress_unique_primary_email	2026-01-30 08:54:17.291931-05
170	socialaccount	0001_initial	2026-01-30 08:54:17.455014-05
171	socialaccount	0002_token_max_lengths	2026-01-30 08:54:17.476633-05
172	socialaccount	0003_extra_data_default_dict	2026-01-30 08:54:17.484459-05
173	socialaccount	0004_app_provider_id_settings	2026-01-30 08:54:17.516092-05
174	socialaccount	0005_socialtoken_nullable_app	2026-01-30 08:54:17.539355-05
175	socialaccount	0006_alter_socialaccount_extra_data	2026-01-30 08:54:17.594758-05
176	operations_portalcms_django	0006_alter_systemstatusnews_options_and_more	2026-02-03 12:30:13.131775-05
177	operations_portalcms_django	0007_alter_systemstatusnews_options_and_more	2026-02-06 14:22:48.628876-05
178	operations_portalcms_django	0008_alter_systemstatusnews_start_datetime	2026-02-06 14:22:48.640688-05
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
2eo4q0usy3m5oskljkofdgmjcfitt125	eyJjbXNfdG9vbGJhcl9kaXNhYmxlZCI6ZmFsc2V9:1vniBn:iu0H95zj8NCWxxcWHjGDCs2tbYMgwD1lBpMM_R_r6lg	2026-02-18 14:05:23.924633-05
l6t3tun7vbcwenl0jr4y2tkvrzfko3rz	.eJxVkd1OwzAMhd8l1zA1tF3T3bFNgguYxo-ACaHISZw2rKw0yegA7d1JoKBxk8Sfj61j55Nw2Pqabx1abhSZEEqODpkAucZNTKhn2FTtSLYbb40YRcloyLrRZauwmQ7afw1qcHWoHitGC8jGdCwzxkRGmUxPUJeJUgzyRKaMlWV5UmQyE1TkQhVpyfJCq5wipLkOTXvzAVbx4ZIWwSN_M9iTySdxHl8H9_HJFXiIPImHdFa_GKUa7MGib4NLMnkkV3d9XZnzUpizRXd5-zZfP6y62bxKlm1RsXp6vUtPxWJ6try_6XA-u1it1rL3Su8aukiXXUee_kwduDmWW2tx4_mPpcdgIeiS41eoMIb0J2zCNrcDCna-Waiy7xEUFBCAQaZTVCLXNNGiAKAqAS0ZSJonRU7HQJ72-2FgbRp0vxNHijtv4XcPEcgXx33bNgIsV8aBaDD8q4bG4f4LYn2tUA:1vQuM8:_k9dIi96YUDw5HpWrNMVfotPshJ0zFzWg-WOkPpmtvU	2025-12-17 16:25:48.496675-05
kwe8h45imfmawxsuffn9oh9x3kfzygsr	.eJxVjEEOgjAQRe_StWmmTAuDS_eegXQ6U4saSCisjHdXEha6_e-9_zJD3NYybFWXYRRzNo05_W4c00OnHcg9TrfZpnlal5HtrtiDVnudRZ-Xw_07KLGWb80gBIDBYdt1kB1ppj4jaoDGZVIV8cRZWg4JOEDyHogxIlPvu9ib9wfRvDej:1vfiMi:S74_G1MbXcAEsrYWO2V-vrgHC8I3e5sfrrYT8ZWyHFI	2026-01-27 12:39:36.353516-05
ywhgq5s6rwjv3um2a2vox2z2kl597irb	.eJxVkttuGyEQht-F68QCdlkc3zmurFpVUlfKTRNFaIBhvSrejYCND5HfvZBsqvQGZr458A_wRhSMaafGiEF1lixITa6-Mg3mD_YlAN4XPANjhrFPs_ecKRxny-xhnzoDqRv626nqv1Y7iLvcR1dzQS2rGsFpXTfAKiMbLi1l3IITFEU2RN3IWkPl-I21XIJBLQSvjeZNbnrozhCsmjYTEBKq1w4PZPFGYsKXfAzLecVUFhIUTstiYnD7zlqPBwiYhqySLJ6I29X6x5H9Do-r5tH6n8c2zqvbdlhvQZ621a_2Ybu-_y5X62-vmz0_m7vlajkGvtmwrTsdzkie_4n6oubajCHkS1Efkp6yhJxHr1-gxeJ-eB76dpxIVvPOclE4FSAZIMAcaleh1cIx6rQEYJaCM3MwTFApWAPk-XKZ5nWdx_g5cKF4TAE-r6EAs48qDYPXEJTtImiP-YEd-IhXpJQH5SEm5QZvp2_Rj95f_gKWCrs8:1vs16R:bRvUiDPhSaM1z-_9hdVC9M2IJ_FiveMrdVahewpeU2s	2026-03-02 11:05:39.319762-05
ni2opv8xuibpnewgzf3riqqyjmnhaabl	eyJjbXNfdG9vbGJhcl9kaXNhYmxlZCI6ZmFsc2V9:1vo5wX:K4PMfL_s7SvbJlpldeQ9xc32_d7WiFEehQ1eDPxgrng	2026-02-19 15:27:13.667937-05
fobr3hjp34ac5wk6r1r83501xd6vjiee	.eJxVjsEOgjAQRP-lZ9MstIXi0bvf0Ox2t4JWmlA4Gf9dSDzodd7My7xUwG0dw1ZlCROrs2rV6TcjjA-ZD8B3nG9FxzKvy0T6qOgvrfpaWPLl2_0TjFjHfU3AHsC4xnR9D6nxkvyQjBEHbZO8CLP1lLgjF4EcRGvBk0FDfrA9Drs0PmtYS8mES-CpImXZfyXMVd4fvTxChA:1vnztU:M2rQBzPm6UjnW6DQM1DERNtd3XI5Hee-Gn7Zp1pATdU	2026-02-19 08:59:40.746481-05
hewvuvild8jnsh7x30515pqlos35t4g1	eyJjbXNfdG9vbGJhcl9kaXNhYmxlZCI6ZmFsc2V9:1vnzwx:P6_vZWxeJVsc1J0HNOPx2DKkuNatN_TBYoIigzvU8AI	2026-02-19 09:03:15.029555-05
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_site (id, domain, name) FROM stdin;
1	https://operations.access-ci.org/	https://operations.access-ci.org/
\.


--
-- Data for Name: djangocms_file_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_file_file (cmsplugin_ptr_id, file_name, link_target, link_title, file_src_id, attributes, template, show_file_size) FROM stdin;
\.


--
-- Data for Name: djangocms_file_folder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_file_folder (template, link_target, show_file_size, attributes, cmsplugin_ptr_id, folder_src_id) FROM stdin;
\.


--
-- Data for Name: djangocms_link_link; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_link_link (cmsplugin_ptr_id, name, target, attributes, template, link) FROM stdin;
\.


--
-- Data for Name: djangocms_picture_picture; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_picture_picture (cmsplugin_ptr_id, link_url, alignment, link_page_id, height, width, picture_id, attributes, caption_text, link_attributes, link_target, use_automatic_scaling, use_crop, use_no_cropping, use_upscale, thumbnail_options_id, external_picture, template, use_responsive_image) FROM stdin;
5	\N		\N	\N	\N	2	{}	\N	{}		t	f	f	f	\N	\N	default	inherit
7	\N		\N	\N	\N	3	{}	\N	{}		t	f	f	f	\N	\N	default	inherit
26	\N		\N	\N	\N	7	{}	\N	{}		t	f	f	f	\N	\N	default	inherit
31	\N		\N	\N	\N	11	{}	\N	{}		t	f	f	f	\N	\N	default	inherit
55	\N		\N	\N	\N	14	{}	\N	{}		t	f	f	f	\N	\N	default	inherit
\.


--
-- Data for Name: djangocms_text_ckeditor_text; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_text_ckeditor_text (cmsplugin_ptr_id, body) FROM stdin;
3	<p>Home</p>
4	<p><cms-plugin alt="Image - unnamed file " title="Image - unnamed file" id="5"></cms-plugin></p>
6	<p><cms-plugin alt="Image - unnamed file " title="Image - unnamed file" id="7"></cms-plugin></p>
9	<p>This  program is intended for undergraduates who are interested in pursuing careers in cyberinfrastructure! Our goal is to provide students with exposure to these careers in an effort to grow the cyberinfrastructure workforce.</p>
56	<div class="row">\n<h1 class="visually-hidden">Timelines</h1>\n\n<h2 class="col-12 p-3">Resource Timelines</h2>\n\n<div class="col-12 p-3 pt-0">\n<ul class="list-unstyled m-0">\n\t<li class="d-flex flex-column flex-md-row align-items-start gap-4 py-2"><img alt="Infrastructure Production Timeline (Google Spreadsheet)" class="img-fluid border" src="/static/operations_portalcms_django/img/infrastructure_production_timeline_google_spreadsheet.png" style="width: 200px; height: 200px;">\n\t<div class="pt-md-4"><a class="btn btn-link p-0" href="https://docs.google.com/spreadsheets/d/1aYESkVFTNlf0f5-N5ygYzX2ewfLZbVaALP43WxGNpEg/edit#gid=911396958" rel="noopener noreferrer" target="_blank">Infrastructure Production Timeline (Google Spreadsheet) </a></div>\n\t</li>\n</ul>\n</div>\n\n<div class="col-12 p-3 pt-0">\n<ul class="list-unstyled m-0">\n\t<li class="d-flex flex-column flex-md-row align-items-start gap-4 py-2"><img alt="Infrastructure Production Timeline (Web App)" class="img-fluid border" src="/static/operations_portalcms_django/img/infrastructure_production_timeline.png" style="width: 200px; height: 200px;">\n\t<div class="pt-md-4"><a class="btn btn-link p-0" href="/pub/infrastructure-production-timeline/">Infrastructure Production Timeline (Web App) </a></div>\n\t</li>\n</ul>\n</div>\n</div>
8	<h3>General Information about the Student Training and Engagement Program (STEP)</h3>
57	<div class="container py-3">\n  <iframe class="w-100 border-0" style="height: 600px;" src="https://access-ci-org.github.io/step-2023-shared-webapps-library/dist/#/timeline" title="Infrastructure Production Timeline">\n  </iframe>\n</div>
27	<div class="container">\n<div class="row">\n<div class="col-md">\n<p style="text-align: center;">The Operational Support team coordinates the integration and operations of RP, ACCESS project, and community infrastructure. We work with other ACCESS projects to define, document, and support infrastructure integration and operation procedures. We provide and operate several software tools and services that enable the seamless integration, maintenance, and support of ACCESS infrastructure.</p>\n</div>\n\n<div class="col-md" style="text-align: center;"><cms-plugin alt="Image - unnamed file " title="Image - unnamed file" id="31"></cms-plugin></div>\n</div>\n</div>
32	<div class="row bg-light">\n<h2 class="col-lg-12 p-3">Operational Support focuses primarily on the following areas.</h2>\n\n<div class="col-lg-12 p-3 pt-0">\n<ul>\n\t<li><span style="color: #000000;">ACCESS wide coordinated infrastructure integration</span></li>\n\t<li><span style="color: #000000;">Supporting resource providers, ACCESS projects, and community services developers integrating into ACCESS</span></li>\n\t<li><span style="color: #000000;">Provide operational services like: ticketing system; infrastructure description, discovery, and status services; and operator and developer facing infrastructure documentation</span></li>\n</ul>\n</div>\n</div>
33	<h3>Services</h3>
13	<div class="row">\n<h2 class="col-lg-12 p-3">Eligibility criteria</h2>\n\n<div class="col-lg-12 p-3 pt-0">\n<p>All students who apply to STEP must be:</p>\n\n<ul>\n\t<li>At least 18 years of age by the start date of the program</li>\n\t<li>Students attending US-based institutions</li>\n\t<li>Enrolled in a degree program (part-time or full-time) leading to a baccalaureate or associate degree or master's degree*</li>\n\t<li>In good academic standing at their college or university</li>\n\t<li>\n\t<p>Available to participate for the full program for which the student is applying</p>\n\n\t<p>*For international students, STEP-1, 2 or 3 may be considered curricular practical training (CPT) by your home institution; it is your responsibility to comply with your home institution's policies and immigration regulations pertaining to your legal status. Please work with your home institution on determining eligibility and any required paperwork.</p>\n\t</li>\n</ul>\n\n<p><strong>Additional criteria/information</strong></p>\n\n<ul>\n\t<li>Some experience with Python is desired as well as some UNIX/Linux</li>\n</ul>\n</div>\n\n<h2 class="col-lg-12 p-3">Program Requirements</h2>\n\n<div class="col-lg-12 p-3 pt-0">\n<ul>\n\t<li>All STEP participants should participate for the full length program for which they were accepted</li>\n\t<li>STEP-2 participants will participate in program activities up to 40 hours a week (i.e. working with team members on projects, attending program-wide activities, professional development seminars/events, and other engagements)</li>\n\t<li>STEP-3 participants will participate in program activities ~10 hours a week (i.e. working with team members on projects, attending program-wide activities, professional development seminars, and other engagements)</li>\n\t<li>STEP-2 and STEP-3 participants will write a report about their program/project activities</li>\n\t<li>STEP-2 and STEP-3 participants will give an oral presentation about their program/project activities during the STEP experience</li>\n\t<li>STEP participants may be asked to assist in further recruitment efforts at their respective schools</li>\n\t<li>\n\t<p>During certain portions of STEP,  on-campus activities may be required; housing during these portions of the program will be provided and arranged by the STEP coordinator</p>\n\n\t<p>*For international students, your home institution may have additional requirements for participation depending on your home institution's policies and immigration regulations pertaining to your legal status. Please work with your home institution on determining any such requirements</p>\n\t</li>\n</ul>\n</div>\n\n<h2 class="col-lg-12 p-3">Important Dates</h2>\n\n<div class="col-lg-12 p-3 pt-0">\n<ul>\n\t<li>Online application: Due February 1, 2026</li>\n\t<li>Program dates:\n\t<ul>\n\t\t<li>STEP-1: May/June 2026 (on Florida International University main campus); dates are May 26 - June 5, 2026</li>\n\t\t<li>STEP-2: June/July 2026 (on University of Illinois, Urbana-Champaign campus), late July/August 2026 (remote + conference attendance); dates June 9 - August 7, 2026</li>\n\t\t<li>STEP-3: Starting between August 15 - September 1, 2026 ending April 30, 2027</li>\n\t</ul>\n\t</li>\n</ul>\n</div>\n\n<h2 class="col-lg-12 p-3">Acceptance</h2>\n\n<div class="col-lg-12 p-3 pt-0">\n<ul>\n\t<li>Offers of acceptance will go out by email on a periodic, rolling basis. After the acceptance review process is complete, the remaining applicants will be notified by email.</li>\n\t<li>Once the program offer is accepted, a STEP participant should complete the portion of the STEP program they were accepted for and meet the program requirements.</li>\n</ul>\n\n<p> </p>\n\n<h2>Other Important Information</h2>\n\n<ul>\n\t<li>For international students, this may be considered Curricular Practical Training (CPT) by your institution. It is your responsibility to comply with your home institution's policies and immigration regulations pertaining to your legal status. Please work with your home institution to determine eligibility and complete and required paperwork. Additionally, per United States government regulations, payments to international participants may have a 30% income tax deduction applied. Each individual is responsible for filing an income tax return with the US government. If you have questions about taxes or tax filing, please consult a tax accountant/expert. </li>\n</ul>\n</div>\n</div>
23	<p style="text-align: center;"><cms-plugin alt="Image - unnamed file " title="Image - unnamed file" id="26"></cms-plugin></p>
34	<div class="row">\n\n\n<div class="col-lg-6 col-md-6 col-sm-6 pb-3">\n<div class="bg-dark text-light p-5 h-100">\n<h3><span style="color: #48c0b9;">Ticket System</span></h3>\n\n<p>Enables researchers, RPs, ACCESS staff, and community developer to submit requests.</p>\n\n<div class="pt-3">\n<h4><span style="color: #ffffff;">Links</span></h4>\n\n<ul class="list-unstyled">\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="/online_services/ticket_system">Ticketing System</a></li>\n</ul>\n</div>\n</div>\n</div>\n\n<div class="col-lg-6 col-md-6 col-sm-6 pb-3">\n<div class="bg-dark text-light p-5 h-100">\n<h3><span style="color: #48c0b9;">Infrastructure Integration</span></h3>\n\n<p>Coordinated integration of ACCESS infrastructure</p>\n\n<div class="pt-3">\n<h4><span style="color: #ffffff;">Links</span></h4>\n\n<ul class="list-unstyled">\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="/pub/access-infrastructure-integration">New infrastructure integration </a></li>\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="/resources/access-allocated">Already integrated infrastructure </a></li>\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="/pub/concierge_integration_experts">Concierge Integration Experts </a></li>\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="/online_services/integration_news">Integration News </a></li>\n</ul>\n</div>\n</div>\n</div>\n\n<div class="col-lg-6 col-md-6 col-sm-6 pb-3">\n<div class="bg-dark text-light p-5 h-100">\n<h3><span style="color: #48c0b9;">Infrastructure Description and Status</span></h3>\n\n<p>Software consumable infrastructure description and status information.</p>\n\n<div class="pt-3">\n<h4><span style="color: #ffffff;">Links</span></h4>\n\n<ul class="list-unstyled">\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="https://cider.access-ci.org/">CyberInfrastructure Description Repository (CiDeR) </a></li>\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="https://github.com/access-ci-org/ipf">Compute Information Publishing Framework (IPF) </a></li>\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="/software_discovery">Software Discovery </a></li>\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="/online_services/infrastructure_news">Infrastructure News and outages </a></li>\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="/online_services/operations_api">Infrastructure Discovery Operations APIs </a></li>\n</ul>\n</div>\n</div>\n</div>\n\n<div class="col-lg-6 col-md-6 col-sm-6 pb-3">\n<div class="bg-dark text-light p-5 h-100">\n<h3><span style="color: #48c0b9;">Reliable Operations</span></h3>\n\n<p>Tools for reliable infrastructure management and operations</p>\n\n<div class="pt-3">\n<h4><span style="color: #ffffff;">Links</span></h4>\n\n<ul class="list-unstyled">\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="/online_services/monitoring_service">Monitoring Service (Nagios) </a></li>\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="/online_services/central_logging">Central Logging Service (Syslog) </a></li>\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="/online_services/service_index">Services Index Catalog </a></li>\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="/online_services/usage_tracking">Service Usage Metrics </a></li>\n</ul>\n</div>\n</div>\n</div>\n\n<div class="col-lg-6 col-md-6 col-sm-6 pb-3">\n<div class="bg-dark text-light p-5 h-100">\n<h3><span style="color: #48c0b9;">Development tools</span></h3>\n\n<p>Collaborative tools and services for ACCESS operators and developers</p>\n\n<div class="pt-3">\n<h4><span style="color: #ffffff;">Links</span></h4>\n\n<ul class="list-unstyled">\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="https://operations.access-ci.org/online_services/source_repository">ACCESS Source Code Repository </a></li>\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="https://readthedocs.access-ci.org/en/latest/">ACCESS ReadTheDocs </a></li>\n    <li><a class="btn btn-link pb-3" style="color: #FFC42D;" href="https://readthedocs.access-ci.org/projects/toolkits/en/latest/">ACCESS Toolkits</a></li>\n</ul>\n</div>\n</div>\n</div>\n</div>
41	<div class="row">\n<div class="col-lg-12 p-3">\n<h2>ACCESS Operations CyberSecurity Activities</h2>\n</div>\n\n<div class="col-lg-6 pb-3">\n<div class="bg-dark text-light p-5 h-100">\n<h3><span style="color: #48c0b9;">Security Incident Management</span></h3>\n\n<p><span style="color: #ffffff;">Managing security incident with ACCESS affiliated partners.  <br>\n<br>\nThe ACCESS Incident Response Trust Group (AIRTG) includes representatives from ACCESS cybersecurity staff, ACCESS Resource Providers (RPs), and members of the broader cybersecurity community in Research and Education. This group monitors current events and threats, and collaborates to respond to incidents when they occur.</span></p>\n\n<div class="pt-3">\n<h4><span style="color: #ffffff;">Links</span></h4>\n\n<p><a class="btn btn-link pb-3" href="https://access-ci.atlassian.net/servicedesk/customer/portal/3/group/5/create/26">Report a Security Incident</a> </p>\n</div>\n</div>\n</div>\n\n<div class="col-lg-6 pb-3">\n<div class="bg-dark p-5 h-100">\n<h3><span style="color: #ffffff;">CyberSecurity Policies and Procedures</span></h3>\n\n<p><span style="color: #ffffff;">Cybersecurity policies and procedures with ACCESS affiliated partners.  <br>\n<br>\nThe ACCESS Cybersecurity Governance Council (CGC) includes representatives from each ACCESS project track, to develop and review ACCESS-wide cybersecurity policies and procedures. Cybersecurity policies and procedures go into effect once they are approved by the ACCESS Executive Council (EC) .</span></p>\n\n<div class="pt-3">\n<h4><span style="color: #ffffff;">Links</span></h4>\n\n<p> <a class="btn btn-link pb-3" href="https://access-ci.org/acceptable-use/">ACCESS Acceptable Use Policy</a>   <br>\n <a class="btn btn-link pb-3" href="https://access-ci.org/privacy-policy">ACCESS Privacy Policy</a></p>\n</div>\n</div>\n</div>\n\n<div class="col-lg-6 pb-3">\n<div class="bg-dark p-5 h-100">\n<h3><span style="color: #ffffff;">Identity and Access Management (IAM) Services</span></h3>\n\n<p><span style="color: #ffffff;">Tools and services to manage identities, and to securely authenticate and authorize access to protected resources.</span></p>\n\n<div class="pt-3">\n<h4><span style="color: #ffffff;">Links</span></h4>\n\n<p><a class="btn btn-link pb-3" href="https://identity.access-ci.org/">Identity and Access Management (IAM)</a>   <br>\n<a class="btn btn-link pb-3" href="https://registry.access-ci.org"> User Identity Dashboard (COmanage)</a></p>\n</div>\n</div>\n</div>\n\n<div class="col-lg-6 pb-3">\n<div class="bg-dark p-5 h-100">\n<h3><span style="color: #ffffff;">Cybersecurity Awareness</span></h3>\n\n<p><span style="color: #ffffff;">Online resources for the ACCESS community about cybersecurity.</span></p>\n\n<div class="pt-3">\n<h4><span style="color: #ffffff;">Links</span></h4>\n\n<p><a class="btn btn-link pb-3" href="/pub/cybersecurity/awareness">Resources for Researchers, ACCESS Resource Providers, and more</a></p>\n</div>\n</div>\n</div>\n</div>
45	<div class="row">\n<div class="col-lg-12 p-3">\n<h2>Services</h2>\n</div>\n\n<div class="col-lg-6 pb-3">\n<div class="bg-dark text-light p-5 h-100">\n<h3><span style="color: #48c0b9;">CONECTnet</span></h3>\n\n<p><span style="color: #ffffff;">ACCESS wide area network connectivity for RPs is via a Layer3 VPN (L3VPN) provisioned on Internet2, the national research and education (R&amp;E) network backbone provider. The NDTS team is available to facilitate RP integration with CONECTnet upon request.</span></p>\n\n<div class="pt-3">\n<h4><span style="color: #ffffff;">Links</span></h4>\n\n<ul class="list-unstyled">\n\t<li><a class="btn btn-link pb-3" href="https://drive.google.com/file/d/1Jw0x2f0J2CUYyXgc74f1efL3DSBBi23C/view">CONECTnet map</a></li>\n</ul>\n</div>\n</div>\n</div>\n\n<div class="col-lg-6 pb-3">\n<div class="bg-dark text-light p-5 h-100">\n<h3><span style="color: #48c0b9;">Globus</span></h3>\n\n<p><span style="color: #ffffff;">High-performance and reliable data transfer services</span></p>\n\n<div class="pt-3">\n<h4><span style="color: #ffffff;">Links</span></h4>\n\n<ul class="list-unstyled">\n\t<li><a class="btn btn-link pb-3" href="https://readthedocs.access-ci.org/projects/integration-roadmaps/en/latest/tasks/Deploy_Globus_Endpoint_v1.html">Deploy a Globus Endpoint</a></li>\n\t<li><a class="btn btn-link pb-3" href="https://access-ci.atlassian.net/wiki/spaces/ACCESSdocumentation/pages/467110548/Using+Globus">Using Globus Documentation</a></li>\n\t<li><a class="btn btn-link pb-3" href="https://app.globus.org/file-manager">Use the Globus Service</a></li>\n</ul>\n</div>\n</div>\n</div>\n\n<div class="col-lg-6 pb-3">\n<div class="bg-dark text-light p-5 h-100">\n<h3><span style="color: #48c0b9;">DNS Services</span></h3>\n\n<p><span style="color: #ffffff;">access-ci.org DNS along with xsede.org and teragrid.org legacy DNS</span></p>\n\n<div class="pt-3">\n<h4><span style="color: #ffffff;">Links</span></h4>\n\n<ul class="list-unstyled">\n\t<li><a class="btn btn-link pb-3" href="https://docs.google.com/document/d/1BJAAyedAKp3uhN1cu884p3NtBe216DazY8an3E7mcb4/edit">ACCESS PowerDNS Documentation</a></li>\n</ul>\n</div>\n</div>\n</div>\n\n<div class="col-lg-6 pb-3">\n<div class="bg-dark text-light p-5 h-100">\n<h3><span style="color: #48c0b9;">RP Network Connectivity Optimization</span></h3>\n\n<p><span style="color: #ffffff;">Resource provider end-to-end network and data transfer performance consultation</span></p>\n\n<div class="pt-3">\n<h4><span style="color: #ffffff;">Links</span></h4>\n\n<ul class="list-unstyled">\n\t<li><a class="btn btn-link pb-3" href="https://docs.google.com/document/d/1UgvfjECgB0XaAIM0cscZQZVXp0nU4bQST6sCqIgAld8/edit?usp=sharing">ACCESS CONECT - CONECTnet Site Survey</a></li>\n\t<li><a class="btn btn-link pb-3" href="https://docs.google.com/document/d/1utXWz7wCIIAQgtZ5w_ER_zppdgl0lwmZ2pGmv70T9cI/edit?usp=sharing">Connectivity Optimization</a></li>\n\t<li><a class="btn btn-link pb-3" href="http://pd.access-ci.org/maddash-webui/index.cgi?dashboard=ACCESS%20CONECTnet%20perfSONAR">CONECTnet perfSONAR Dashboard</a></li>\n</ul>\n</div>\n</div>\n</div>\n\n\n</div>
36	<div class="container-fluid">\n<h1 class="mb-4">ACCESS Identity Management - Frequently Asked Questions</h1>\n\n<div class="organization-section mb-4">\n<h2 class="organization-header">For Users</h2>\n\n<div class="accordion accordion-flush" id="accordion1">\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_1_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_1" data-bs-toggle="collapse" type="button">Can I use my existing XSEDE account with ACCESS?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_1">\n<div class="accordion-body">Yes, your ACCESS ID is the same as your XSEDE Portal account. Please do not create a new ACCESS ID. You do not need to change your password or your Duo registration during the transition from XSEDE to ACCESS.</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_2_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_2" data-bs-toggle="collapse" type="button">Which identity provider should I choose when logging in?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_2">\n<div class="accordion-body">\n<p>Select the "ACCESS CI" identity provider to log in with your ACCESS/XSEDE username and password.</p>\n\n<p>If you would like to log in to ACCESS using an identity provider other than "ACCESS CI", you need to link your identity from that other identity provider with your ACCESS ID. Please proceed to the <a href="https://identity.access-ci.org/id-linking">identity linking</a> page for details.</p>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_3_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_3" data-bs-toggle="collapse" type="button">How do I log out?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_3">\n<div class="accordion-body">\n<p>Please visit <a href="https://cilogon.org/logout">https://cilogon.org/logout</a> to log out of your CILogon session.</p>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_4_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_4" data-bs-toggle="collapse" type="button">How do I clear or reset my CILogon browser cookies?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_4">\n<div class="accordion-body">\n<p>If you are having trouble logging in, it may help to click the "Delete ALL" button at <a href="https://cilogon.org/me/">https://cilogon.org/me/</a> to reset your CILogon browser cookies, then try again to log in.</p>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_5_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_5" data-bs-toggle="collapse" type="button">How do I view information about my authenticated identity?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_5">\n<div class="accordion-body">\n<p>Visit <a href="https://cilogon.org/me/">https://cilogon.org/me/</a> to view the "Session Variables" associated with your authenticated identity, including your selected identity provider.</p>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_6_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_6" data-bs-toggle="collapse" type="button">I forgot my ACCESS username. Can I get a reminder?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_6">\n<div class="accordion-body">\n<p>Yes, visit <a href="https://identity.access-ci.org/username-reminder">https://identity.access-ci.org/username-reminder</a> to request a username reminder by email.</p>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_7_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_7" data-bs-toggle="collapse" type="button">I forgot my ACCESS password. Can I reset it?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_7">\n<div class="accordion-body">\n<p>Yes, visit <a href="https://identity.access-ci.org/password-reset">https://identity.access-ci.org/password-reset</a> to reset your ACCESS password.</p>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_8_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_8" data-bs-toggle="collapse" type="button">I'm having trouble with Duo. How do I update my Duo configuration?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_8">\n<div class="accordion-body">\n<p>Please visit <a href="https://identity.access-ci.org/manage-mfa">https://identity.access-ci.org/manage-mfa</a> for instructions on managing your Duo configuration for ACCESS.</p>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_9_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_9" data-bs-toggle="collapse" type="button">Why doesn't my university appear in the list of identity providers?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_9">\n<div class="accordion-body">\n<p>ACCESS uses identity providers from CILogon. Please visit <a href="https://www.cilogon.org/faq">https://www.cilogon.org/faq</a> for details.</p>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_10_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_10" data-bs-toggle="collapse" type="button">How do I change the organization listed in my ACCESS profile?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_10">\n<div class="accordion-body">\n<p>Please <a href="https://support.access-ci.org/open-a-ticket">open a ticket</a> to request the change.</p>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_11_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_11" data-bs-toggle="collapse" type="button">I accidentally created multiple ACCESS IDs. Can I merge them?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_11">\n<div class="accordion-body">\n<p>Yes, please <a href="https://support.access-ci.org/open-a-ticket">open a ticket</a> indicating which ACCESS ID you want to continue using and which one(s) you want marked as duplicate.</p>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_12_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_12" data-bs-toggle="collapse" type="button">I'm having trouble logging in to an ACCESS Resource Provider. How can I get assistance?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_12">\n<div class="accordion-body">\n<p>Please review <a href="https://access-ci.atlassian.net/wiki/x/n4qyBw">ACCESS RP Documentation</a> for login details and support contacts for each resource provider.</p>\n\n<p>If you're not able to get assistance directly from the resource provider, please <a href="https://support.access-ci.org/open-a-ticket">open a ticket</a> with ACCESS.</p>\n</div>\n</div>\n</div>\n</div>\n</div>\n\n<div class="organization-section mb-4">\n<h2 class="organization-header">For Admins</h2>\n\n<div class="accordion accordion-flush" id="accordion2">\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_2_1_header"><button class="accordion-button collapsed" data-bs-target="#collapse_2_1" data-bs-toggle="collapse" type="button">Can I configure my web application to require authentication using the ACCESS CI Identity Provider (IdP)?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion2" id="collapse_2_1">\n<div class="accordion-body">\n<p>By default, when you <a href="https://identity.access-ci.org/register-app">register your web application</a>, ACCESS users will be able to log in using any identity provider supported by CILogon that is linked to their ACCESS ID, and the resulting id_token will contain the user's ACCESS ID (i.e., "sub": "username@access-ci.org"). This is the recommended configuration, because it allows users to log in without needing an ACCESS-specific username and password.</p>\n\n<p>However, if you want to require authentication using the ACCESS CI IdP (e.g., to require ACCESS multi-factor authentication), please contact <strong>help@cilogon.org</strong> to request this configuration to be applied to your client. Include your registered client_id in your request.</p>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_2_2_header"><button class="accordion-button collapsed" data-bs-target="#collapse_2_2" data-bs-toggle="collapse" type="button">What is the ACCESS "Named Configuration"?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion2" id="collapse_2_2">\n<div class="accordion-body">\n<p>When you register an OIDC client with the ACCESS COmanage Registry, it is recommended you use a Named Configuration for "ACCESS OIDC client configuration v1". This configuration does the following:</p>\n\n<ul>\n\t<li>Registers the following <a href="https://www.cilogon.org/oidc#h.p_PEQXL8QUjsQm">scopes</a>: openid, email, profile, org.cilogon.userinfo</li>\n\t<li>Verifies that OIDC client transactions request the org.cilogon.userinfo scope</li>\n\t<li>Checks that the user has an ACCESS account. If so, asserts "username@access-ci.org" in the "sub" claim. If not, redirects the user to an appropriate error page.</li>\n\t<li>Checks if the user is in the "AccessDenied" group. If so, redirects the user to an appropriate error page.</li>\n</ul>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_2_3_header"><button class="accordion-button collapsed" data-bs-target="#collapse_2_3" data-bs-toggle="collapse" type="button">Why does my OIDC client not show the ACCESS "skin" (i.e., CSS) when authenticating?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion2" id="collapse_2_3">\n<div class="accordion-body">\n<p>There is a server-side configuration which automatically applies the <a href="https://cilogon.org/?skin=access">ACCESS skin</a> for OIDC clients with a redirect_uri in the access-ci.org domain. This skin changes the CSS for the "Select an Identity Provider" page, and also selects "ACCESS CI" as the initial IdP for new visitors to the site. However, your OIDC client might have a redirect_uri in some other domain. In this case, the ACCESS "skin" would not be applied. To fix this, please contact <strong>help@cilogon.org</strong> with your registered client_id and request that the ACCESS "skin" be applied to your client.</p>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_2_4_header"><button class="accordion-button collapsed" data-bs-target="#collapse_2_4" data-bs-toggle="collapse" type="button">Can I get a mapping from CILogon DNs to ePPN values to help with the GCSv4 to GCSv5 transition?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion2" id="collapse_2_4">\n<div class="accordion-body">\n<p>Yes, please send a list of DNs to help@cilogon.org, and the CILogon team can provide the mapping.</p>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_2_5_header"><button class="accordion-button collapsed" data-bs-target="#collapse_2_5" data-bs-toggle="collapse" type="button">Why does my OIDC client require users to re-authenticate so frequently?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion2" id="collapse_2_5">\n<div class="accordion-body">\n<p>If you are using <a href="https://github.com/zmartzone/mod_auth_openidc">mod_auth_openidc</a>, please be sure to configure OIDCSessionInactivityTimeout. Visit <a href="https://www.cilogon.org/oidc#h.p_1_IG_eaP90Ty">https://www.cilogon.org/oidc#h.p_1_IG_eaP90Ty</a> for details.</p>\n\n<p>You may also need to enable Refresh Tokens in your web app registration.</p>\n</div>\n</div>\n</div>\n</div>\n</div>\n\n<div class="organization-section">\n<h2 class="organization-header">Related FAQs</h2>\n\n<div class="p-3"><a class="resource-link" href="/pub/ticketing-faqs/">ACCESS Ticketing</a></div>\n</div>\n</div>
35	<div class="container-fluid">\n<h1 class="mb-4">ACCESS Ticket System - Frequently Asked Questions</h1>\n\n<div class="organization-section mb-4">\n<h2 class="organization-header">For Community Members</h2>\n\n<div class="accordion accordion-flush" id="accordion1">\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_1_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_1" data-bs-toggle="collapse" type="button">Can I use my existing XSEDE account with ACCESS?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_1">\n<div class="accordion-body">Yes, your ACCESS ID is the same as your XSEDE Portal account. Please do not create a new ACCESS ID. You do not need to change your password or your Duo registration during the transition from XSEDE to ACCESS.</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_2_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_2" data-bs-toggle="collapse" type="button">What will be different for me?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_2">\n<div class="accordion-body">The interface to the system will look different but will function similarly to the old system. Key upgrades include the ability to easily find answers to your questions with the search capabilities.</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_3_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_3" data-bs-toggle="collapse" type="button">Is a login required to submit a ticket?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_3">\n<div class="accordion-body">\n<p>Yes, this is current practice. Researchers and other community members will still be directed to login to access the ticket request functionality.</p>\n\n<p>If you cannot login (e.g. need password reset), there is a separate contact page where you can request assistance.</p>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_4_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_4" data-bs-toggle="collapse" type="button">Can I still access my current/active tickets?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_4">\n<div class="accordion-body">Yes, once the new system is accepting new tickets there will be a transition period of 2-3 weeks when all issues are expected to be resolved and the tickets closed.</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_1_5_header"><button class="accordion-button collapsed" data-bs-target="#collapse_1_5" data-bs-toggle="collapse" type="button">What will happen if I respond to an old ticket?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion1" id="collapse_1_5">\n<div class="accordion-body">After the transition period, you will need to create a new ticket for all issues.</div>\n</div>\n</div>\n</div>\n</div>\n\n<div class="organization-section mb-4">\n<h2 class="organization-header">For Resource Providers</h2>\n\n<div class="accordion accordion-flush" id="accordion2">\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_2_1_header"><button class="accordion-button collapsed" data-bs-target="#collapse_2_1" data-bs-toggle="collapse" type="button">When will JSM be accepting new tickets?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion2" id="collapse_2_1">\n<div class="accordion-body">We are planning for a "soft opening" starting the week of March 13, 2023 with all new tickets going to JSM by the end of the month.</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_2_2_header"><button class="accordion-button collapsed" data-bs-target="#collapse_2_2" data-bs-toggle="collapse" type="button">Is a login required to submit a ticket?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion2" id="collapse_2_2">\n<div class="accordion-body">\n<p>Yes, this is current practice. Researchers and other community members will still be directed to login to access the ticket request functionality.</p>\n\n<p>We are working on a separate form for Resource Providers and ACCESS staff.</p>\n\n<p>If a community member cannot login (e.g. need password reset), there is a separate <a href="https://registry.access-ci.org/registry/krb_authenticator/krbs/ssr/authenticatorid:1">contact page</a> where they can request assistance.</p>\n</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_2_3_header"><button class="accordion-button collapsed" data-bs-target="#collapse_2_3" data-bs-toggle="collapse" type="button">How long will ACCESS RT be available to access old tickets?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion2" id="collapse_2_3">\n<div class="accordion-body">ACCESS RT will be available to close out active tickets for approximately two weeks following the transition where new tickets are created in JSM.</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_2_4_header"><button class="accordion-button collapsed" data-bs-target="#collapse_2_4" data-bs-toggle="collapse" type="button">Can we move old tickets to JSM?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion2" id="collapse_2_4">\n<div class="accordion-body">We cannot do a bulk ingest of old tickets into JSM but we will be leaving ACCESS RT available in read-only format for 3-6 months.</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_2_5_header"><button class="accordion-button collapsed" data-bs-target="#collapse_2_5" data-bs-toggle="collapse" type="button">Will ACCESS RT ticket metrics be available to us for reporting?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion2" id="collapse_2_5">\n<div class="accordion-body">Yes, we will provide certain metrics to RPs needing them; this may include metrics number of tickets, average response time, etc.</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_2_6_header"><button class="accordion-button collapsed" data-bs-target="#collapse_2_6" data-bs-toggle="collapse" type="button">Will there be a transition document?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion2" id="collapse_2_6">\n<div class="accordion-body">Yes, we are working on this now.</div>\n</div>\n</div>\n\n<div class="accordion-item">\n<h3 class="accordion-header" id="collapse_2_7_header"><button class="accordion-button collapsed" data-bs-target="#collapse_2_7" data-bs-toggle="collapse" type="button">JSM is an Atlassian product. I have an account already, what do I do?</button></h3>\n\n<div class="accordion-collapse collapse" data-bs-parent="#accordion2" id="collapse_2_7">\n<div class="accordion-body">If you already have an Atlassian account and wish to use the email associated with that account, please provide it. If you do not have an Atlassian account, we will add you to Atlassian (using the email provided to us for accessing ACCESS RT) and then add you onto the project.</div>\n</div>\n</div>\n</div>\n</div>\n\n<div class="organization-section">\n<h2 class="organization-header">Related FAQs</h2>\n\n<div class="p-3"><a class="resource-link" href="/pub/identity-faqs">ACCESS Identity Management</a></div>\n</div>\n</div>
37	<div class="container">\n<div class="layout layout--onecol">\n<div class="layout__region layout__region--content">\n<div class="block block-layout-builder block-field-blocknodepeople-facing-informationbody">\n<div class="clearfix text-formatted field field--name-body field--type-text-with-summary field--label-hidden field__item">\n<div class="row bg-light text-dark">\n<div class="col-md-6 p-5 ">\n<h1 class="mb-5">What is ACCESS Operations?</h1>\n</div>\n\n<div class="col-md-6 p-5">\n<p>ACCESS Operations is provided by the CONECT project. CONECT (COre National Ecosystem for CyberinfrasTructure) delivers innovative integrations across the NSF-funded cyberinfrastructure ecosystem in the areas of operations, data and networking, and cybersecurity. CONECT uses agile mechanisms to integrate the rapidly diversifying set of non-traditional resources that previously have been left on the fringes of the national cyberinfrastructure.</p>\n</div>\n</div>\n\n<div class="row">\n<div class="pt-5 pb-5 bg-white text-black w-100">\n<h1 class="visually-hidden-focusable">About</h1>\n\n<h2>Eco-system wide integration</h2>\n\n<p>ACCESS Operations is provided by the CONECT project. CONECT (COre National Ecosystem for CyberinfrasTructure) delivers innovative integrations across the NSF-funded cyberinfrastructure ecosystem in the areas of operations, data and networking, and cybersecurity. CONECT uses agile mechanisms to integrate the rapidly diversifying set of non-traditional resources that previously have been left on the fringes of the national cyberinfrastructure. CONECT builds upon the successes of its predecessors and moves toward a more agile, dynamic, and inclusive ecosystem.</p>\n\n<h2 class="mt-5">Framework based approach</h2>\n\n<p>CONECT introduces and coordinates a framework-based approach to ecosystem-wide integration using step-by-step integration roadmaps and modular concepts that enable entirely new kinds of cyberinfrastructure resources to fully participate in the coordinated national cyberinfrastructure. Integral to this new approach is the Information Sharing Platform for sharing cyberinfrastructure integration and operations information between people, while also enabling cyberinfrastructure components to discover and securely access integrated resources and other components; increased network reliability enabled by expanded metrics insights and availability; opportunities for more control over data transfer such as transfer scheduling and network programmability; new Cybersecurity Governance Council and coordination groups; modern authentication strategies and technologies; and focus on broad protection of ACCESS resources through the sharing of cybersecurity threat intelligence.</p>\n\n<h2 class="mt-5">Community wide engagement</h2>\n\n<p>To further community engagement, education, and training efforts, CONECT hosts the Student Training and Engagement Program (STEP) that provides students with training on marketable skills in the areas of operations, data and networking, and cybersecurity. CONECT STEP will promote the development of a diverse, competitive STEM workforce by providing opportunities to students, with a focus on recruiting and enrolling students from underrepresented groups. Through these shared efforts, CONECT will democratize participation in the cyberinfrastructure ecosystem, deliver more value at all layers of the service and support stack, and enable the entire ACCESS program to achieve success in advancing cyberinfrastructure that adopts new thinking and transformative discoveries in all areas of science and engineering research and education.</p>\n</div>\n</div>\n</div>\n</div>\n</div>\n</div>\n</div>
12	<h2 class="col-lg-12 p-3"><span style="color: #48c0b9;">Step 1: 2-week introductory experience</span></h2>\n\n<div class="col-lg-12 p-3 pt-0">\n<p>Join us for a dynamic two-week experience in Miami, FL in May! We cover your travel, provide accommodations, and give you a stipend. This program is designed to help you:</p>\n\n<ul>\n\t<li>Become more aware of the many areas of interest within the field: front-end development/software engineering for high performance computing systems, cybersecurity, networking.</li>\n\t<li>Determine where your interests are.</li>\n\t<li>Discover what areas of study you should pursue in the future.</li>\n\t<li>Experience high levels of direct interaction with knowledgeable cyberinfrastructure professionals with diverse skill sets.</li>\n</ul>\n</div>\n\n<h2 class="col-lg-12 p-3"><span style="color: #48c0b9;">STEP-2: Full-time for the summer</span></h2>\n\n<div class="col-lg-12 p-3 pt-0">\n<p>STEP-2  follows STEP-1. STEP-2 is a full-time summer program* (in-person + virtual) where you will participate in projects in web programming, software engineering for high performance computing systems, cybersecurity, networking. We cover travel, accommodations for in-person events, provide a stipend for participating, plus take you to a national conference. This program is designed to help you:</p>\n\n<ul>\n\t<li>Develop an intermediate understanding of one of the areas of interest within the field: front-end development/software engineering for high performance computing systems and services, cybersecurity, advanced networking.</li>\n\t<li>Provide opportunities for interactions with professionals in the field.</li>\n</ul>\n\n<h3><span style="color: #48c0b9;">Example Projects</span>:</h3>\n\n<ul>\n\t<li>Students in cybersecurity will work with CONECT cybersecurity professionals to help protect ACCESS’s CI – a highly complex and heterogeneous environment that is constantly under attack–by managing vulnerabilities, analyzing security log data, and performing security vetting tasks.</li>\n\t<li>Students in operations will create and monitor the information sharing platform technology stack, create web applications, and use and develop APIs to push information to various platforms (e.g., Ask.CI, etc.).</li>\n\t<li>Students in networking  learn networking best practices, Linux systems management, testing methodologies, software defined networking projects, and identification and resolution of networking performance issues.</li>\n</ul>\n</div>\n\n<h2 class="col-lg-12 p-3"><span style="color: #48c0b9;">STEP-3: Part-time during the school year</span></h2>\n\n<div class="col-lg-12 p-3 pt-0">\n<p>STEP-3 follows STEP-2. You will continue interacting (virtually) with your team on projects on a part-time basis during the academic year. Participants will receive a stipend and we will also take you to the annual Supercomputing (SC) conference. This program is designed to help you:</p>\n\n<ul>\n\t<li>Develop a deep understanding of one of the areas of interest within the field: front-end development/software engineering for high performance computing systems, cybersecurity, networking.</li>\n\t<li>Provide further opportunities for interactions with professionals in the field.</li>\n\t<li>Understand how a career in cyberinfrastructure could fit with your future plans!</li>\n</ul>\n<a class="btn btn-warning" href="https://forms.gle/FL12DvV7aM5qyBzd6">Apply here</a></div>
38	<div class="row p-5">\n<h1 class="col-lg-12 p-3">ACCESS Integration and Operations Help</h1>\n\n<p class="col-lg-12 p-3">ACCESS integration and operations questions can be submitted through the ticket system, or more informally discussed through Slack or semi-weekly ACCESS-RP integration coordination meetings.</p>\n\n<div class="col-lg-4 col-md-4 col-sm-6 p-3 h-100">\n<h2 class="w-100 text-center" style="height: 80px;">Integration and Operations Requests</h2>\n\n<p class="w-100 overflow-auto" style="height: 300px;">If you are an ACCESS RP, ACCESS central service provider, or ACCESS affiliated infrastructure provider and need help integrating or interoperating in the ACCESS environment please open an ACCESS Operations Request. These request are handled by all the ACCESS projects. You can also submit questions about how to become one of these.</p>\n\n<p><a class="btn btn-warning w-100" href="https://access-ci.atlassian.net/servicedesk/customer/portal/2/group/3/create/32">Open an Operations Request</a></p>\n</div>\n\n<div class="col-lg-4 col-md-4 col-sm-6 p-3 h-100">\n<h2 class="w-100 text-center" style="height: 80px;">Report a Security Incident</h2>\n\n<p class="w-100 overflow-auto" style="height: 300px;">If your ACCESS ID or ACCESS integrated infrastructure was compromised, please report an ACCESS Security Incident.</p>\n\n<p><a class="btn btn-warning w-100" href="https://access-ci.atlassian.net/servicedesk/customer/portal/3/group/5/create/26">Report a Security Incident</a></p>\n</div>\n\n<div class="col-lg-4 col-md-4 col-sm-6 p-3 h-100">\n<h2 class="w-100 text-center" style="height: 80px;">Ad-Hoc Discussion</h2>\n\n<p class="w-100 overflow-auto" style="height: 300px;">ACCESS offers a Slack space and a by-weekly ACCESS-RP meeting where operators and ACCESS can discuss integration and operations topics. To request access to these resources please open an Operations Request with issue type "ACCESS-wide: Provider Integration - Infrastructure Integration and Roadmaps"</p>\n\n<p><a class="btn btn-warning w-100" href="https://access-ci.atlassian.net/servicedesk/customer/portal/2/group/3/create/32">Open an Operations Request</a></p>\n</div>\n</div>\n\n<div class="row bg-light p-5">\n<h1 class="col-lg-12 p-3">Documentation and Community Help</h1>\n\n<p class="col-lg-12 p-3">ACCESS is part of a community of resource providers, online service providers, and developers building and operating distributed cyberinfrastructure. Please explore the following resources if you have general questions about integrating and operating research infrastructure.</p>\n\n<div class="col-lg-6 col-md-6 col-sm-6 p-3 h-100">\n<div class="w-100 text-center pb-2"><img alt="Documentation" src="/static/operations_portalcms_django/img/community_support_icon_documentation.png" style=""></div>\n\n<h2 class="w-100 text-center" style="height: 80px;">Infrastructure Integration Documentation</h2>\n\n<p class="w-100 text-center overflow-auto" style="height: 150px;">ACCESS projects document how to integrate and operate infrastructure into the ACCESS environment. Individual Integration Roadmap documents provide step by step instructions for integrating specific types of infrastructure.</p>\n\n<p><a class="w-100 btn btn-warning" href="/pub/access-infrastructure-integration">Visit Infrastructure Integration Documentation</a></p>\n</div>\n\n<div class="col-lg-6 col-md-6 col-sm-6 p-3 h-100">\n<div class="w-100 text-center pb-2"><img alt="Knowledge Base" src="/static/operations_portalcms_django/img/community_support_icon_knowledge_base.png" style=""></div>\n\n<h2 class="w-100 text-center" style="height: 80px;">ACCESS Knowledge Base</h2>\n\n<p class="w-100 overflow-auto" style="height: 150px;">The ACCESS Knowledge Base includes ACCESS resource and services documentation, Ask.CI community Q&amp;A forums, Crowd-source information, and Community Affinity Groups for exploring common infrastructure integration and operations topics.</p>\n\n<p><a class="w-100 btn btn-warning" href="https://support.access-ci.org/knowledge-base/">Visit ACCESS Knowledge Base</a></p>\n</div>\n\n<div class="col-lg-6 col-md-6 col-sm-6 p-3 h-100">\n<div class="w-100 text-center pb-2"><img alt="Campus Champions" src="/static/operations_portalcms_django/img/community_support_icon_campuschampions.png" style=""></div>\n\n<h2 class="w-100 text-center" style="height: 80px;">Campus Champions</h2>\n\n<p class="w-100 overflow-auto" style="height: 150px;">Campus Champions fosters a dynamic environment for a diverse community of research computing and data professionals sharing knowledge and experience in digital research infrastructure.</p>\n\n<p><a class="w-100 btn btn-warning" href="https://campuschampions.cyberinfrastructure.org/">Visit Campus Champions</a></p>\n</div>\n\n<div class="col-lg-6 col-md-6 col-sm-6 p-3 h-100">\n<div class="w-100 text-center pb-2"><img alt="ACCESS Toolkits" src="/static/operations_portalcms_django/img/community_support_icon_crowd_source.png" style=""></div>\n\n<h2 class="w-100 text-center" style="height: 80px;">ACCESS Toolkits</h2>\n\n<p class="w-100 overflow-auto" style="height: 150px;">Here, you'll find descriptions and documentation for the various toolkits we provide to computational resource providers and users.</p>\n\n<p><a class="w-100 btn btn-warning" href="https://readthedocs.access-ci.org/projects/toolkits/en/latest/">Visit ACCESS Toolkits</a></p>\n</div>\n</div>
43	<h2 class="col-lg-12 p-3"><span style="color: #48c0b9;">NDTS focuses primarily on the following areas:</span></h2>\n\n<div class="col-lg-12 p-3">\n<ul>\n\t<li>Network Architecture and Data Transfer Services</li>\n\t<li>Network performance Metrics</li>\n\t<li>Cyberinfrastructure Community Engagement</li>\n</ul>\n</div>
42	<div class="row">\n<h1 class="visually-hidden">Data &amp; Networking</h1>\n\n<div class="col-md-6 p-3 lead">The ACCESS Networking and Data Transfer Services (NDTS) team provides the CONECTnet ACCESS wide area network and provides efficient and resilient data transfer capability across the ACCESS ecosystem. The team also seeks to identify new data transfer and networking technologies and methodologies for potential introduction into the ACCESS ecosystem.</div>\n\n<div class="col-md-6 p-3">\n<div class="w-100" style="height: 200px;"><img src="/static/operations_portalcms_django/img/banner_data_and_networking.png" alt="Data and Networking Banner" class="img-fluid w-100" style="">\n</div>\n</div>\n</div>
40	<div class="row">\n<div class="col-md-6 p-3 lead">Cybersecurity Support works with ACCESS RPs and Tracks to develop and maintain policies, procedures, services, operational support and incident management capabilities to protect the security of the ACCESS cyberinfrastructure (CI) and ensure that it is a safe, secure, and trustworthy shared CI ecosystem.</div>\n\n<div class="col-md-6 p-3">\n<img src="/static/operations_portalcms_django/img/banner_cybersecurity.png" alt="Cybersecurity Banner" class="img-fluid w-100" style="">\n</div>\n</div>
46	<div class="col-lg-12 p-3">\n<p>Administration of XSEDE's high-speed Internet2 overlay network, XSEDEnet, was transitioned to NDTS as the team began working with Internet2 on the XSEDEnet to CONECTnet transition. NDTS agreed to continue with an L3VPN architecture and, in cooperation with Internet2, requested that Internet2 create a new ACCESS OESS workgroup for provisioning the infrastructure, providing a more adaptive and well managed administration approach for CONECTnet. Migration to CONECTnet is in progress with the ACCESS resource providers, and from the view-point of the RPs, the transition is seamless. Support for Globus file transfer continues through the first year of ACCESS operations ending 31-Aug-2023, with documentation and help made available to users for Globus Connect Server 5.4.</p>\n</div>
39	<div class="row bg-light">\n<h1 class="visually-hidden">Cybersecurity</h1>\n\n<div class="col-lg-4 p-5 text-center"><a class="btn btn-primary mt-5" href="https://access-ci.atlassian.net/servicedesk/customer/portal/3/group/5/create/26">Report a Security Incident</a></div>\n\n<div class="col-lg-8 p-5">\n<p>Has your identity been stolen?  <br>\nHas your password been stolen?  <br>\nDid your computer become infected with malware or spyware?  <br>\nHas someone else been using your ACCESS ID or ACCESS Resource Provider account?</p>\n\n<p><strong>Please report a security incident immediately so that we can help to protect your ACCESS accounts and data as soon as possible. </strong></p>\n</div>\n</div>
47	<div class="container">\n<div class="row">\n<div class="col-lg-6 pb-3">\n<div class="bg-dark text-light p-5 h-100">\n<h3><span style="color: #48c0b9;">For Researchers</span></h3>\n\n<p><span style="color: #ffffff;">Resources and training for cybersecurity research and awareness.</span></p>\n\n<div class="pt-3">\n<h4><span style="color: #ffffff;">Links</span></h4>\n\n<ul class="list-unstyled">\n<li><a class="btn btn-link pb-3" href="https://seedsecuritylabs.org/labs.html?utm_medium=email&amp;utm_source=govdelivery">NSF-funded SEED Labs</a></li>\n<li><a class="btn btn-link pb-3" href="https://new.nsf.gov/eng/updates/nsf-research-security-training-modules-now-available">NSF Research Security Training Modules</a></li>\n<li><a class="btn btn-link pb-3" href="https://new.nsf.gov/focus-areas/cybersecurity">NSF Funding for Cybersecurity Research</a></li>\n</ul>\n</div>\n</div>\n</div>\n\n<div class="col-lg-6 pb-3">\n<div class="bg-dark text-light p-5 h-100">\n<h3><span style="color: #48c0b9;">For ACCESS Resource Providers</span></h3>\n\n<p><span style="color: #ffffff;">Security frameworks and implementation guides for resource providers.</span></p>\n\n<div class="pt-3">\n<h4><span style="color: #ffffff;">Links</span></h4>\n\n<ul class="list-unstyled">\n<li><a class="btn btn-link pb-3" href="https://www.trustedci.org/guide-overview">Trusted CI Framework Implementation Guide Overview</a></li>\n</ul>\n</div>\n</div>\n</div>\n</div>\n\n<div class="row">\n<div class="col-lg-12 p-3">\n<h2>More Resources</h2>\n</div>\n\n<div class="col-lg-12 p-3">\n<ol>\n<li><a href="https://www.sans.org/security-resources/glossary-of-terms/">SANS Glossary of Cybersecurity Terms</a></li>\n<li><a href="https://new.nsf.gov/funding/opportunities/satc-secure-trustworthy-cyberspace?utm_medium=email&amp;utm_source=govdelivery">The CISE-led Secure and Trustworthy Cyberspace (SaTC) program</a></li>\n<li><a href="https://blog.trustedci.org/">NSF Cybersecurity Center of Excellence (Trusted CI) Blog</a></li>\n<li><a href="https://www.sans.org/mlp/ssa-2024-security-awareness-report/?utm_medium=CPC&amp;utm_source=Google&amp;utm_content=Global_Security_Awareness_KWs&amp;utm_campaign=Security_Awareness_Report_2024&amp;utm_rdetail=Global&amp;utm_goal=Leads&amp;utm_type=SSA&amp;gad_source=1&amp;gclid=Cj0KCQiA0MG5BhD1ARIsAEcZtwQ3tN84Ty0hPo41d04vEvHs33kmMC5XjPrfyAAjNptJDD20oJ61V6caAmpTEALw_wcB">Internet Security Awareness Training (SANS)</a></li>\n<li><a href="https://www.cisa.gov/resources-tools/resources/cisa-cybersecurity-awareness-program-toolkit">Cybersecurity Awareness Program Toolkit (NICE)</a></li>\n<li><a href="https://www.cisa.gov/topics/cybersecurity-best-practices">CISA: Cybersecurity Best Practices</a></li>\n<li><a href="https://www.dhs.gov/publications-library/cybersecurity">Homeland Security: Cybersecurity</a></li>\n<li><a href="https://www.dhs.gov/archive/science-and-technology/cybersecurity-resources">Homeland Security: Cybersecurity Resource Archive</a></li>\n<li><a href="https://csrc.nist.gov/pubs/sp/800/223/final">NIST SP 800-223: HPC Security: Architecture, Threat Analysis, and Security Posture</a></li>\n</ol>\n</div>\n</div>\n</div>
48	<div class="container">\n<div class="row">\n<div class="col-md-6 p-3 lead">\n<p>ACCESS uses an <em>Integration Roadmaps Framework</em> to define how operators can integrate classes of infrastructure into the ACCESS environment to achieve a defined operational status. This framework defines, for example, how HPC compute clusters can achieve the ACCESS allocated operational status, and will also be used to define how many new classes of emerging infrastructure can integrated to achieve ACCESS allocated, un-allocated, discoverable, or other statuses.</p>\n</div>\n\n<div class="col-md-6 p-3">\n<div class="w-100" style="height: 300px;"><img alt="Integration Roadmap" src="/static/operations_portalcms_django/img/banner_integration_road_map.jpg" style="display: block; width: 100%; height: 100%;"></div>\n</div>\n</div>\n\n<div class="row">\n<h2 class="col-lg-12 p-3">Additional Information</h2>\n\n<div class="pt-2 pb-2"><a class="btn btn-primary" href="https://access-ci.org/get-started/for-resource-providers/">ACCESS RP Landing Page</a> <a class="btn btn-primary" href="https://dashboard.operations.access-ci.org/IntegrationBadgesUI/organizations/">ACCESS Integration Dashboard</a></div>\n\n<h2 class="col-lg-12 p-3">Existing ACCESS Infrastructure Classes</h2>\n\n<p class="col-lg-12 p-3">ACCESS has defined Integration Roadmaps for the following classes of infrastructure:</p>\n\n<div class="col-lg-6 pb-3">\n<div class="bg-light text-dark p-5 h-100">\n<p><img alt="High-Performance Computing" height="90" src="/static/operations_portalcms_django/img/integration_icon_compute.png" width="125"></p>\n\n<h3>High-Performance Computing</h3>\n\n<p>High-performance computing clusters (<a href="https://en.wikipedia.org/wiki/High-performance_computing">definition</a>) are used by logging in to front-end nodes, installing application software, and running batch computing jobs under a scheduler. These compute resources may include GPUs, and always provide some tightly coupled local storage.</p>\n\n<div class="pt-3">\n<h4>Integration options (roadmaps):</h4>\n\n<ul class="list-unstyled">\n\t<li><a class="btn btn-link" href="https://operations-api.access-ci.org/wh2/integration_badges/v1/roadmap_review/67/">ACCESS Allocated Compute</a></li>\n</ul>\n</div>\n</div>\n</div>\n\n<div class="col-lg-6 pb-3">\n<div class="bg-light text-dark p-5 h-100">\n<p><img alt="Storage" height="90" src="/static/operations_portalcms_django/img/integration_icon_storage.png" width="129"></p>\n\n<h3>Storage</h3>\n\n<p>Storage resources are used to store and manage large amounts of data.</p>\n\n<div class="pt-3">\n<h4>Integration options (roadmaps):</h4>\n\n<ul class="list-unstyled">\n\t<li><a class="btn btn-link" href="https://operations-api.access-ci.org/wh2/integration_badges/v1/roadmap_review/68/">ACCESS Allocated Storage</a></li>\n</ul>\n</div>\n</div>\n</div>\n\n<div class="col-lg-6 pb-3">\n<div class="bg-light text-dark p-5 h-100">\n<p><img alt="Cloud Infrastructure" height="90" src="/static/operations_portalcms_django/img/integration_icon_cloud.png" width="125"></p>\n\n<h3>Cloud Infrastructure</h3>\n\n<p>Cloud infrastructure is used by launching and running virtual machines or containers.</p>\n\n<div class="pt-3">\n<h4>Integration options (roadmaps):</h4>\n\n<ul class="list-unstyled">\n\t<li><a class="btn btn-link" href="https://operations-api.access-ci.org/wh2/integration_badges/v1/roadmap_review/34/">ACCESS Allocated Cloud</a></li>\n</ul>\n</div>\n</div>\n</div>\n\n<div class="col-lg-6 pb-3">\n<div class="bg-light text-dark p-5 h-100">\n<p><img alt="Science Gateways" height="90" src="/static/operations_portalcms_django/img/integration_icon_science_gateways.png" width="131"></p>\n\n<h3>Science Gateways</h3>\n\n<p>Websites / portals where researchers can run high-level computational science applications without having to directly interact with low level compute, storage, or cloud resources or request ACCESS allocations. These resources will typically allow the researcher to select their input and output datasets, select and configure the application they want to run, and then run that application for the researcher using compute, storage, and/or cloud resources that have been pre-configured for executing science gateway applications</p>\n\n<div class="pt-3">\n<h4>Integration options (roadmaps):</h4>\n\n<ul class="list-unstyled">\n\t<li><a class="btn btn-link" href="https://operations-api.access-ci.org/wh2/integration_badges/v1/roadmap_review/1/">ACCESS Science Gateway</a></li>\n</ul>\n</div>\n</div>\n</div>\n</div>\n</div>
50	<article>\n<div class="container py-4"><iframe class="w-100" src="https://access-ci-org.github.io/step-2023-shared-webapps-library/dist/#/location-map" style="height: 600px;" title="Infrastructure Location Map"></iframe></div>\n</article>
52	<p><cms-plugin alt="Image - unnamed file " title="Image - unnamed file" id="55"></cms-plugin></p>
51	<div class="row">\n<h1 class="visually-hidden">Infrastructure Maps</h1>\n\n<h2 class="col-12 p-3">Resource Maps</h2>\n\n<div class="col-12 p-3 pt-0">\n<ul class="list-unstyled m-0">\n\t<li class="d-flex flex-column flex-md-row align-items-start gap-4 py-2"><img alt="ACCESS Allocations Resource Map" class="img-fluid border" src="/static/operations_portalcms_django/img/infrastructure-maps-allocations.png" style="width: 200px; height: 200px;">\n\t<div class="pt-md-4"><a class="btn btn-link p-0" href="https://allocations.access-ci.org/geo#3.4/38.88/-111.01">ACCESS Allocations Resource Map </a></div>\n\t</li>\n</ul>\n</div>\n\n<div class="col-12 p-3 pt-0">\n<ul class="list-unstyled m-0">\n\t<li class="d-flex flex-column flex-md-row align-items-start gap-4 py-2"><img alt="Infrastructure Location Map" class="img-fluid border" src="/static/operations_portalcms_django/img/infrastructure_location_map_1.png" style="width: 200px; height: 200px;">\n\t<div class="pt-md-4"><a class="btn btn-link p-0" href="/pub/infrastructure-location-map/">Infrastructure Location Map </a></div>\n\t</li>\n</ul>\n</div>\n\n<h2 class="col-12 p-3">Network Maps</h2>\n\n<div class="col-12 p-3 pt-0">\n<ul class="list-unstyled m-0">\n\t<li class="d-flex flex-column flex-md-row align-items-start gap-4 py-2"><img alt="CONECTnet Map" class="img-fluid border" src="/static/operations_portalcms_django/img/infrastructure-maps-conectnet.png" style="width: 200px; height: 200px;">\n\t<div class="pt-md-4"><a class="btn btn-link p-0" href="/pub/conect-map/">CONECTnet Map </a></div>\n\t</li>\n</ul>\n</div>\n</div>
\.


--
-- Data for Name: djangocms_video_videoplayer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_video_videoplayer (cmsplugin_ptr_id, embed_link, poster_id, attributes, label, template, parameters) FROM stdin;
\.


--
-- Data for Name: djangocms_video_videosource; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_video_videosource (cmsplugin_ptr_id, text_title, text_description, attributes, source_file_id) FROM stdin;
\.


--
-- Data for Name: djangocms_video_videotrack; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.djangocms_video_videotrack (cmsplugin_ptr_id, kind, srclang, label, attributes, src_id) FROM stdin;
\.


--
-- Data for Name: easy_thumbnails_source; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.easy_thumbnails_source (id, storage_hash, name, modified) FROM stdin;
1	0d677af76ca5bf5575d614e04932c3a4	filer_public/9e/f6/9ef6629f-57c9-4a91-9293-58e0dd1258f0/055c0e6e-ed27-48bc-a8b1-957cd77add1e.jpg	2026-02-03 15:21:33.526414-05
2	0d677af76ca5bf5575d614e04932c3a4	filer_public/6f/12/6f1270f8-4510-4042-9ba1-9b6dad0ee369/8eaa31c0-1672-4e33-902e-63ee3824a0fe.jpg	2026-02-03 15:32:34.367974-05
3	0d677af76ca5bf5575d614e04932c3a4	filer_public/b5/e8/b5e81f42-d18e-4fda-a915-988f0cefcab6/262f3a4c-a905-44f1-b0db-18cbd93def2a.png	2026-02-03 15:44:40.18245-05
4	0d677af76ca5bf5575d614e04932c3a4	filer_public/a4/b6/a4b65354-308d-47aa-87bc-58423db9d312/step-collage-2024.jpg	2026-02-04 14:31:14.831042-05
5	0d677af76ca5bf5575d614e04932c3a4	filer_public/5a/55/5a558f61-9caf-4822-aa93-abf723fd66dc/ee13f35b-2d02-4a39-b58e-e12dbb198c20.jpg	2026-02-04 14:39:05.928023-05
6	0d677af76ca5bf5575d614e04932c3a4	filer_public/88/de/88ded3ef-30e4-407f-8ec5-acee6391c2a4/8d57f2f0-e0ae-4aa4-acd6-718db8e152a7.jpg	2026-02-04 14:50:42.196591-05
8	0d677af76ca5bf5575d614e04932c3a4	filer_public/ca/c0/cac02a70-e94c-4f99-a857-c9110346146d/e59a160b-a70b-4ba6-9744-d73fd8edc161.png	2026-02-04 17:06:17.249988-05
9	0d677af76ca5bf5575d614e04932c3a4	filer_public/25/25/25253139-c3fd-49b1-b544-afdc3f74267a/3139125a-fe2e-4822-a0e9-01eb5349cd91.png	2026-02-04 17:10:23.845646-05
11	0d677af76ca5bf5575d614e04932c3a4	filer_public/07/a0/07a00fd0-92ec-421b-8ed2-1f1e7ebbfd51/70097836-796f-4742-a7be-b8623f72cb74.png	2026-02-12 12:28:41.660828-05
7	0d677af76ca5bf5575d614e04932c3a4	filer_public/c9/95/c995dc13-3e98-4bbc-b0bd-75eb86059641/91f6675b-d90a-47a0-a59e-65a31e4f9281.png	2026-02-12 12:28:49.666463-05
12	0d677af76ca5bf5575d614e04932c3a4	filer_public/93/5b/935b13ff-844d-421c-aa8d-33715e1de7f3/644c894c-91d9-43b4-9df2-ed8fdfa0efa5.png	2026-02-16 10:25:46.998184-05
14	0d677af76ca5bf5575d614e04932c3a4	filer_public/e6/b7/e6b7e24f-ef51-4c79-8cc0-a17010b7a2f4/5a77e8fd-4fd3-4f35-98e7-f34ed66faeed.png	2026-02-16 10:33:56.307776-05
\.


--
-- Data for Name: easy_thumbnails_thumbnail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.easy_thumbnails_thumbnail (id, storage_hash, name, modified, source_id) FROM stdin;
1	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/9e/f6/9ef6629f-57c9-4a91-9293-58e0dd1258f0/055c0e6e-ed27-48bc-a8b1-957cd77add1e.jpg__1800x1200_q85_subsampling-2.jpg	2026-02-03 15:21:33.531409-05	1
2	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/6f/12/6f1270f8-4510-4042-9ba1-9b6dad0ee369/8eaa31c0-1672-4e33-902e-63ee3824a0fe.jpg__1800x1200_q85_subsampling-2.jpg	2026-02-03 15:32:34.372116-05	2
3	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/b5/e8/b5e81f42-d18e-4fda-a915-988f0cefcab6/262f3a4c-a905-44f1-b0db-18cbd93def2a.png__1281x400_subsampling-2.png	2026-02-03 15:44:40.186648-05	3
5	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/a4/b6/a4b65354-308d-47aa-87bc-58423db9d312/step-collage-2024.jpg__210x140_q85_subsampling-2_upscale.jpg	2026-02-04 14:30:37.410813-05	4
6	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/a4/b6/a4b65354-308d-47aa-87bc-58423db9d312/step-collage-2024.jpg__420x280_q85_subsampling-2_upscale.jpg	2026-02-04 14:30:37.454482-05	4
8	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/a4/b6/a4b65354-308d-47aa-87bc-58423db9d312/step-collage-2024.jpg__1800x1200_q85_subject_location-900,600_subsampling-2.jpg	2026-02-04 14:31:04.269368-05	4
9	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/a4/b6/a4b65354-308d-47aa-87bc-58423db9d312/step-collage-2024.jpg__120x120_q85_crop_subsampling-2.jpg	2026-02-04 14:31:14.834851-05	4
10	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/a4/b6/a4b65354-308d-47aa-87bc-58423db9d312/step-collage-2024.jpg__240x240_q85_crop_subsampling-2.jpg	2026-02-04 14:31:14.875789-05	4
11	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/5a/55/5a558f61-9caf-4822-aa93-abf723fd66dc/ee13f35b-2d02-4a39-b58e-e12dbb198c20.jpg__1800x1200_q85_subsampling-2.jpg	2026-02-04 14:39:05.93022-05	5
4	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/a4/b6/a4b65354-308d-47aa-87bc-58423db9d312/step-collage-2024.jpg__40x40_q85_crop_subsampling-2.jpg	2026-02-04 14:43:32.603829-05	4
7	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/a4/b6/a4b65354-308d-47aa-87bc-58423db9d312/step-collage-2024.jpg__80x80_q85_crop_subsampling-2.jpg	2026-02-04 14:49:20.918633-05	4
12	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/88/de/88ded3ef-30e4-407f-8ec5-acee6391c2a4/8d57f2f0-e0ae-4aa4-acd6-718db8e152a7.jpg__1800x1200_q85_subsampling-2.jpg	2026-02-04 14:50:42.198496-05	6
14	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/ca/c0/cac02a70-e94c-4f99-a857-c9110346146d/e59a160b-a70b-4ba6-9744-d73fd8edc161.png__1281x400_subsampling-2.png	2026-02-04 17:06:17.251952-05	8
15	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/25/25/25253139-c3fd-49b1-b544-afdc3f74267a/3139125a-fe2e-4822-a0e9-01eb5349cd91.png__350x109_subsampling-2.png	2026-02-04 17:10:23.847829-05	9
16	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/07/a0/07a00fd0-92ec-421b-8ed2-1f1e7ebbfd51/70097836-796f-4742-a7be-b8623f72cb74.png__425x133_subsampling-2.png	2026-02-12 12:28:41.683921-05	11
13	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/c9/95/c995dc13-3e98-4bbc-b0bd-75eb86059641/91f6675b-d90a-47a0-a59e-65a31e4f9281.png__700x467_subsampling-2.png	2026-02-12 12:28:49.671088-05	7
17	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/93/5b/935b13ff-844d-421c-aa8d-33715e1de7f3/644c894c-91d9-43b4-9df2-ed8fdfa0efa5.png__1260x918_subsampling-2.png	2026-02-16 10:25:47.00168-05	12
18	0d677af76ca5bf5575d614e04932c3a4	filer_public_thumbnails/filer_public/e6/b7/e6b7e24f-ef51-4c79-8cc0-a17010b7a2f4/5a77e8fd-4fd3-4f35-98e7-f34ed66faeed.png__1356x946_subsampling-2.png	2026-02-16 10:33:56.309685-05	14
\.


--
-- Data for Name: easy_thumbnails_thumbnaildimensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.easy_thumbnails_thumbnaildimensions (id, thumbnail_id, width, height) FROM stdin;
\.


--
-- Data for Name: filer_clipboard; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filer_clipboard (id, user_id) FROM stdin;
1	2
2	4
\.


--
-- Data for Name: filer_clipboarditem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filer_clipboarditem (id, clipboard_id, file_id) FROM stdin;
\.


--
-- Data for Name: filer_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filer_file (id, file, _file_size, sha1, has_all_mandatory_data, original_filename, name, description, uploaded_at, modified_at, is_public, folder_id, owner_id, polymorphic_ctype_id, mime_type) FROM stdin;
1	filer_public/9e/f6/9ef6629f-57c9-4a91-9293-58e0dd1258f0/055c0e6e-ed27-48bc-a8b1-957cd77add1e.jpg	1817023	d0849ad39e13e7b4d80e1fa996a6222a157fa9aa	f	\N		\N	2026-02-03 15:21:31.501663-05	2026-02-03 15:21:31.50167-05	t	\N	\N	43	image/jpeg
2	filer_public/6f/12/6f1270f8-4510-4042-9ba1-9b6dad0ee369/8eaa31c0-1672-4e33-902e-63ee3824a0fe.jpg	1817023	d0849ad39e13e7b4d80e1fa996a6222a157fa9aa	f	\N		\N	2026-02-03 15:32:34.164922-05	2026-02-03 15:32:34.164928-05	t	\N	\N	43	image/jpeg
3	filer_public/b5/e8/b5e81f42-d18e-4fda-a915-988f0cefcab6/262f3a4c-a905-44f1-b0db-18cbd93def2a.png	738952	137a1e6336869770dccd5aaa70853d6c96d39389	f	\N		\N	2026-02-03 15:44:39.814812-05	2026-02-03 15:44:39.814816-05	t	\N	\N	43	image/png
5	filer_public/5a/55/5a558f61-9caf-4822-aa93-abf723fd66dc/ee13f35b-2d02-4a39-b58e-e12dbb198c20.jpg	1817023	d0849ad39e13e7b4d80e1fa996a6222a157fa9aa	f	\N		\N	2026-02-04 14:39:05.788728-05	2026-02-04 14:39:05.788734-05	t	\N	\N	43	image/jpeg
4	filer_public/a4/b6/a4b65354-308d-47aa-87bc-58423db9d312/step-collage-2024.jpg	1817023	d0849ad39e13e7b4d80e1fa996a6222a157fa9aa	f	STEP-collage-2024.jpg			2026-02-04 14:30:23.822557-05	2026-02-04 14:44:55.783983-05	t	1	4	43	image/jpeg
6	filer_public/88/de/88ded3ef-30e4-407f-8ec5-acee6391c2a4/8d57f2f0-e0ae-4aa4-acd6-718db8e152a7.jpg	1817023	d0849ad39e13e7b4d80e1fa996a6222a157fa9aa	f	\N		\N	2026-02-04 14:50:42.09118-05	2026-02-04 14:50:42.091192-05	t	\N	\N	43	image/jpeg
7	filer_public/c9/95/c995dc13-3e98-4bbc-b0bd-75eb86059641/91f6675b-d90a-47a0-a59e-65a31e4f9281.png	628158	37cbc5cd8c1888e6a0267b3a996889cec12ac04a	f	\N		\N	2026-02-04 14:59:40.454759-05	2026-02-04 14:59:40.454765-05	t	\N	\N	43	image/png
8	filer_public/ca/c0/cac02a70-e94c-4f99-a857-c9110346146d/e59a160b-a70b-4ba6-9744-d73fd8edc161.png	857639	f24d59762ef96c5429c58e2468936a55ba946b04	f	\N		\N	2026-02-04 17:06:17.149997-05	2026-02-04 17:06:17.150001-05	t	\N	\N	43	image/png
9	filer_public/25/25/25253139-c3fd-49b1-b544-afdc3f74267a/3139125a-fe2e-4822-a0e9-01eb5349cd91.png	75801	1b5d233f328bf28288e1cb592371d6d1abc57bff	f	\N		\N	2026-02-04 17:10:23.79035-05	2026-02-04 17:10:23.790355-05	t	\N	\N	43	image/png
11	filer_public/07/a0/07a00fd0-92ec-421b-8ed2-1f1e7ebbfd51/70097836-796f-4742-a7be-b8623f72cb74.png	108624	fc49557d74c26278dee0be5119b194c4ae997d24	f	\N		\N	2026-02-04 17:12:52.439326-05	2026-02-04 17:12:52.439329-05	t	\N	\N	43	image/png
12	filer_public/93/5b/935b13ff-844d-421c-aa8d-33715e1de7f3/644c894c-91d9-43b4-9df2-ed8fdfa0efa5.png	610077	1a72cfbcdc1b2d2049e2f75f239efb0d0a612f9c	f	\N		\N	2026-02-16 10:25:46.704708-05	2026-02-16 10:25:46.704713-05	t	\N	\N	43	image/png
14	filer_public/e6/b7/e6b7e24f-ef51-4c79-8cc0-a17010b7a2f4/5a77e8fd-4fd3-4f35-98e7-f34ed66faeed.png	241876	c061ec24568897622445cc6125b83b969c40c989	f	\N		\N	2026-02-16 10:33:56.243952-05	2026-02-16 10:33:56.243956-05	t	\N	\N	43	image/png
\.


--
-- Data for Name: filer_folder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filer_folder (id, name, uploaded_at, created_at, modified_at, owner_id, parent_id) FROM stdin;
1	Banners	2026-02-04 14:28:21.792462-05	2026-02-04 14:28:21.792481-05	2026-02-04 14:28:21.792487-05	4	\N
\.


--
-- Data for Name: filer_folderpermission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filer_folderpermission (id, type, everybody, can_edit, can_read, can_add_children, folder_id, group_id, user_id) FROM stdin;
\.


--
-- Data for Name: filer_image; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filer_image (file_ptr_id, _height, _width, date_taken, default_alt_text, default_caption, author, must_always_publish_author_credit, must_always_publish_copyright, subject_location, _transparent) FROM stdin;
1	1200	1800	2026-02-03 15:21:31.471594-05	\N	\N	\N	f	f		f
2	1200	1800	2026-02-03 15:32:34.137278-05	\N	\N	\N	f	f		f
3	400	1281	2026-02-03 15:44:39.806326-05	\N	\N	\N	f	f		t
5	1200	1800	2026-02-04 14:39:05.776809-05	\N	\N	\N	f	f		f
4	1200	1800	2026-02-04 14:30:23.806751-05	2 cohortsof STEP students	\N	\N	f	f	900,600	f
6	1200	1800	2026-02-04 14:50:42.064885-05	\N	\N	\N	f	f		f
7	467	700	2026-02-04 14:59:40.4463-05	\N	\N	\N	f	f		f
8	400	1281	2026-02-04 17:06:17.11108-05	\N	\N	\N	f	f		t
9	109	350	2026-02-04 17:10:23.778295-05	\N	\N	\N	f	f		t
11	133	425	2026-02-04 17:12:52.431247-05	\N	\N	\N	f	f		t
12	918	1260	2026-02-16 10:25:46.690938-05	\N	\N	\N	f	f		t
14	946	1356	2026-02-16 10:33:56.235236-05	\N	\N	\N	f	f		t
\.


--
-- Data for Name: filer_thumbnailoption; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.filer_thumbnailoption (id, name, width, height, crop, upscale) FROM stdin;
\.


--
-- Data for Name: menus_cachekey; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.menus_cachekey (id, language, site, key) FROM stdin;
\.


--
-- Data for Name: operations_portalcms_django_integrationnews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operations_portalcms_django_integrationnews (id, title, content, created_at, updated_at, is_active, author_id, affected_element, effective_date, expiration_date, news_type) FROM stdin;
5	Strawberry twizzlers back from their server repair	\r\n\r\ntwizzlers candy\r\n\r\ndon’t etgay ityay istedtway – izzlerstway andycay ashay omethingsay orfay everyyay uity-chewyfray andycay overlay . eepkay ethay unfay oinggay ! 	2026-02-03 11:29:36.445912-05	2026-02-03 11:29:36.445926-05	t	2		\N	\N	
3	candy cyber infra codev1	owhay ayay eatgray andycay asway avedsay omfray oblivionyay ybay ayay allsmay alienyay isitorvay omfray outeryay acespay oryay ethay orystay ofyay reese’s iecespay , eyay . t . ’s avoritefay andycay . \r\n\r\nin ethay 1950s , ersheyhay ocolatechay evelopedday ethay apabilitycay orfay panning; atthay isyay , ugar-coatingsay ayay oductpray . m&ms areyay obablypray ethay estbay ownknay exampleyay ofyay ayay annedpay andycay oductpray . hershey’s irstfay annedpay oductpray asway ershey-etshay , andy-coatedcay ocolatechay iscsday oryay entilslay . oneyay arketingmay allengechay orfay isthay ewnay oductpray asway atthay enwhay ethay ompanycay introducedyay ershey-etshay , eoplepay ouldway aysay , “what isyay ityay ? ” andyay otay efineday ityay , ouyay adhay otay useyay ethay competitor’s amenay . that’s ayay ettypray ifficultday ituationsay . ethay oductpray asway eventuallyyay iscontinuedday , exceptyay orfay olidayhay andyay easonalsay applicationsyay . 	2026-02-03 10:24:51.598968-05	2026-02-03 12:13:52.173613-05	t	2		\N	\N	
4	candy cyber infra codev2	owhay ayay eatgray andycay asway avedsay omfray oblivionyay ybay ayay allsmay alienyay isitorvay omfray outeryay acespay oryay ethay orystay ofyay reese’s iecespay , eyay . t . ’s avoritefay andycay . \r\n\r\nin ethay 1950s , ersheyhay ocolatechay evelopedday ethay apabilitycay orfay panning; atthay isyay , ugar-coatingsay ayay oductpray . m&ms areyay obablypray ethay estbay ownknay exampleyay ofyay ayay annedpay andycay oductpray . hershey’s irstfay annedpay oductpray asway ershey-etshay , andy-coatedcay ocolatechay iscsday oryay entilslay . oneyay arketingmay allengechay orfay isthay ewnay oductpray asway atthay enwhay ethay ompanycay introducedyay ershey-etshay , eoplepay ouldway aysay , “what isyay ityay ? ” andyay otay efineday ityay , ouyay adhay otay useyay ethay competitor’s amenay . that’s ayay ettypray ifficultday ituationsay . ethay oductpray asway eventuallyyay iscontinuedday , exceptyay orfay olidayhay andyay easonalsay applicationsyay . 	2026-02-03 11:24:02.330126-05	2026-02-03 12:14:04.139442-05	t	2		\N	\N	
6	TWIZZLERS Candy	TWIZZLERS Candy\r\n\r\nDon’t get it twisted – TWIZZLERS Candy has something for every fruity-chewy candy lover. Keep the fun going!	2026-02-03 12:44:00.144854-05	2026-02-03 12:44:00.144861-05	f	2	aws_registry	2026-02-04	2026-02-13	changed_roadmap_task
\.


--
-- Data for Name: operations_portalcms_django_integrationnewsitemplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operations_portalcms_django_integrationnewsitemplugin (cmsplugin_ptr_id, title, content, published_date, author_id) FROM stdin;
\.


--
-- Data for Name: operations_portalcms_django_systemstatusnews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operations_portalcms_django_systemstatusnews (id, content, created_at, updated_at, is_active, author_id, effective_date, expiration_date, affected_infrastructure, email_list, end_datetime, infrastructure_news_type, post_to_slack, send_email, slack_channel, start_datetime, subject) FROM stdin;
3	more candy and latin fakery stuff	2026-01-13 12:40:19.926277-05	2026-02-06 14:30:14.898196-05	t	2	\N	\N			\N	outage_full	f	f		2026-02-06 14:22:48-05	real ou faux candy - that is the question
4	flash orwardfay ayay ouplecay ecadesday . \r\n\r\nin ethay 1970s , ersheyhay ocolatechay evelopedday ayay ormulafay orfay eetenedsway eanutpay ealmay ithway ethay onsistencycay ofyay ocolatechay . ityay ecamebay ethay asisbay orfay reese’s iecespay , ichwhay ereway ademay usingyay ethay amesay ocedurespray andyay equipmentyay asyay ershey-etshay . \r\n\r\nthe ewnay oductpray asway originallyyay amednay spbay . utbay spbay wasn’t ayay operpray amenay andyay ethay oductpray asway oonsay echristenedray reese’s iecespay . \r\n\r\nat atthay imetay , ersheyhay asway uildingbay ayay ewnay anufacturingmay antplay inyay stuart’s aftdray , irginiavay , andyay ersheyhay annedplay otay anufacturemay reese’s iecespay erethay , inyay additionyay otay ethay anufacturingmay inyay ersheyhay .	2026-02-03 11:25:32.410638-05	2026-02-06 14:31:24.501902-05	t	2	\N	\N			2026-02-09 04:23:00-05	reconfiguration	f	f		2026-02-06 14:22:48-05	1970s - the decade for candy
5	Let it be stated that some chocolate is more equal than others - la la la	2026-02-13 09:35:04.427341-05	2026-02-13 09:35:04.427351-05	t	4	\N	\N		jelambe@iu.edu	2026-02-18 02:34:00-05	reconfiguration	f	f		2026-02-16 16:32:00-05	all hersheys chocolate with almonds go to heaven
\.


--
-- Data for Name: operations_portalcms_django_systemstatusnewsitemplugin; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operations_portalcms_django_systemstatusnewsitemplugin (cmsplugin_ptr_id, title, content, published_date, author_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key, provider_id, settings) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.


--
-- Data for Name: taggit_tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.taggit_tag (id, name, slug) FROM stdin;
\.


--
-- Data for Name: taggit_taggeditem; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.taggit_taggeditem (id, object_id, content_type_id, tag_id) FROM stdin;
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 1, false);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 3, true);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 16, true);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 228, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 3, true);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 5, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: cms_cmsplugin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_cmsplugin_id_seq', 57, true);


--
-- Name: cms_globalpagepermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_globalpagepermission_id_seq', 1, false);


--
-- Name: cms_globalpagepermission_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_globalpagepermission_sites_id_seq', 1, false);


--
-- Name: cms_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_page_id_seq', 23, true);


--
-- Name: cms_pagepermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_pagepermission_id_seq', 1, false);


--
-- Name: cms_pageurl_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_pageurl_id_seq', 23, true);


--
-- Name: cms_placeholder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_placeholder_id_seq', 207, true);


--
-- Name: cms_staticplaceholder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_staticplaceholder_id_seq', 1, false);


--
-- Name: cms_title_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_title_id_seq', 23, true);


--
-- Name: cms_urlconfrevision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_urlconfrevision_id_seq', 1, false);


--
-- Name: cms_usersettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cms_usersettings_id_seq', 3, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 239, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 58, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 178, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, true);


--
-- Name: djangocmsjoy_resourcenews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.djangocmsjoy_resourcenews_id_seq', 6, true);


--
-- Name: djangocmsjoy_systemnews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.djangocmsjoy_systemnews_id_seq', 5, true);


--
-- Name: easy_thumbnails_source_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.easy_thumbnails_source_id_seq', 14, true);


--
-- Name: easy_thumbnails_thumbnail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.easy_thumbnails_thumbnail_id_seq', 18, true);


--
-- Name: easy_thumbnails_thumbnaildimensions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.easy_thumbnails_thumbnaildimensions_id_seq', 1, false);


--
-- Name: filer_clipboard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filer_clipboard_id_seq', 2, true);


--
-- Name: filer_clipboarditem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filer_clipboarditem_id_seq', 1, false);


--
-- Name: filer_file_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filer_file_id_seq', 14, true);


--
-- Name: filer_folder_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filer_folder_id_seq', 1, true);


--
-- Name: filer_folderpermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filer_folderpermission_id_seq', 1, false);


--
-- Name: filer_thumbnailoption_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.filer_thumbnailoption_id_seq', 1, false);


--
-- Name: menus_cachekey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.menus_cachekey_id_seq', 20, true);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 1, false);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Name: taggit_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.taggit_tag_id_seq', 1, false);


--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.taggit_taggeditem_id_seq', 1, false);


--
-- Name: account_emailaddress account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailaddress account_emailaddress_user_id_email_987c8728_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_email_987c8728_uniq UNIQUE (user_id, email);


--
-- Name: account_emailconfirmation account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: cms_aliaspluginmodel cms_aliaspluginmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_aliaspluginmodel
    ADD CONSTRAINT cms_aliaspluginmodel_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cms_cmsplugin cms_cmsplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_cmsplugin
    ADD CONSTRAINT cms_cmsplugin_pkey PRIMARY KEY (id);


--
-- Name: cms_cmsplugin cms_cmsplugin_placeholder_id_language_position_bad60ebe_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_cmsplugin
    ADD CONSTRAINT cms_cmsplugin_placeholder_id_language_position_bad60ebe_uniq UNIQUE (placeholder_id, language, "position");


--
-- Name: cms_globalpagepermission_sites cms_globalpagepermission_globalpagepermission_id__db684f41_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission_sites
    ADD CONSTRAINT cms_globalpagepermission_globalpagepermission_id__db684f41_uniq UNIQUE (globalpagepermission_id, site_id);


--
-- Name: cms_globalpagepermission cms_globalpagepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission
    ADD CONSTRAINT cms_globalpagepermission_pkey PRIMARY KEY (id);


--
-- Name: cms_globalpagepermission_sites cms_globalpagepermission_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission_sites
    ADD CONSTRAINT cms_globalpagepermission_sites_pkey PRIMARY KEY (id);


--
-- Name: cms_page cms_page_path_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page
    ADD CONSTRAINT cms_page_path_key UNIQUE (path);


--
-- Name: cms_page cms_page_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page
    ADD CONSTRAINT cms_page_pkey PRIMARY KEY (id);


--
-- Name: cms_pagepermission cms_pagepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pagepermission
    ADD CONSTRAINT cms_pagepermission_pkey PRIMARY KEY (id);


--
-- Name: cms_pageurl cms_pageurl_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pageurl
    ADD CONSTRAINT cms_pageurl_pkey PRIMARY KEY (id);


--
-- Name: cms_pageuser cms_pageuser_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pageuser
    ADD CONSTRAINT cms_pageuser_pkey PRIMARY KEY (user_ptr_id);


--
-- Name: cms_pageusergroup cms_pageusergroup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pageusergroup
    ADD CONSTRAINT cms_pageusergroup_pkey PRIMARY KEY (group_ptr_id);


--
-- Name: cms_placeholder cms_placeholder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_placeholder
    ADD CONSTRAINT cms_placeholder_pkey PRIMARY KEY (id);


--
-- Name: cms_placeholderreference cms_placeholderreference_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_placeholderreference
    ADD CONSTRAINT cms_placeholderreference_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: cms_staticplaceholder cms_staticplaceholder_code_site_id_21ba079c_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_staticplaceholder
    ADD CONSTRAINT cms_staticplaceholder_code_site_id_21ba079c_uniq UNIQUE (code, site_id);


--
-- Name: cms_staticplaceholder cms_staticplaceholder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_staticplaceholder
    ADD CONSTRAINT cms_staticplaceholder_pkey PRIMARY KEY (id);


--
-- Name: cms_pagecontent cms_title_language_page_id_61aaf084_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pagecontent
    ADD CONSTRAINT cms_title_language_page_id_61aaf084_uniq UNIQUE (language, page_id);


--
-- Name: cms_pagecontent cms_title_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pagecontent
    ADD CONSTRAINT cms_title_pkey PRIMARY KEY (id);


--
-- Name: cms_urlconfrevision cms_urlconfrevision_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_urlconfrevision
    ADD CONSTRAINT cms_urlconfrevision_pkey PRIMARY KEY (id);


--
-- Name: cms_usersettings cms_usersettings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_usersettings
    ADD CONSTRAINT cms_usersettings_pkey PRIMARY KEY (id);


--
-- Name: cms_usersettings cms_usersettings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_usersettings
    ADD CONSTRAINT cms_usersettings_user_id_key UNIQUE (user_id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: djangocms_file_file djangocms_file_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_file_file
    ADD CONSTRAINT djangocms_file_file_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: djangocms_file_folder djangocms_file_folder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_file_folder
    ADD CONSTRAINT djangocms_file_folder_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: djangocms_link_link djangocms_link_link_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_link_link
    ADD CONSTRAINT djangocms_link_link_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: djangocms_picture_picture djangocms_picture_picture_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_picture_picture
    ADD CONSTRAINT djangocms_picture_picture_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: djangocms_text_ckeditor_text djangocms_text_ckeditor_text_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_text_ckeditor_text
    ADD CONSTRAINT djangocms_text_ckeditor_text_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: djangocms_video_videoplayer djangocms_video_video_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_video_videoplayer
    ADD CONSTRAINT djangocms_video_video_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: djangocms_video_videosource djangocms_video_videosource_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_video_videosource
    ADD CONSTRAINT djangocms_video_videosource_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: djangocms_video_videotrack djangocms_video_videotrack_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_video_videotrack
    ADD CONSTRAINT djangocms_video_videotrack_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: operations_portalcms_django_integrationnewsitemplugin djangocmsjoy_integrationnewsitemplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations_portalcms_django_integrationnewsitemplugin
    ADD CONSTRAINT djangocmsjoy_integrationnewsitemplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: operations_portalcms_django_integrationnews djangocmsjoy_resourcenews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations_portalcms_django_integrationnews
    ADD CONSTRAINT djangocmsjoy_resourcenews_pkey PRIMARY KEY (id);


--
-- Name: operations_portalcms_django_systemstatusnews djangocmsjoy_systemnews_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations_portalcms_django_systemstatusnews
    ADD CONSTRAINT djangocmsjoy_systemnews_pkey PRIMARY KEY (id);


--
-- Name: operations_portalcms_django_systemstatusnewsitemplugin djangocmsjoy_systemstatusnewsitemplugin_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations_portalcms_django_systemstatusnewsitemplugin
    ADD CONSTRAINT djangocmsjoy_systemstatusnewsitemplugin_pkey PRIMARY KEY (cmsplugin_ptr_id);


--
-- Name: easy_thumbnails_source easy_thumbnails_source_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_source easy_thumbnails_source_storage_hash_name_481ce32d_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_source
    ADD CONSTRAINT easy_thumbnails_source_storage_hash_name_481ce32d_uniq UNIQUE (storage_hash, name);


--
-- Name: easy_thumbnails_thumbnail easy_thumbnails_thumbnai_storage_hash_name_source_fb375270_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnai_storage_hash_name_source_fb375270_uniq UNIQUE (storage_hash, name, source_id);


--
-- Name: easy_thumbnails_thumbnail easy_thumbnails_thumbnail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thumbnail_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnaildimensions easy_thumbnails_thumbnaildimensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_pkey PRIMARY KEY (id);


--
-- Name: easy_thumbnails_thumbnaildimensions easy_thumbnails_thumbnaildimensions_thumbnail_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thumbnaildimensions_thumbnail_id_key UNIQUE (thumbnail_id);


--
-- Name: filer_clipboard filer_clipboard_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_clipboard
    ADD CONSTRAINT filer_clipboard_pkey PRIMARY KEY (id);


--
-- Name: filer_clipboarditem filer_clipboarditem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_clipboarditem
    ADD CONSTRAINT filer_clipboarditem_pkey PRIMARY KEY (id);


--
-- Name: filer_file filer_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_file
    ADD CONSTRAINT filer_file_pkey PRIMARY KEY (id);


--
-- Name: filer_folder filer_folder_parent_id_name_bc773258_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folder
    ADD CONSTRAINT filer_folder_parent_id_name_bc773258_uniq UNIQUE (parent_id, name);


--
-- Name: filer_folder filer_folder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folder
    ADD CONSTRAINT filer_folder_pkey PRIMARY KEY (id);


--
-- Name: filer_folderpermission filer_folderpermission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folderpermission
    ADD CONSTRAINT filer_folderpermission_pkey PRIMARY KEY (id);


--
-- Name: filer_image filer_image_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_image
    ADD CONSTRAINT filer_image_pkey PRIMARY KEY (file_ptr_id);


--
-- Name: filer_thumbnailoption filer_thumbnailoption_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_thumbnailoption
    ADD CONSTRAINT filer_thumbnailoption_pkey PRIMARY KEY (id);


--
-- Name: menus_cachekey menus_cachekey_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menus_cachekey
    ADD CONSTRAINT menus_cachekey_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_provider_uid_fc810c6e_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_provider_uid_fc810c6e_uniq UNIQUE (provider, uid);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq UNIQUE (socialapp_id, site_id);


--
-- Name: socialaccount_socialapp socialaccount_socialapp_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.socialaccount_socialapp
    ADD CONSTRAINT socialaccount_socialapp_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq UNIQUE (app_id, account_id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_pkey PRIMARY KEY (id);


--
-- Name: taggit_tag taggit_tag_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_tag
    ADD CONSTRAINT taggit_tag_name_key UNIQUE (name);


--
-- Name: taggit_tag taggit_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_tag
    ADD CONSTRAINT taggit_tag_pkey PRIMARY KEY (id);


--
-- Name: taggit_tag taggit_tag_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_tag
    ADD CONSTRAINT taggit_tag_slug_key UNIQUE (slug);


--
-- Name: taggit_taggeditem taggit_taggeditem_content_type_id_object_id_tag_id_4bb97a8e_uni; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_content_type_id_object_id_tag_id_4bb97a8e_uni UNIQUE (content_type_id, object_id, tag_id);


--
-- Name: taggit_taggeditem taggit_taggeditem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_pkey PRIMARY KEY (id);


--
-- Name: cms_pageurl unique_together_page_language; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pageurl
    ADD CONSTRAINT unique_together_page_language UNIQUE (page_id, language);


--
-- Name: account_emailaddress_email_03be32b2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX account_emailaddress_email_03be32b2 ON public.account_emailaddress USING btree (email);


--
-- Name: account_emailaddress_email_03be32b2_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX account_emailaddress_email_03be32b2_like ON public.account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX account_emailaddress_user_id_2c513194 ON public.account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id_5b7f8c58; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX account_emailconfirmation_email_address_id_5b7f8c58 ON public.account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_f43612bd_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX account_emailconfirmation_key_f43612bd_like ON public.account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: cms_aliaspluginmodel_alias_placeholder_id_6d6e0c8a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_aliaspluginmodel_alias_placeholder_id_6d6e0c8a ON public.cms_aliaspluginmodel USING btree (alias_placeholder_id);


--
-- Name: cms_aliaspluginmodel_plugin_id_9867676e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_aliaspluginmodel_plugin_id_9867676e ON public.cms_aliaspluginmodel USING btree (plugin_id);


--
-- Name: cms_cmsplug_placeho_3f2b0f_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_cmsplug_placeho_3f2b0f_idx ON public.cms_cmsplugin USING btree (placeholder_id, language, "position");


--
-- Name: cms_cmsplugin_language_bbea8a48; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_cmsplugin_language_bbea8a48 ON public.cms_cmsplugin USING btree (language);


--
-- Name: cms_cmsplugin_language_bbea8a48_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_cmsplugin_language_bbea8a48_like ON public.cms_cmsplugin USING btree (language varchar_pattern_ops);


--
-- Name: cms_cmsplugin_parent_id_fd3bd9dd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_cmsplugin_parent_id_fd3bd9dd ON public.cms_cmsplugin USING btree (parent_id);


--
-- Name: cms_cmsplugin_placeholder_id_0bfa3b26; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_cmsplugin_placeholder_id_0bfa3b26 ON public.cms_cmsplugin USING btree (placeholder_id);


--
-- Name: cms_cmsplugin_plugin_type_94e96ebf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_cmsplugin_plugin_type_94e96ebf ON public.cms_cmsplugin USING btree (plugin_type);


--
-- Name: cms_cmsplugin_plugin_type_94e96ebf_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_cmsplugin_plugin_type_94e96ebf_like ON public.cms_cmsplugin USING btree (plugin_type varchar_pattern_ops);


--
-- Name: cms_globalpagepermission_group_id_991b4733; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_globalpagepermission_group_id_991b4733 ON public.cms_globalpagepermission USING btree (group_id);


--
-- Name: cms_globalpagepermission_sites_globalpagepermission_id_46bd2681; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_globalpagepermission_sites_globalpagepermission_id_46bd2681 ON public.cms_globalpagepermission_sites USING btree (globalpagepermission_id);


--
-- Name: cms_globalpagepermission_sites_site_id_00460b53; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_globalpagepermission_sites_site_id_00460b53 ON public.cms_globalpagepermission_sites USING btree (site_id);


--
-- Name: cms_globalpagepermission_user_id_a227cee1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_globalpagepermission_user_id_a227cee1 ON public.cms_globalpagepermission USING btree (user_id);


--
-- Name: cms_page_application_urls_9ef47497; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_application_urls_9ef47497 ON public.cms_page USING btree (application_urls);


--
-- Name: cms_page_application_urls_9ef47497_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_application_urls_9ef47497_like ON public.cms_page USING btree (application_urls varchar_pattern_ops);


--
-- Name: cms_page_is_home_edadca07; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_is_home_edadca07 ON public.cms_page USING btree (is_home);


--
-- Name: cms_page_navigation_extenders_c24af8dd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_navigation_extenders_c24af8dd ON public.cms_page USING btree (navigation_extenders);


--
-- Name: cms_page_navigation_extenders_c24af8dd_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_navigation_extenders_c24af8dd_like ON public.cms_page USING btree (navigation_extenders varchar_pattern_ops);


--
-- Name: cms_page_parent_id_f89b72e4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_parent_id_f89b72e4 ON public.cms_page USING btree (parent_id);


--
-- Name: cms_page_path_d3a06f3d_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_path_d3a06f3d_like ON public.cms_page USING btree (path varchar_pattern_ops);


--
-- Name: cms_page_reverse_id_ffc9ede2; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_reverse_id_ffc9ede2 ON public.cms_page USING btree (reverse_id);


--
-- Name: cms_page_reverse_id_ffc9ede2_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_reverse_id_ffc9ede2_like ON public.cms_page USING btree (reverse_id varchar_pattern_ops);


--
-- Name: cms_page_site_id_4323d3ff; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_page_site_id_4323d3ff ON public.cms_page USING btree (site_id);


--
-- Name: cms_pagepermission_group_id_af5af193; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pagepermission_group_id_af5af193 ON public.cms_pagepermission USING btree (group_id);


--
-- Name: cms_pagepermission_page_id_0ae9a163; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pagepermission_page_id_0ae9a163 ON public.cms_pagepermission USING btree (page_id);


--
-- Name: cms_pagepermission_user_id_0c7d2b3c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pagepermission_user_id_0c7d2b3c ON public.cms_pagepermission USING btree (user_id);


--
-- Name: cms_pageurl_language_a10302dc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pageurl_language_a10302dc ON public.cms_pageurl USING btree (language);


--
-- Name: cms_pageurl_language_a10302dc_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pageurl_language_a10302dc_like ON public.cms_pageurl USING btree (language varchar_pattern_ops);


--
-- Name: cms_pageurl_page_id_dbf4793a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pageurl_page_id_dbf4793a ON public.cms_pageurl USING btree (page_id);


--
-- Name: cms_pageurl_path_9f26e673; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pageurl_path_9f26e673 ON public.cms_pageurl USING btree (path);


--
-- Name: cms_pageurl_path_9f26e673_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pageurl_path_9f26e673_like ON public.cms_pageurl USING btree (path varchar_pattern_ops);


--
-- Name: cms_pageurl_slug_f8d42287; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pageurl_slug_f8d42287 ON public.cms_pageurl USING btree (slug);


--
-- Name: cms_pageurl_slug_f8d42287_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pageurl_slug_f8d42287_like ON public.cms_pageurl USING btree (slug varchar_pattern_ops);


--
-- Name: cms_pageuser_created_by_id_8e9fbf83; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pageuser_created_by_id_8e9fbf83 ON public.cms_pageuser USING btree (created_by_id);


--
-- Name: cms_pageusergroup_created_by_id_7d57fa39; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_pageusergroup_created_by_id_7d57fa39 ON public.cms_pageusergroup USING btree (created_by_id);


--
-- Name: cms_placeholder_content_type_id_a7659d9c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_placeholder_content_type_id_a7659d9c ON public.cms_placeholder USING btree (content_type_id);


--
-- Name: cms_placeholder_slot_0bc04d21; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_placeholder_slot_0bc04d21 ON public.cms_placeholder USING btree (slot);


--
-- Name: cms_placeholder_slot_0bc04d21_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_placeholder_slot_0bc04d21_like ON public.cms_placeholder USING btree (slot varchar_pattern_ops);


--
-- Name: cms_placeholderreference_placeholder_ref_id_244759b1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_placeholderreference_placeholder_ref_id_244759b1 ON public.cms_placeholderreference USING btree (placeholder_ref_id);


--
-- Name: cms_staticplaceholder_draft_id_5aee407b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_staticplaceholder_draft_id_5aee407b ON public.cms_staticplaceholder USING btree (draft_id);


--
-- Name: cms_staticplaceholder_public_id_876aaa66; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_staticplaceholder_public_id_876aaa66 ON public.cms_staticplaceholder USING btree (public_id);


--
-- Name: cms_staticplaceholder_site_id_dc6a85b6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_staticplaceholder_site_id_dc6a85b6 ON public.cms_staticplaceholder USING btree (site_id);


--
-- Name: cms_title_in_navigation_e2463722; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_in_navigation_e2463722 ON public.cms_pagecontent USING btree (in_navigation);


--
-- Name: cms_title_language_50a0dfa1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_language_50a0dfa1 ON public.cms_pagecontent USING btree (language);


--
-- Name: cms_title_language_50a0dfa1_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_language_50a0dfa1_like ON public.cms_pagecontent USING btree (language varchar_pattern_ops);


--
-- Name: cms_title_limit_visibility_in_menu_762b16e3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_limit_visibility_in_menu_762b16e3 ON public.cms_pagecontent USING btree (limit_visibility_in_menu);


--
-- Name: cms_title_page_id_5fade2a3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_page_id_5fade2a3 ON public.cms_pagecontent USING btree (page_id);


--
-- Name: cms_title_soft_root_45486e51; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_title_soft_root_45486e51 ON public.cms_pagecontent USING btree (soft_root);


--
-- Name: cms_usersettings_clipboard_id_3ae17c19; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cms_usersettings_clipboard_id_3ae17c19 ON public.cms_usersettings USING btree (clipboard_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: djangocms_file_file_file_src_id_74ac14a5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_file_file_file_src_id_74ac14a5 ON public.djangocms_file_file USING btree (file_src_id);


--
-- Name: djangocms_file_folder_folder_src_id_9558406a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_file_folder_folder_src_id_9558406a ON public.djangocms_file_folder USING btree (folder_src_id);


--
-- Name: djangocms_picture_picture_page_link_id_d5c782e0; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_picture_picture_page_link_id_d5c782e0 ON public.djangocms_picture_picture USING btree (link_page_id);


--
-- Name: djangocms_picture_picture_picture_id_f7d6711b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_picture_picture_picture_id_f7d6711b ON public.djangocms_picture_picture USING btree (picture_id);


--
-- Name: djangocms_picture_picture_thumbnail_options_id_59cf80d1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_picture_picture_thumbnail_options_id_59cf80d1 ON public.djangocms_picture_picture USING btree (thumbnail_options_id);


--
-- Name: djangocms_video_videoplayer_poster_id_07790e24; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_video_videoplayer_poster_id_07790e24 ON public.djangocms_video_videoplayer USING btree (poster_id);


--
-- Name: djangocms_video_videosource_source_file_id_16f11167; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_video_videosource_source_file_id_16f11167 ON public.djangocms_video_videosource USING btree (source_file_id);


--
-- Name: djangocms_video_videotrack_src_id_e5a015d8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocms_video_videotrack_src_id_e5a015d8 ON public.djangocms_video_videotrack USING btree (src_id);


--
-- Name: djangocmsjoy_integrationnewsitemplugin_author_id_32089c1a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocmsjoy_integrationnewsitemplugin_author_id_32089c1a ON public.operations_portalcms_django_integrationnewsitemplugin USING btree (author_id);


--
-- Name: djangocmsjoy_resourcenews_author_id_cb45b430; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocmsjoy_resourcenews_author_id_cb45b430 ON public.operations_portalcms_django_integrationnews USING btree (author_id);


--
-- Name: djangocmsjoy_systemnews_author_id_a0aca835; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocmsjoy_systemnews_author_id_a0aca835 ON public.operations_portalcms_django_systemstatusnews USING btree (author_id);


--
-- Name: djangocmsjoy_systemstatusnewsitemplugin_author_id_fb1f3e7a; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX djangocmsjoy_systemstatusnewsitemplugin_author_id_fb1f3e7a ON public.operations_portalcms_django_systemstatusnewsitemplugin USING btree (author_id);


--
-- Name: easy_thumbnails_source_name_5fe0edc6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_source_name_5fe0edc6 ON public.easy_thumbnails_source USING btree (name);


--
-- Name: easy_thumbnails_source_name_5fe0edc6_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_source_name_5fe0edc6_like ON public.easy_thumbnails_source USING btree (name varchar_pattern_ops);


--
-- Name: easy_thumbnails_source_storage_hash_946cbcc9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_source_storage_hash_946cbcc9 ON public.easy_thumbnails_source USING btree (storage_hash);


--
-- Name: easy_thumbnails_source_storage_hash_946cbcc9_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_source_storage_hash_946cbcc9_like ON public.easy_thumbnails_source USING btree (storage_hash varchar_pattern_ops);


--
-- Name: easy_thumbnails_thumbnail_name_b5882c31; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_thumbnail_name_b5882c31 ON public.easy_thumbnails_thumbnail USING btree (name);


--
-- Name: easy_thumbnails_thumbnail_name_b5882c31_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_thumbnail_name_b5882c31_like ON public.easy_thumbnails_thumbnail USING btree (name varchar_pattern_ops);


--
-- Name: easy_thumbnails_thumbnail_source_id_5b57bc77; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_thumbnail_source_id_5b57bc77 ON public.easy_thumbnails_thumbnail USING btree (source_id);


--
-- Name: easy_thumbnails_thumbnail_storage_hash_f1435f49; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_thumbnail_storage_hash_f1435f49 ON public.easy_thumbnails_thumbnail USING btree (storage_hash);


--
-- Name: easy_thumbnails_thumbnail_storage_hash_f1435f49_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX easy_thumbnails_thumbnail_storage_hash_f1435f49_like ON public.easy_thumbnails_thumbnail USING btree (storage_hash varchar_pattern_ops);


--
-- Name: filer_clipboard_user_id_b52ff0bc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_clipboard_user_id_b52ff0bc ON public.filer_clipboard USING btree (user_id);


--
-- Name: filer_clipboarditem_clipboard_id_7a76518b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_clipboarditem_clipboard_id_7a76518b ON public.filer_clipboarditem USING btree (clipboard_id);


--
-- Name: filer_clipboarditem_file_id_06196f80; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_clipboarditem_file_id_06196f80 ON public.filer_clipboarditem USING btree (file_id);


--
-- Name: filer_file_folder_id_af803bbb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_file_folder_id_af803bbb ON public.filer_file USING btree (folder_id);


--
-- Name: filer_file_owner_id_b9e32671; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_file_owner_id_b9e32671 ON public.filer_file USING btree (owner_id);


--
-- Name: filer_file_polymorphic_ctype_id_f44903c1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_file_polymorphic_ctype_id_f44903c1 ON public.filer_file USING btree (polymorphic_ctype_id);


--
-- Name: filer_folder_owner_id_be530fb4; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_folder_owner_id_be530fb4 ON public.filer_folder USING btree (owner_id);


--
-- Name: filer_folder_parent_id_308aecda; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_folder_parent_id_308aecda ON public.filer_folder USING btree (parent_id);


--
-- Name: filer_folderpermission_folder_id_5d02f1da; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_folderpermission_folder_id_5d02f1da ON public.filer_folderpermission USING btree (folder_id);


--
-- Name: filer_folderpermission_group_id_8901bafa; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_folderpermission_group_id_8901bafa ON public.filer_folderpermission USING btree (group_id);


--
-- Name: filer_folderpermission_user_id_7673d4b6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX filer_folderpermission_user_id_7673d4b6 ON public.filer_folderpermission USING btree (user_id);


--
-- Name: socialaccount_socialaccount_user_id_8146e70c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX socialaccount_socialaccount_user_id_8146e70c ON public.socialaccount_socialaccount USING btree (user_id);


--
-- Name: socialaccount_socialapp_sites_site_id_2579dee5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX socialaccount_socialapp_sites_site_id_2579dee5 ON public.socialaccount_socialapp_sites USING btree (site_id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id_97fb6e7d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX socialaccount_socialapp_sites_socialapp_id_97fb6e7d ON public.socialaccount_socialapp_sites USING btree (socialapp_id);


--
-- Name: socialaccount_socialtoken_account_id_951f210e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX socialaccount_socialtoken_account_id_951f210e ON public.socialaccount_socialtoken USING btree (account_id);


--
-- Name: socialaccount_socialtoken_app_id_636a42d7; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX socialaccount_socialtoken_app_id_636a42d7 ON public.socialaccount_socialtoken USING btree (app_id);


--
-- Name: taggit_tag_name_58eb2ed9_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_tag_name_58eb2ed9_like ON public.taggit_tag USING btree (name varchar_pattern_ops);


--
-- Name: taggit_tag_slug_6be58b2c_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_tag_slug_6be58b2c_like ON public.taggit_tag USING btree (slug varchar_pattern_ops);


--
-- Name: taggit_tagg_content_8fc721_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_tagg_content_8fc721_idx ON public.taggit_taggeditem USING btree (content_type_id, object_id);


--
-- Name: taggit_taggeditem_content_type_id_9957a03c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_taggeditem_content_type_id_9957a03c ON public.taggit_taggeditem USING btree (content_type_id);


--
-- Name: taggit_taggeditem_object_id_e2d7d1df; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_taggeditem_object_id_e2d7d1df ON public.taggit_taggeditem USING btree (object_id);


--
-- Name: taggit_taggeditem_tag_id_f4f5b767; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX taggit_taggeditem_tag_id_f4f5b767 ON public.taggit_taggeditem USING btree (tag_id);


--
-- Name: unique_primary_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_primary_email ON public.account_emailaddress USING btree (user_id, "primary") WHERE "primary";


--
-- Name: unique_verified_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_verified_email ON public.account_emailaddress USING btree (email) WHERE verified;


--
-- Name: account_emailaddress account_emailaddress_user_id_2c513194_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_2c513194_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_emailconfirmation account_emailconfirm_email_address_id_5b7f8c58_fk_account_e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirm_email_address_id_5b7f8c58_fk_account_e FOREIGN KEY (email_address_id) REFERENCES public.account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_aliaspluginmodel cms_aliaspluginmodel_alias_placeholder_id_6d6e0c8a_fk_cms_place; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_aliaspluginmodel
    ADD CONSTRAINT cms_aliaspluginmodel_alias_placeholder_id_6d6e0c8a_fk_cms_place FOREIGN KEY (alias_placeholder_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_aliaspluginmodel cms_aliaspluginmodel_cmsplugin_ptr_id_f71dfd31_fk_cms_cmspl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_aliaspluginmodel
    ADD CONSTRAINT cms_aliaspluginmodel_cmsplugin_ptr_id_f71dfd31_fk_cms_cmspl FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_aliaspluginmodel cms_aliaspluginmodel_plugin_id_9867676e_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_aliaspluginmodel
    ADD CONSTRAINT cms_aliaspluginmodel_plugin_id_9867676e_fk_cms_cmsplugin_id FOREIGN KEY (plugin_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_cmsplugin cms_cmsplugin_parent_id_fd3bd9dd_fk_cms_cmsplugin_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_cmsplugin
    ADD CONSTRAINT cms_cmsplugin_parent_id_fd3bd9dd_fk_cms_cmsplugin_id FOREIGN KEY (parent_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_cmsplugin cms_cmsplugin_placeholder_id_0bfa3b26_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_cmsplugin
    ADD CONSTRAINT cms_cmsplugin_placeholder_id_0bfa3b26_fk_cms_placeholder_id FOREIGN KEY (placeholder_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_globalpagepermission_sites cms_globalpagepermis_globalpagepermission_46bd2681_fk_cms_globa; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission_sites
    ADD CONSTRAINT cms_globalpagepermis_globalpagepermission_46bd2681_fk_cms_globa FOREIGN KEY (globalpagepermission_id) REFERENCES public.cms_globalpagepermission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_globalpagepermission_sites cms_globalpagepermis_site_id_00460b53_fk_django_si; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission_sites
    ADD CONSTRAINT cms_globalpagepermis_site_id_00460b53_fk_django_si FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_globalpagepermission cms_globalpagepermission_group_id_991b4733_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission
    ADD CONSTRAINT cms_globalpagepermission_group_id_991b4733_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_globalpagepermission cms_globalpagepermission_user_id_a227cee1_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_globalpagepermission
    ADD CONSTRAINT cms_globalpagepermission_user_id_a227cee1_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_page cms_page_parent_id_f89b72e4_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page
    ADD CONSTRAINT cms_page_parent_id_f89b72e4_fk_cms_page_id FOREIGN KEY (parent_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_page cms_page_site_id_4323d3ff_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_page
    ADD CONSTRAINT cms_page_site_id_4323d3ff_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pagepermission cms_pagepermission_group_id_af5af193_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pagepermission
    ADD CONSTRAINT cms_pagepermission_group_id_af5af193_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pagepermission cms_pagepermission_page_id_0ae9a163_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pagepermission
    ADD CONSTRAINT cms_pagepermission_page_id_0ae9a163_fk_cms_page_id FOREIGN KEY (page_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pagepermission cms_pagepermission_user_id_0c7d2b3c_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pagepermission
    ADD CONSTRAINT cms_pagepermission_user_id_0c7d2b3c_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pageurl cms_pageurl_page_id_dbf4793a_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pageurl
    ADD CONSTRAINT cms_pageurl_page_id_dbf4793a_fk_cms_page_id FOREIGN KEY (page_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pageuser cms_pageuser_created_by_id_8e9fbf83_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pageuser
    ADD CONSTRAINT cms_pageuser_created_by_id_8e9fbf83_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pageuser cms_pageuser_user_ptr_id_b3d65592_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pageuser
    ADD CONSTRAINT cms_pageuser_user_ptr_id_b3d65592_fk_auth_user_id FOREIGN KEY (user_ptr_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pageusergroup cms_pageusergroup_created_by_id_7d57fa39_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pageusergroup
    ADD CONSTRAINT cms_pageusergroup_created_by_id_7d57fa39_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pageusergroup cms_pageusergroup_group_ptr_id_34578d93_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pageusergroup
    ADD CONSTRAINT cms_pageusergroup_group_ptr_id_34578d93_fk_auth_group_id FOREIGN KEY (group_ptr_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_placeholder cms_placeholder_content_type_id_a7659d9c_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_placeholder
    ADD CONSTRAINT cms_placeholder_content_type_id_a7659d9c_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_placeholderreference cms_placeholderrefer_cmsplugin_ptr_id_6977ec85_fk_cms_cmspl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_placeholderreference
    ADD CONSTRAINT cms_placeholderrefer_cmsplugin_ptr_id_6977ec85_fk_cms_cmspl FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_placeholderreference cms_placeholderrefer_placeholder_ref_id_244759b1_fk_cms_place; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_placeholderreference
    ADD CONSTRAINT cms_placeholderrefer_placeholder_ref_id_244759b1_fk_cms_place FOREIGN KEY (placeholder_ref_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_staticplaceholder cms_staticplaceholder_draft_id_5aee407b_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_staticplaceholder
    ADD CONSTRAINT cms_staticplaceholder_draft_id_5aee407b_fk_cms_placeholder_id FOREIGN KEY (draft_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_staticplaceholder cms_staticplaceholder_public_id_876aaa66_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_staticplaceholder
    ADD CONSTRAINT cms_staticplaceholder_public_id_876aaa66_fk_cms_placeholder_id FOREIGN KEY (public_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_staticplaceholder cms_staticplaceholder_site_id_dc6a85b6_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_staticplaceholder
    ADD CONSTRAINT cms_staticplaceholder_site_id_dc6a85b6_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_pagecontent cms_title_page_id_5fade2a3_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_pagecontent
    ADD CONSTRAINT cms_title_page_id_5fade2a3_fk_cms_page_id FOREIGN KEY (page_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_usersettings cms_usersettings_clipboard_id_3ae17c19_fk_cms_placeholder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_usersettings
    ADD CONSTRAINT cms_usersettings_clipboard_id_3ae17c19_fk_cms_placeholder_id FOREIGN KEY (clipboard_id) REFERENCES public.cms_placeholder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cms_usersettings cms_usersettings_user_id_09633b2d_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cms_usersettings
    ADD CONSTRAINT cms_usersettings_user_id_09633b2d_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_file_file djangocms_file_file_cmsplugin_ptr_id_428f5041_fk_cms_cmspl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_file_file
    ADD CONSTRAINT djangocms_file_file_cmsplugin_ptr_id_428f5041_fk_cms_cmspl FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_file_file djangocms_file_file_file_src_id_74ac14a5_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_file_file
    ADD CONSTRAINT djangocms_file_file_file_src_id_74ac14a5_fk_filer_file_id FOREIGN KEY (file_src_id) REFERENCES public.filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_file_folder djangocms_file_folde_cmsplugin_ptr_id_b258b166_fk_cms_cmspl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_file_folder
    ADD CONSTRAINT djangocms_file_folde_cmsplugin_ptr_id_b258b166_fk_cms_cmspl FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_file_folder djangocms_file_folder_folder_src_id_9558406a_fk_filer_folder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_file_folder
    ADD CONSTRAINT djangocms_file_folder_folder_src_id_9558406a_fk_filer_folder_id FOREIGN KEY (folder_src_id) REFERENCES public.filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_link_link djangocms_link_link_cmsplugin_ptr_id_10f7b2f2_fk_cms_cmspl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_link_link
    ADD CONSTRAINT djangocms_link_link_cmsplugin_ptr_id_10f7b2f2_fk_cms_cmspl FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_picture_picture djangocms_picture_pi_cmsplugin_ptr_id_0e797309_fk_cms_cmspl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_picture_picture
    ADD CONSTRAINT djangocms_picture_pi_cmsplugin_ptr_id_0e797309_fk_cms_cmspl FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_picture_picture djangocms_picture_pi_picture_id_f7d6711b_fk_filer_ima; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_picture_picture
    ADD CONSTRAINT djangocms_picture_pi_picture_id_f7d6711b_fk_filer_ima FOREIGN KEY (picture_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_picture_picture djangocms_picture_pi_thumbnail_options_id_59cf80d1_fk_filer_thu; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_picture_picture
    ADD CONSTRAINT djangocms_picture_pi_thumbnail_options_id_59cf80d1_fk_filer_thu FOREIGN KEY (thumbnail_options_id) REFERENCES public.filer_thumbnailoption(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_picture_picture djangocms_picture_picture_link_page_id_dbec9beb_fk_cms_page_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_picture_picture
    ADD CONSTRAINT djangocms_picture_picture_link_page_id_dbec9beb_fk_cms_page_id FOREIGN KEY (link_page_id) REFERENCES public.cms_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_text_ckeditor_text djangocms_text_ckedi_cmsplugin_ptr_id_946882c1_fk_cms_cmspl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_text_ckeditor_text
    ADD CONSTRAINT djangocms_text_ckedi_cmsplugin_ptr_id_946882c1_fk_cms_cmspl FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_video_videosource djangocms_video_vide_cmsplugin_ptr_id_474cebf9_fk_cms_cmspl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_video_videosource
    ADD CONSTRAINT djangocms_video_vide_cmsplugin_ptr_id_474cebf9_fk_cms_cmspl FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_video_videoplayer djangocms_video_vide_cmsplugin_ptr_id_cc81a95d_fk_cms_cmspl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_video_videoplayer
    ADD CONSTRAINT djangocms_video_vide_cmsplugin_ptr_id_cc81a95d_fk_cms_cmspl FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_video_videotrack djangocms_video_vide_cmsplugin_ptr_id_edcbdf6c_fk_cms_cmspl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_video_videotrack
    ADD CONSTRAINT djangocms_video_vide_cmsplugin_ptr_id_edcbdf6c_fk_cms_cmspl FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_video_videoplayer djangocms_video_vide_poster_id_07790e24_fk_filer_ima; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_video_videoplayer
    ADD CONSTRAINT djangocms_video_vide_poster_id_07790e24_fk_filer_ima FOREIGN KEY (poster_id) REFERENCES public.filer_image(file_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_video_videosource djangocms_video_vide_source_file_id_16f11167_fk_filer_fil; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_video_videosource
    ADD CONSTRAINT djangocms_video_vide_source_file_id_16f11167_fk_filer_fil FOREIGN KEY (source_file_id) REFERENCES public.filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djangocms_video_videotrack djangocms_video_videotrack_src_id_e5a015d8_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.djangocms_video_videotrack
    ADD CONSTRAINT djangocms_video_videotrack_src_id_e5a015d8_fk_filer_file_id FOREIGN KEY (src_id) REFERENCES public.filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: operations_portalcms_django_integrationnewsitemplugin djangocmsjoy_integra_author_id_32089c1a_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations_portalcms_django_integrationnewsitemplugin
    ADD CONSTRAINT djangocmsjoy_integra_author_id_32089c1a_fk_auth_user FOREIGN KEY (author_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: operations_portalcms_django_integrationnewsitemplugin djangocmsjoy_integra_cmsplugin_ptr_id_a403debb_fk_cms_cmspl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations_portalcms_django_integrationnewsitemplugin
    ADD CONSTRAINT djangocmsjoy_integra_cmsplugin_ptr_id_a403debb_fk_cms_cmspl FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: operations_portalcms_django_integrationnews djangocmsjoy_resourcenews_author_id_cb45b430_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations_portalcms_django_integrationnews
    ADD CONSTRAINT djangocmsjoy_resourcenews_author_id_cb45b430_fk_auth_user_id FOREIGN KEY (author_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: operations_portalcms_django_systemstatusnews djangocmsjoy_systemnews_author_id_a0aca835_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations_portalcms_django_systemstatusnews
    ADD CONSTRAINT djangocmsjoy_systemnews_author_id_a0aca835_fk_auth_user_id FOREIGN KEY (author_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: operations_portalcms_django_systemstatusnewsitemplugin djangocmsjoy_systems_author_id_fb1f3e7a_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations_portalcms_django_systemstatusnewsitemplugin
    ADD CONSTRAINT djangocmsjoy_systems_author_id_fb1f3e7a_fk_auth_user FOREIGN KEY (author_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: operations_portalcms_django_systemstatusnewsitemplugin djangocmsjoy_systems_cmsplugin_ptr_id_f0585fe0_fk_cms_cmspl; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operations_portalcms_django_systemstatusnewsitemplugin
    ADD CONSTRAINT djangocmsjoy_systems_cmsplugin_ptr_id_f0585fe0_fk_cms_cmspl FOREIGN KEY (cmsplugin_ptr_id) REFERENCES public.cms_cmsplugin(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: easy_thumbnails_thumbnail easy_thumbnails_thum_source_id_5b57bc77_fk_easy_thum; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnail
    ADD CONSTRAINT easy_thumbnails_thum_source_id_5b57bc77_fk_easy_thum FOREIGN KEY (source_id) REFERENCES public.easy_thumbnails_source(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: easy_thumbnails_thumbnaildimensions easy_thumbnails_thum_thumbnail_id_c3a0c549_fk_easy_thum; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.easy_thumbnails_thumbnaildimensions
    ADD CONSTRAINT easy_thumbnails_thum_thumbnail_id_c3a0c549_fk_easy_thum FOREIGN KEY (thumbnail_id) REFERENCES public.easy_thumbnails_thumbnail(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_clipboard filer_clipboard_user_id_b52ff0bc_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_clipboard
    ADD CONSTRAINT filer_clipboard_user_id_b52ff0bc_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_clipboarditem filer_clipboarditem_clipboard_id_7a76518b_fk_filer_clipboard_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_clipboarditem
    ADD CONSTRAINT filer_clipboarditem_clipboard_id_7a76518b_fk_filer_clipboard_id FOREIGN KEY (clipboard_id) REFERENCES public.filer_clipboard(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_clipboarditem filer_clipboarditem_file_id_06196f80_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_clipboarditem
    ADD CONSTRAINT filer_clipboarditem_file_id_06196f80_fk_filer_file_id FOREIGN KEY (file_id) REFERENCES public.filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_file filer_file_folder_id_af803bbb_fk_filer_folder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_file
    ADD CONSTRAINT filer_file_folder_id_af803bbb_fk_filer_folder_id FOREIGN KEY (folder_id) REFERENCES public.filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_file filer_file_owner_id_b9e32671_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_file
    ADD CONSTRAINT filer_file_owner_id_b9e32671_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_file filer_file_polymorphic_ctype_id_f44903c1_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_file
    ADD CONSTRAINT filer_file_polymorphic_ctype_id_f44903c1_fk_django_co FOREIGN KEY (polymorphic_ctype_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_folder filer_folder_owner_id_be530fb4_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folder
    ADD CONSTRAINT filer_folder_owner_id_be530fb4_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_folder filer_folder_parent_id_308aecda_fk_filer_folder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folder
    ADD CONSTRAINT filer_folder_parent_id_308aecda_fk_filer_folder_id FOREIGN KEY (parent_id) REFERENCES public.filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_folderpermission filer_folderpermission_folder_id_5d02f1da_fk_filer_folder_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folderpermission
    ADD CONSTRAINT filer_folderpermission_folder_id_5d02f1da_fk_filer_folder_id FOREIGN KEY (folder_id) REFERENCES public.filer_folder(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_folderpermission filer_folderpermission_group_id_8901bafa_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folderpermission
    ADD CONSTRAINT filer_folderpermission_group_id_8901bafa_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_folderpermission filer_folderpermission_user_id_7673d4b6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_folderpermission
    ADD CONSTRAINT filer_folderpermission_user_id_7673d4b6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: filer_image filer_image_file_ptr_id_3e21d4f0_fk_filer_file_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.filer_image
    ADD CONSTRAINT filer_image_file_ptr_id_3e21d4f0_fk_filer_file_id FOREIGN KEY (file_ptr_id) REFERENCES public.filer_file(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_account_id_951f210e_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_account_id_951f210e_fk_socialacc FOREIGN KEY (account_id) REFERENCES public.socialaccount_socialaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_app_id_636a42d7_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_app_id_636a42d7_fk_socialacc FOREIGN KEY (app_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_site_id_2579dee5_fk_django_si; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_site_id_2579dee5_fk_django_si FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc FOREIGN KEY (socialapp_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_user_id_8146e70c_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_user_id_8146e70c_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: taggit_taggeditem taggit_taggeditem_content_type_id_9957a03c_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_content_type_id_9957a03c_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: taggit_taggeditem taggit_taggeditem_tag_id_f4f5b767_fk_taggit_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_tag_id_f4f5b767_fk_taggit_tag_id FOREIGN KEY (tag_id) REFERENCES public.taggit_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

\unrestrict C2bNOe3oulJmmKEGTggCUthMQa5ZshXos5qvhyb6c9dnJwIP4DjRS6A2NpNfppH

